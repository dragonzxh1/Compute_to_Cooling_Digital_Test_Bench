# C2C-DTB offline V4 source SDK
Use a separate stable Python3.11 environment; install the delivered
v0_2/tests/tools/c3b_v14_1/requirements-development.lock.
Run `python sdk_cli.py --describe --verify` to inspect parameters without models.
On an approved stable execution host, use
`python sdk_cli.py --run --input-index 15 --rows 3` for a small offline example.
Complete traces and immutable completed records are retained under artifacts/m1-autonomous-development in this SDK directory. This is not formal qualification or hardware control.
The known hard-hanging HIPPO workstation is refused for model execution.
See docs/M1_SOFTWARE_USER_GUIDE.md and docs/V02_PHYSICS_PARAMETER_REFERENCE.md.
Do not modify frozen parameters/expectations merely to get PASS.