# R4.7-C1 — PRE/POST Publication Semantics Adjudication

## 1. 工程决策

Primary decision：`CONTRACT15A_TIMING_CLARIFICATION_REQUIRED`。

Preferred publication model：**P1：phase-qualified PRE Safety contribution + 一次POST final public publication**，仅有条件推荐。CONTRACT_CLARIFICATION_APPROVED=NO；SPLIT_EQUIVALENCE_PROVED=NO；FULL_RUNTIME_SPEC_FROZEN=NO；PRODUCTION_IMPLEMENTATION_AUTHORIZED=NO。

已起草单独 `CONTRACT15A_PUBLICATION_TIMING_CLARIFICATION_DRAFT`，状态PROPOSED_ONLY_NOT_APPROVED，不改Contract15A。提案不改六state/mapping/qualified tracking算法，而是明确一个尚未授权的Safety观察时间接口；不能把它包装成“现有合同本来如此”。若批准/验证发现必须改qualification或原finalpublictiming，则需单独语义重开。

大白话：保留“这一拍Safety据真实旧证据看到疑似故障”和“随后泵命令撤回、最终tracking显示无方向待办”两个事实。前者不是误判，后者不回写已经发生的Safety决定。但二者各管哪一次决策，必须另写窄条款并获批准。

## 2. 基线先核验

本次先按用户给定hash核验C四文件、candidate、run manifest、Contract15A和Policy A canonical，全部匹配；SOURCE_IDENTITY_MISMATCH=NO。再核验C上游全部绑定，无drift。原R4.6 U-fresh stdout/stderr/structured/parser/gate/stage manifest六文件raw（JSON另核canonical）均匹配run manifest，才读取trace。

源SHA由registration/source_hash_bindings保存。关键source：

| 来源 | RAW SHA-256 |
| --- | --- |
| contracts/14_control_input_permission_contract.md | efd8d325753163b91170578ceeb3de02dafafbf8fb0a208a279c76c964d7b144 |
| contracts/15_safety_supervisor_contract.md | 1e93c50037e2b211494e98b30f951e638399e041d1c07b9c0daa2426fb00e073 |
| contracts/15A_tracking_safety_policy_amendment.md | b741a05925a043706dbdc93351faf37fdbd6f1d41ad22360143c8184dd08e280 |
| v0_2/examples/phase5_r5_2_1r4_5c_lifecycle_engine.py | 453f2f1d02c9aaa845d5222b3ef01da8c1a9db6580268c54674d374d76fa9300 |
| v0_2/examples/phase5_r5_2_1r4_paired_engine.py | 1197847d61f1dbab08b42da7b7fc7c6dcd34cfd8c12e0135f8b0320c64d26a6d |
| U-fresh/structured_result.json（下述run目录） | 859b4809f5c14c07e135bb0950917b3787f37e766c386a3b1bebdbb6c544cc03 |

run目录为 `artifacts/r46-qualification-executions/r46-575461fb6cb3420eabbe4b3e878517ac/`。Source行号以本机已核验bytes为准，JSON来源同时给pointer；不改旧报告行号或旧hash。

## 3. 精确State U witness：原trace + 静态PRE推导

case=ST12-U-CONTROL-v1；stage=U-fresh；冻结registration canonical=2dbc47f859eb05bcda99ffbb2941752260d55bc8c33e3e1d68b6501f5bbcf707。

| 项目 | 核验后的事实 | 证据性质 |
| --- | --- | --- |
| source sample | synthetic-measurement:1200000000；sample/release/evaluation均1200000000ns；measured0.5，VALID | 原structured inputs/records |
| prior command | command0.7，issue0；progress pair source command ID released-command:0 | 原pair；这是fixture fallback ID，不是真实PLCcommand/cycleID |
| 旧义务 | tracking-epoch:1，expected_direction=+1，watch motion-watch:1/start0；startup directional_obligation对象为null | 原先前record和epoch START；不补造obligation |
| evaluation evidence | fault_evidence_before_evaluation=0；carried_suspicion_evidence=1；expected_motion=0.1264241117657115；measured/qualified progress0/false；notconfirmed | 原finalrecord保留评价字段；不是本次计算 |
| PRE state | TRACKING_FAULT_SUSPECTED | 冻结source分支推导，不是原run中独立PRE Safety快照 |
| 同tickwithdrawal | command0.5，issue1200000000ns | 原input |
| retention | CLOSE_DIRECTIONAL_OBLIGATION/history_retained=true；epoch关闭DIRECTION_WITHDRAWN_HISTORY_RETAINED；watch不重建/不CANCEL | 原lifecycle/epoch/watch events |
| POST | STEADY_TRACKING，direction inactive，history retained，startup_demand_suspended=true；confirmed_latched=false | 原records + 冻结post_withdrawal_public_state |
| public transitions | 此tick恰好1条：SUSPECTED→STEADY；没有额外PRE公开事件 | 原snapshot.transitions |
| 后续区分 | 2.6s reissue同watch、expected_motion0、count1、notconfirmed、finalHANDOFF；run-end已confirmed是后续事实 | 不将run-end latch当1.2s状态 |

1.0s原record已经是SUSPECTED（count0）；因此本witness不是声称1.2s首次出现公开suspected。1.2s PRE仍/成为旧义务suspected，随后撤回finalsteady。

PRE推导链：`lifecycle.py:125–139`先以旧command/time构造old_context并super.update；`paired.py:238–248`的distinct deficient branch增count至1、line243赋SUSPECTED，未达到confirm；`lifecycle.py:146–151`因撤回net非material、非confirmed、无qualifiedprogress赋finalSTEADY；`169–173`删除该tick父层transition并只公开final变化。_consume记录opportunity消费不等于fault，fault count由paired合格measurement产生。

原证据没有实际PRE SafetyDecision、runtime transaction/cycle ID或实际PLCoutput。JSON明确保留这些“未记录”而不捏造。以上fixture数字不是新hardware设定。

## 4. Contract14/15/15A依据裁决

| 问题 | 分类 | 精确依据及缺口 |
| --- | --- | --- |
| A：Safety在PRE cut消费贡献 | IMPLIED_BUT_UNSPECIFIED | 15A:9/13/17/20允许qualified内部contribution及mapping；:30规定Safety-before-PLC；14:18/19/31规定权限/时间对齐。没有PRE transaction lease条款 |
| B：POST不同的finalpublicstate | IMPLIED_BUT_UNSPECIFIED | candidate lifecycle:146/151/169/173及U冻结final期望直接支持此final行为；15A:13/17支持steady/suspected映射，但未命名POST-public与Safety不同cut |
| C：同transaction两值共同授权 | NOT_AUTHORIZED | 15A:9/28/30/34/57及15:9/11/50/70没有合并时间切面、applicability/expiration/POST-failure规则，现阶段未建立完整权限 |

每项source路径、lines和raw SHA在registration的contract_findings对象完整绑定。NOT_AUTHORIZED在此指“尚无共同时间协议授权”，不是证明合同禁止所有双phase、更不是CONTRACT_CONFLICT。已有字段可算两个值，也不等于获许可消费。

15A:28的currently-active reasons必须指定观察cut；:34既有恢复/锁存规则不改。Final SafetyState本来还受独立channel影响，不能错误要求SafetyState字面等于tracking state。需要补充的是tracking contribution当前决策的时间身份，而不是Severity重新定义。

## 5. P1/P2/P3对比

| 评价项 | P1 双cut | P2 延迟finalpublication | P3 现有held-command pre-PLC path |
| --- | --- | --- | --- |
| 14/15A | 原authority/mapping可保持，需单独timing批准 | authority可能保持，但原publication变 | loop authority存在，未接合格qualifier |
| Safety-before-PLC | 保持 | 可保持 | 现有loop:199/214保持 |
| frozen final观察等价 | 有望，16路径待验证 | QUALIFIED_SEMANTIC_DIFFERENCE | 新command留到下一评价，未证明等价 |
| State U | final1.2ssteady/flagTrue不推迟 | 原精确tick可能被推迟 | 简单oldcommand path不处理同tickwithdraw/reissue |
| 同tickwithdrawal | POST本tick处理 | latercut改变 | 需另桥，不能原样解决 |
| 同tickconfirmation | PRE真实confirm不得压制 | 不得用延迟隐藏确认 | 旧raw2s timer不能代替qualifiedevidence |
| single credit | context-only+ledger，仍需实证 | 单state不证明singlecredit | 单call也不证明source身份 |
| public latency | 不加sample延迟，finalcut不变 | 增tick/改变timing | 可能enrollment/publicshift |
| all-reason retention | POST无Safety写权 | 仍需独立实现 | 旧if/elif已有缺口 |
| rollback/crash | commits不可回滚；POST失败需受控核验 | deferral仍需事务记录 | 当前无完整checkpointbridge |

P3指 `v0_2/plant/controlled_loop.py:199/214` 与旧 `SafetySupervisor.evaluate` 的已存在顺序，不是新造“已资格化第三方案”。未找到已证明与R4.6等价的其他P3实现。

推荐P1只因能走**明确、有限、另行批准的补充路线**，不因为现有合同已足够。P2会改变冻结publictiming，不能为消除视觉差异强行采用。P1新增Safety时相trace不在旧R4.6 oracle里，需独立规范检查。

## 6. 两种internal record身份提案

PRE_SAFETY_CONTRIBUTION_RECORD绑定transaction/schedulercycle/phase=PRE、旧source/obligation/watch、trackingstate-at-evaluation、15A映射、evidencecommit、PRErecord和Safetydecision关联。POST_FINAL_PUBLICATION_RECORD绑定同transaction/phase=POST、实际新PLCcommand/cycle、真实lifecycle、finalstate、PRElink、latch/publicationidentity。

PRE不能引用未来PLCcycle ID；scheduler cycle与PLC cycle不同。SafetyDecision尚未建立时，关联用预留identity或单独immutablebinding，不能修改PRE事实。二种record不是二种新public states；PRE不增加publictransition或真实progressmilestone。

## 7. 八个时间语义问题逐条回答

| 问题 | 现有依据或明确提案 |
| --- | --- |
| 1 PREsuspected真实吗 | 是，原count/progress字段+冻结source推出；不是格式化状态。原run无独立PRE Safety日志 |
| 2 可供本拍Safety吗 | generic15A mapping有依据；命名PREcut消费须另批T02/T03/T06 |
| 3 POSTsteady能不删PRE吗 | 拟批准T04/T05允许；linked lifecycle解释改变，旧Safety不回写 |
| 4 PRE贡献何时停止适用 | 拟T06仅对所绑定Safetydecision/cycle有效，不能作为下一决定输入；历史record永久保留 |
| 5 下一cycle重新计算吗 | 拟T06从届时enrolledcontext/qualifiedmeasurement生成新contribution，旧score不借用 |
| 6 可无限保持旧DEGRADED吗 | 不可复制旧nonlatchedPRE作为当前理由；独立Safetydwell/recovery可能继续顶层state，不能绕过15 |
| 7 POST可清其他理由吗 | 不可，14/15A权限禁止POST直接写Safety；all-reason/latch保持 |
| 8 POST失败怎么办 | 拟T09保留真实PRE/Safety/PLCcommits、标内部incomplete/invalidcontinuation，不虚构final、不重赚分、不擅自重发command |

适用范围不是新hardwaretimeout/holdtimer。若调度中断，不能猜一个安全pumpaction；existingenvelope validity、sensor invalidity、独立latchedFAULT与UP02继续约束。新contribution为NORMAL identity也不保证下一次顶层Safety立刻NORMAL，原dwell/recovery与其他理由仍生效。

## 8. 最小草案范围与防止语义偷换

独立草案T01–T10只覆盖PRE/POST身份、偏序、decision-bound contribution使用、no retroactive rewrite、latch/all-reasons、provenance、不可回滚phase和verification gates。没有新tracking阈值/timer/速度限制/state/reset权限。

提案必须被明确批准，不能默默修改Contract15A解释。若finalstate/event/count、qualification/evidence/reference时钟被改，或把本来只诊断的PRE state映成新的severity，必须FROZEN_SEMANTIC_REOPEN_REQUIRED。本次尚未发现必然要求这种实质改动，因此主裁决是有限timing clarification required，而不是强行semantic reopen。

## 9. 16原路径分类（身份和原status不回写）

| ID | 原路径 | 本次完整phase比较分类 |
| --- | --- | --- |
| PF-01 | withdrawal before evidence | CONDITIONAL_ON_TIMING_CLARIFICATION |
| PF-02 | withdrawal after evidence | CONDITIONAL_ON_TIMING_CLARIFICATION |
| PF-03 | same-tick confirmation | CONDITIONAL_ON_TIMING_CLARIFICATION |
| PF-04 | State U suspension | CONDITIONAL_ON_TIMING_CLARIFICATION |
| PF-05 | State U reissue | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-06 | reversal | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-07 | invalid outage | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-08 | valid recovery | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-09 | deferred demand | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-10 | resolved_pair creation | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-11 | progress_pair creation | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-12 | startup reference establishment | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-13 | no stale confirmation | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-14 | watch lineage | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-15 | sample single-credit | UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST |
| PF-16 | confirmed latch retention | CONDITIONAL_ON_TIMING_CLARIFICATION |

STATICALLY_PROVED=0；CONDITIONAL_ON_TIMING_CLARIFICATION=5；UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST=11；CONFLICT_WITH_FROZEN_SEMANTICS=0。这是新增fullphase比较分类，原C各conditional localproof/status逐项原样嵌入矩阵，未改判。

每条矩阵分别覆盖reference before/after、PRE state、Safety贡献、PLC边界、POSTtransition/final、provenance、evidence count、confirmed、公事件数量与decision equivalence。不是序列图PASS。

first fresh sample after restart作为额外UP05 extension obligation，单列EXTRA-RESTART-01，不替换16路径/不冒充第17原路径；R4.6未有reset/restart oracle，另登记新预期、不能借原PASS。

## 10. 后续差分资格设计（未执行）

先C2独立批准有限timing草案/冻结身份，不修改旧Contract15A。再另批C3split测试实现/adapter/harness和预登记。严格相同frozen输入，oracle为原candidate；原ST/U/v2/ITQ预期不动。

对比不能仅state字符串：每tick W/D/A/E/K/O/U/C/T/V、atomic refs/sourceIDs/time、progress/deficient/consumption次数、watch/latch、originalpublicevent数/时点、POSTzero-credit逐项一致。PRE/Safety新增record须独立对批准条款、frozencriteria和真实旧command归属验证，不能run split后保存golden。

Offline comparison的获准command序列经声明的PLC-owned replay stub在POSTboundary给出，不能PRE偷读未来；这只验证输入相同下的tracking调度语义，不是闭环真实PLC控制资格。后续integration/scheduler/hardware gates仍分开。reference observer若需提取原内部PRE切面，须单独冻结只读instrumentation source及其非干扰依据，不改reference算法；当前未创建observer。

C3输入/expected/comparator/source/hash/cut/causal-prefix/repeat/STOP规则全部封包后单独批准执行。source/fixture漂移、真实FAIL、doublecredit、prefix/non-determinism/incomplete证据均立即STOP，同次不改试卷/候选重跑PASS。旧成绩不借。

## 11. 剩余blockers与下一批准点

具体剩余：timing draft尚未批准；16-path splitimplementation+comparator尚未冻结/差分验证；startup/reissue/outage/recovery/reference creation及singlecredit映射仍有实际验证缺口；POSTfailure/reconciliation与firstfresh source/window/time/PLC连续性仍待实现前验证；硬件仍无校准资格。

UP01/02/03/05原批准政策保持不重开。下一步只请求C2审阅T05/T06/T09的不同cut、decision使用范围和不可回滚边界；批准C2不自动授权C3执行，更不授权productionport。

## 12. Integrity / STOP

行为executions=0，candidate executions=0；只读取已有R4.6证据并做source静态推导；未运行tests/qualification/modelsolver、未生成新candidate/fixture、未改production/contracts、未commit/push。原Git-visible 2,195文件保护，无DSX/Twin修改。完整源/证据raw/canonical在registration/evidence绑定，新文件hash最终回读输出，evidence自身hash不自引用。

Candidate=REQUALIFIED_FOR_FROZEN_FIXTURE_DOMAIN；UP04仍UNRESOLVED；CONTRACT_CLARIFICATION_APPROVED=NO；SPLIT_EQUIVALENCE_PROVED=NO；FULL_RUNTIME_SPEC_FROZEN=NO；CAN_PRODUCTION_PORT_START=NO；REAL_HARDWARE=CALIBRATION_REQUIRED；FULL_P_HISTORY_VALIDATION_AVAILABLE=NO；PHASE6=NO。STOP。

