# R4.7-C2-R1 — Fresh Static Acceptance Report

## Result

Fresh SC-01..SC-12: **12/12 PASS**. Checker-only synthetic cases: **8/8 expected outcomes matched**.
R4_7_C2_R1_GATE=NARROW_PUBLICATION_TIMING_POLICY_FROZEN, subject to final manifest actual-byte verification recorded in evidence.
P1_TIMING_POLICY=APPROVED_FOR_FUTURE_DIFFERENTIAL_QUALIFICATION.

这次只是有限时间政策和静态验收通过：完整runtime未冻结，UP04完整split等价未证明，C3harness创建/执行未授权。大白话：修的是“中文英文该怎么判”的检查器，不是改控制算法或Safety规则来过关。

## New independent execution

ID=c2-r1-static-e7ca180e73fa4543a59c310f73ef0c3b
startUTC=2026-10-10T19:08:25.138489+00:00; endUTC=2026-10-10T19:08:25.306060+00:00.
Client timezone Asia/Singapore (UTC+8): 2026-10-11 03:08:25.
Source=b459f9bfb5dd7bcff9fee67fd83de1d838b95bce5d9e5272024da6d02168ce97; checker freeze RAW=ecc57584c4a1a4a6f96734f34fca4083e8221dd6526868989ac13955738d670d.
Returncode0；source_drift_before/after=[]；checker_and_freeze_unchanged=true。
All12 checks freshly evaluated; no borrowed old results, no same-execution repair/retry. Raw stdout SHA=390ca603c864fa5fcb82a27c3b4ad2d0301e74b662258d6c5646d45fc0cb888e; stderrSHA=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855. Full stdout and start/end saved in versioned runJSON.

## Complete results

| ID | Result | Criterion |
| --- | --- | --- |
| SC-01 | PASS | 10clause IDs/order and exact document wording; versioned PRE/POST/internalmetadata required fields defined |
| SC-02 | PASS | All source raw/canonical bindings including approvedC1/authorization and newnormative document match |
| SC-03 | PASS | Exact U witness and derivedPRE vsobservedPOST distinction preserved |
| SC-04 | PASS | PRE input expiration separated fromSafety/envelope/latch protection; no crosscyclecopy |
| SC-05 | PASS | UNKNOWNissue/fourcommits/stalehistoricalpublicstate/noautoenrollment andimplementationhold explicit |
| SC-06 | PASS | Crossreference through reserved identities/separate immutablebinding, notrecord mutation |
| SC-07 | PASS | Only actual frozen six publictrackingstates; metadata enum notpublicstate |
| SC-08 | PASS | Frozen15Aseverity/reasons/restrictions preserved; no hardwareparameter ornewreason assigned |
| SC-09 | PASS | SafetybeforePLC andnofuturecommandpermission retained |
| SC-10 | PASS | Allreason/latch retention required; POST noSafetywrite |
| SC-11 | PASS | All16originalPFIDs/rows/classifications preserved bytecontent semantically; historicalmatrix unmodified |
| SC-12 | PASS | Noequivalence/runtime/behaviorauthorizationpromotion |

原失败C2依然11/12、NOT_FROZEN_STATIC_ACCEPTANCE_FAILED；新12/12只属于此executionID。没有把旧文件改成PASS。原checker来源是已定位的会话inline代码，转录证据/精确SHA与SC04-only差异见独立repair报告。

## Policy-byte finalization

Only after fresh12/12, create new R1 policy document/registration/manifest/evidence. New administrative status and reference names do not change T01–T10 clause wording or schema. Final static byte comparison must bind:
- All10 clause texts and3schemas equal approved stoppedregistration.
- All16 PF IDs/paths/originalrows/classifications equal C1; no PROVED promotion.
- Repairedchecker andcheckerfreeze unchanged.
- Protected STOP/C1/R46/contracts/runtime/DSX/Twin source bytes unchanged.
- Final manifest references raw/canonical identities match actual files.

This final integrity verification is not another repaired/rerun of SC01..SC12, and does not borrow any old PASS. Any integrity failure invalidates final freeze.

## 16PF unchanged and remaining work

- PF-01 withdrawal before evidence: CONDITIONAL_ON_TIMING_CLARIFICATION; policy dependency approved, refinement still required.
- PF-02 withdrawal after evidence: CONDITIONAL_ON_TIMING_CLARIFICATION; policy dependency approved, refinement still required.
- PF-03 same-tick confirmation: CONDITIONAL_ON_TIMING_CLARIFICATION; policy dependency approved, refinement still required.
- PF-04 State U suspension: CONDITIONAL_ON_TIMING_CLARIFICATION; policy dependency approved, refinement still required.
- PF-05 State U reissue: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-06 reversal: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-07 invalid outage: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-08 valid recovery: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-09 deferred demand: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-10 resolved_pair creation: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-11 progress_pair creation: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-12 startup reference establishment: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-13 no stale confirmation: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-14 watch lineage: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-15 sample single-credit: UNRESOLVED_REQUIRES_DIFFERENTIAL_TEST; policy dependency approved, refinement still required.
- PF-16 confirmed latch retention: CONDITIONAL_ON_TIMING_CLARIFICATION; policy dependency approved, refinement still required.

Policy wording approval resolves only timing-policy dependency; behavior still requires independent C3 preregistration/differential proof of StateU/reissue/outage/recovery/reference creation/provenance/single-credit. T09 reconciliation/storage/unknownissued/idempotent recovery remains IMPLEMENTATION_HOLD. Nohardwarecalibration orfullPhistoryrecovery claim.

## Integrity and STOP

Candidate=REQUALIFIED_FOR_FROZEN_FIXTURE_DOMAIN; UP04fullsplitUNRESOLVED; runtimeNOT_FROZEN; C3creation/executionNO; productionportNO; REAL_HARDWARE=CALIBRATION_REQUIRED; FULL_P_HISTORY_VALIDATION_AVAILABLE=NO; PHASE6=NO; GIT_COMMIT_PUSH=NO.
Behavioral tests/candidate executions/production modifications all0. Static-only program AST/schema/hash checks and synthetic strings were authorized.
STOP after verified versioned package; user must separately authorize C3 preregistration.

