# R4.7-C — Runtime Policy Adjudication & PRE/POST Split Equivalence Refinement

## 1. 当前裁决

`PRE_POST_SPLIT_EQUIVALENCE_REMAINS_UNRESOLVED`。

UP-01/02/03/05按用户本轮授权分别记录为 **FROZEN_REVIEWER_APPROVED_POLICY_ONLY**；R4.7-B原文件和原身份不修改，整个runtime规范未最终冻结。UP-04没有通过。特别是 `PRE_POST_SAFETY_PUBLICATION_SEMANTICS_UNRESOLVED`。

大白话：重启不能洗历史、复位必须由Safety协调、停机不能补算分数，已定。算法拆成前后两段后却可能“Safety这一拍看到疑似故障，最终报告显示平稳”，这个差异尚未获现有合同的时间语义授权。允许POST读context并不能解决已经供给Safety的差异。

本阶段无production implementation、无行为运行、无模型求解器运行、无硬件数字分配、无Git commit/push。R4.6 candidate资格保持不变，生产port仍NO。

## 2. 来源与资格域

权威参考是RAW 453f2f1d02c9aaa845d5222b3ef01da8c1a9db6580268c54674d374d76fa9300的 `v0_2/examples/phase5_r5_2_1r4_5c_lifecycle_engine.py` 及其Startup→Directional→Deferred→Paired→base父链，不重写候选来生成证明。

R4.6 run manifest RAW 68dc4ef177146e64132e522e519bec2721cbf84f2610a5e2dd3457ddf1085d49，canonical 794fc58cdecf1fb2a1a47f17e2ba181e3153f46a7be34be0e07ce15bb3f5b85d。Policy A/v2/U canonical分别d86eaa…167082、8c793b…f8976、2dbc47…cf707。本阶段重新复算R4.7-B绑定的23项source/JSON身份，drift=0，并绑定B三文件与本轮授权附件。

本文source简称lifecycle/startup/paired/directional/deferred/base分别对应上述 `v0_2/examples/` 下 r4_5c_lifecycle / r4_3_startup / r4_paired / r4_2_directional / r4_1_deferred / r_semantic engine。机器包包含完整路径和SHA。候选REQUALIFIED仅覆盖冻结数值软件域；重启/两阶段reset是新授权runtime规范，未被R4.6运行验证，不向旧ST/ITQ回写。

## 3. 四项政策冻结记录（仅此范围）

### UP-01 — OPTION C

必须恢复必要qualified state，并重新资格确认外部权威PLC/source/time/window连续性。A作为存储superset允许以后设计，但即便完整checkpoint也不能略过输入连续性qualification。B的清零新epoch不得冒充unresolved/confirmed状态的透明continuation。

必要state沿用R4.7-B grounded inventory：watch lineage/oldest time、active/completed epoch及directional obligation、paired references、fault evidence/latch/provenance、response_history/consumed source identities、outage/deferred、State U startup context/flag、publication milestone与causal clock/previous observation。nested ID/timestamp/原因保持原子关联。last_command仅在完整权威journal与同一提交切面可证时重建；不能从echo或当前speed重建真实历史。

resolved/progress pair ID依event-list长度、deferred ID依CREATE数量，日志中的身份分配依赖也要保留。当前snapshot不是完整checkpoint。存储布局、原子写实现、CRC/算法格式、日志裁剪未在此选择。

### UP-02 — INVALID_CONTINUATION

checkpoint缺失、损坏、transaction torn，或PLC journal/epoch/time无法核验，必须进入内部INVALID_CONTINUATION。禁止新增tracking evidence、禁止清已知历史/confirmed、禁止自动恢复tracking连续性，独立Safety reasons/latches不受此操作解除。

这是完整性标记，不是第七公开tracking state，不是新Safety FAULT reason，不授权另发泵命令或关PLC。无法恢复的数据不得假装已保留、不得把未知confirmed字段填False；已可核验的历史/独立latch保留。恢复需显式受控重新接纳并满足state和输入资格，具体接口未实现。UNKNOWN/provenance-ambiguous公开状态的时相一致性仍属于UP-04，不随内部标记擅自改变六state定义。

### UP-03 — Coordinated reset transaction

Safety继续拥有Contract15/15A既有显式reset/recovery authority，不能简化成两方“用户点一下都清零”：

```text
RESET REQUEST
 → Safety检查已有reset/recovery eligibility
 → durable unique reset_transaction_id
 → SAFETY_RESET_ACCEPTED
 → qualifier持久关闭目标active confirmed episode
    保留evidence / provenance / consumed source identities
 → 对同一transaction的qualifier ACK
 → Safety最后提交自身latch clear
```

任何完成前crash/ACK失败，Safety FAULT仍latched。Qualifier关闭记录不是Safety commit完成的证据；不得以它自动恢复NORMAL。解除的是目标episode的active confirmed latch，而不是抹去过去confirmed事实。保留其他同时活跃原因，新故障不能被旧reset ACK清掉；sample namespace不复用。

两个组件操作仍不同，只有Safety接受的transaction绑定它们。普通qualifier restart不能清Safety，普通旧Safety.reset_fault调用不能隐含清qualifier全部字段。现有source仅直接清Safety latch（supervisor.py:106），还未实现此协议，本阶段不改它。

唯一ID、目标episode/请求关联、持久完成与ACK是批准语义约束；transport重试、幂等存储实现、日志布局和失败后reconciliation程序仍待设计。若qualifier已ACK而Safety未commit，Safe latch留存，transaction保持待核对，不能静默当全事务完成。不能声称R4.6原候选（没有reset API）已资格化了这个新增运行路径。

### UP-05 — No-back-credit restart

Audit wall clock记录真实elapsed time；qualified response opportunity不是wall clock计时器。未证明连续性期间不得新增credit、不得只凭downtime制造fault或response opportunity；watch/evidence/latch不清零，也不发明fresh grace。

第一条fresh source sample必须source epoch、window、clock资格、权威PLC command归属全部可证明，才允许评价记功。window跨restart/command effect uncertainty或old/new attribution不明，AMBIGUOUS_NO_CREDIT；context只在其所需配对/身份另有证明时可用，不因“context-only”免除provenance资格。

不能直接将停机后的wall time喂原_expected，也不能任意减去停机时间伪造连续clock。该规则已冻结；具体qualified-time坐标恢复函数尚未给出、更未实现/验证。无新hardware delay/tau/ramp/minΔspeed/sampleperiod/latency/noise/clockaccuracy。

## 4. 两个形式化transition模型

### REFERENCE

设 Q=(W,D,A,E,K,O,U,C,T,V)，依次是watch/方向义务/paired refs/evidence与latch/消费历史/outage/startup/命令与source上下文/时间/publication。m是已release测量，c是离线reference这一tick输入中已经给出的获准command。

`R(Q,m,c,t,p)` 指 **原candidate程序的精确transition**，而不是假定其已经分成两个纯函数。输入使用原冻结profile/classifier。Reference只离线返回tracking record，本身不调用production Safety；比较Safety投影时需明确采用哪一state/time切面。

active && valid && command_changed路径：lifecycle:118–137捕获旧epoch/watch/demand并以旧command和旧issue time替换item；父链评价；_consume；随后lifecycle:144–166以评价后的anchor与新command处理方向；168–188最终公开record。Inactive或invalid路径没有通用旧context替换，父链可能在evaluation前处理当前command。

### SPLIT（关系规格，不是实现）

```text
P(Q,m,J_already_issued) → Q_pre, evidence_commit, pre_contribution, context_token
Safety reduce(pre_contribution, independent reasons/latches) → envelope
PLC(accepted inputs, envelope) → actual approved final c_new
L(Q_pre,c_new,CONTEXT_ONLY(context_token)) → Q_post
publish Q_post
```

P不能读尚未产生的c_new，不用requested/echo/预测PLC output代替。L可读取同measurement的context/reference字段，但不得新增progress credit、fault evidence、confirmation、response-opportunity consumption或第二次source credit。

POST noninterference约束：E_post=E_pre、confirmed_post=confirmed_pre、consumed identities_post=pre、所有新credit_POST=0。合法episode/方向关闭与audit保留按原生命周期处理。Reset transaction是另一个独立批准操作，不插入L用来绕过latch等式。

恢复已经存在的deferred obligation可以在PRE建立其合法context并评价一次，不必等POST新command。但“此刻刚产生新command”的重建不能提前偷读未来。

### 要证明的refinement relation

每个逻辑tick结束 Q_post ~ R(Q,m,c_new,t,p)，比较W/D/A/E/K/O/U/C/T/V及nested paired provenance与milestones；已经声明NON_NORMATIVE的纯allocator命名至多允许保持关系的双射，normative来源/time不变。另需证明Safety reason/severity/restriction与明确授权的15A观察切面一致。

只有内部counters一样、另一独立FAULT掩盖severity差异、增加一个public progress milestone、或把command/sample timestamp移一拍，都不是完整equivalence。本阶段为手工静态程序推理，不是mechanized theorem，也不是行为PASS。

## 5. 16条逐路径refinement matrix

| ID | 路径 | 本地结果 | 尚缺的证明 |
| --- | --- | --- | --- |
| PF-01 | withdrawal before evidence | PROVED_LOCAL_CONDITIONAL | must prove PRE creates identical response-history marker; no publication equivalence claim |
| PF-02 | withdrawal after evidence | PROVED_LOCAL_CONDITIONAL_WITH_PUBLICATION_GAP | CE-01 disproves assumed PRE/POST state equality; Safety temporal permission unresolved |
| PF-03 | same-tick confirmation | PROVED_LOCAL_CONDITIONAL | not proof of future coordinated reset branch; not latch-clearing by withdrawal |
| PF-04 | State U suspension | PROVED_LOCAL_CONDITIONAL_WITH_PUBLICATION_GAP | U registration fixes input and expected slice; PRE SUSPECTED versus final STEADY unresolved |
| PF-05 | State U reissue | UNRESOLVED | need branch-by-branch proof that R parent earns no new credit for every admissible reissue; U frozen boundary establishes only its narrow zero-expected case |
| PF-06 | reversal | PROVED_LOCAL_CONDITIONAL | reference IDs/allocator and recovery flag update side effects require full state relation; Safety/public divergence not solved |
| PF-07 | invalid outage | UNRESOLVED | intermediate hook cancellation/creation order and identity allocation may differ; cannot equate invalidity with do-nothing |
| PF-08 | valid recovery | PROVED_LOCAL_CONDITIONAL | only when command unchanged and restoration uses same refs/clocks; same-cycle commandchanged case unresolved |
| PF-09 | deferred demand | UNRESOLVED | two command contexts at one tick may produce extra events/IDs; no full commute proof |
| PF-10 | resolved_pair creation | UNRESOLVED | pre-baseline may not exist in R using newcommand; for two possible commands exact paired state differs; no allowed collapse proven |
| PF-11 | progress_pair creation | PROVED_LOCAL_CONDITIONAL | only if reason and IDs/old-pair selection identical; pair creation is not evidence, no universal branch proof |
| PF-12 | startup reference establishment | UNRESOLVED | must prove parent eval has zero effects on new evidence/opportunity and exactly same startup/pair/public milestone; general proof absent |
| PF-13 | no stale confirmation | PROVED_POST_NONINTERFERENCE_BY_MODEL_CONSTRAINT | future branch equivalence and timebase qualification still needed; no new grace/delay allowed |
| PF-14 | watch lineage | PROVED_LOCAL_CONDITIONAL | pair/deferred event lengths and new IDs require state relation beyond counters; invalid/recovery ordering unresolved |
| PF-15 | sample single-credit | PROVED_POST_NONINTERFERENCE_BY_MODEL_CONSTRAINT | do not infer universal source-delivery theorem from candidate ledger; identity bridge and restart guards separately required; first inactive-epoch consumption compatibility unresolved |
| PF-16 | confirmed latch retention | PROVED_LOCAL_CONDITIONAL | coordinated reset is new runtime policy outside R4.6 replay domain, not newly tested candidate capability |

每条的precondition、原program transition、split transition及精确source区间在独立proof matrix JSON中。PROVED_LOCAL_CONDITIONAL只证明列出的guard与state切面下的局部代换；PROVED_POST_NONINTERFERENCE_BY_MODEL_CONSTRAINT是对拟议L约束本身的证明，不是证明不存在的实现，更不是整个R4.6 suite通过。

关键正面结果：旧合法measurement独立满足confirmation时，PRE可照原规则确认，POST不能清；active valid撤回可以在旧evaluation后复用_retained，不把count=0误当无历史；新pair可将同sample用作context而不因此宣称有真实progress；already-enrolled unchanged-command recovery允许PRE沿保留refs主动评价。

关键未闭合：State U reissue在startup:73–143先用当前command及measurement重建context，之后父链仍评价；invalid/recovery在deferred:135–153中有command-sensitive前置处理；initial resolved/startup baseline在paired:151–159依据当前command-measured误差建立。P旧command建立的baseline可能在R新command路径根本不存在，不能让L偷偷把它“当诊断删掉”。必须证明每个guard/ID/时钟/公开milestone，不能用CONTEXT_ONLY标签代替证明。

## 6. CE-01：PRE Safety与POST public不相同的静态见证

这是读取已有冻结输入/断言并推导source分支，**没有新执行**：

| 切面 | 冻结State U对照及source推导 |
| --- | --- |
| 旧context | 已有数值fixture：command0.7、measured0.5、issue0，1.2s valid sample同tick withdrawal0.5 |
| PRE evaluation | U-01/02/03要求旧measurement先合法评价、count由0到1、measured progress0、not confirmed；paired:239–243产生SUSPECTED |
| POST withdrawal | U-04/05/06要求direction inactive、history/provenance保持、flagTrue；lifecycle:146–150在未progress且未confirmed时最终STEADY |
| 冻结final期望 | U registration `expectations.post_withdrawal_public_state` 精确冻结STEADY_TRACKING |
| 15A投影 | PRE SUSPECTED→DEGRADED/ACTUATOR_TRACKING_SUSPECTED；final STEADY→NORMAL identity/no tracking reason |

由此 refute “PRE contribution总等于reference final state contribution”的断言。上述0.7/0.5/1.2s仅引用既有冻结fixture，不是新硬件参数、不生成新试卷、不报告runtime行为FAIL。

相同旧评价前缀在继续旧demand或撤回demand的合法command后缀下，final public可以不同，PRE在禁止读futurecommand的接口下不能从旧测量 alone得到最终state。这是该拟议接口的信息边界论证，不声称相同完整部署PLC状态能产生两个输出。

CONTEXT_ONLY能阻止重复赚分，但不能取消Safety已经读取的PRE贡献。更高独立FAULT掩盖最终state差异也不能证明理由集合一致；第二次Safety/PLC求fixed point改变cycle，不获本阶段授权。用requested或echo预测withdrawal仍不等于实际PLC输出。

## 7. Contract15A publication adjudication

15A:9已有tracking_internal_state、tracking_epoch_id、tracking_evidence_id，可容纳独立身份的结构来源；15A:13–20及24定义每种state的意义和severity；15A:28要求所有**currently active**理由保持；15A:30要求Safety-before-PLC。

但文件未明确授权“同一logical tick，PRE suspected已供Safety，POST无方向final steady，而PRE reason继续作为本拍active contribution”的phase/time合同。存在结构ID ≠ 已授权时间切面差异。也没有明确证明它必然禁止所有分相接口：SafetyState可因其他channel不同于tracking state，不能误要求全局SafetyState与tracking state字面相等。

因此结论是 **PRE_POST_SAFETY_PUBLICATION_SEMANTICS_UNRESOLVED**，不是贸然认定FROZEN_CONTRACT_CHANGE_REQUIRED，也不是认为差异默认允许。要另行裁决观察时间切面、active reason寿命及final publication归属，或给出不引入差异的完整refinement证明。若最终需要改15A的meaning/mapping才成立，须单独重开合同，本阶段不改、不先选解决方案。

## 8. CONTEXT_ONLY的精确边界

允许原source ID/time及measured值用于已批准的pair/startup/direction context构造；pair创建不是自动progress credit。禁止调用另一轮super.update(t)、禁止伪造t+epsilon、禁止重新_consume、禁止清ledger让旧样本变fresh、禁止新direction使用旧样本加evidence。

Direction/pair ID建立必须保留source意义，不能伪称measurement是在新command后取得。Pair只作为新义务reference时，response lower bound按原startup/directional规则；保留oldest watch不等于向新方向套用旧response age。对未知provenance的数据，CONTEXT_ONLY也不是truth权限升级。

POST建立初始context而reference同tick还执行父评价的路径，需证明后者新增credit确实为0才可消去。Frozen U单个reissue expected_motion0能证明其窄case，不能外推全部reissue/outage路径。

## 9. 剩余闭环项及状态边界

四policy决定已记录，不再把UP-01/02/03/05重新抛回“选方案”。仍待审/证明的是：

- UP-04-P：PRE contribution与POST final public的合法time/phase观察关系。
- UP-04-R：startup/State U reissue、invalid/recovery/deferred、resolved/progress reference创建的完整guard/state等价。
- 实现前细化：two-phase reset持久提交/失败reconciliation，以及qualified-time/input bridge；不可声称本阶段已实现或硬件qualified。

B1有approved政策基础，checkpoint/source continuity与reset仍未实现/验证，不标运行blocker已关闭；B2 fullrefinement未关闭；B3schema方向保持、硬件数据仍CALIBRATION_REQUIRED。B4仅后续原15A窄接入，旧raw mismatch+2s不得变第二detector。所有channel理由和PLC唯一finalcommand authority不变；无Phase6。

## 10. 完整性及停止

本阶段开始保护Git-visible 2,191文件，包括tracked与非ignored untracked；忽略缓存不宣称全盘hash。仅新增report、policy registration、proof matrix、evidence四文件。candidate、production、Safety、PLC、measurement、profile、Contract06/07/14/15/15A、ITQ、Startup、DSX保持原bytes；HEAD未变。行为tests=0、candidate executions=0、formal solver executions=0，Git commit/push=NO。

Raw按真实文件bytes；JSON canonical=UTF-8/ensure_ascii=False/sort_keys=True/separators=(',',':')。附属hash在evidence与最终响应，evidence不嵌入自身hash；无自引用循环。

candidate=REQUALIFIED_FOR_FROZEN_FIXTURE_DOMAIN；CAN_PRODUCTION_PORT_START=NO；FULL_P_HISTORY_VALIDATION_AVAILABLE=NO；REAL_HARDWARE=CALIBRATION_REQUIRED；PHASE6=NO。R4.7-D whole-runtime final freeze尚不具备条件。STOP，等待用户审阅UP-04 publication/refinement，不进入实现。

