"""R4.5 offline candidate; R4.3B remains an immutable failed baseline."""

from v0_2.examples.phase5_r5_2_1r4_3_startup_engine import StartupTrackingQualifier
from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation


class WithdrawalCancellationTrackingQualifier(StartupTrackingQualifier):
    """Cancel only unproven, withdrawn no-motion demand after resolved baseline."""

    def update(self, item):
        if not isinstance(item, ReleasedObservation):
            raise TypeError("Only released observations may enter the qualifier")
        if self.last_time_ns is not None and item.time_ns <= self.last_time_ns:
            raise ValueError("Strictly increasing causal observations required")
        anchor = self.resolved_pair
        if (anchor is not None and self._valid(item)
                and self.measurement_unavailable_since_ns is None
                and not (self.deferred_demand and self.deferred_demand.deferred_demand_active)
                and self.oldest_unresolved_demand_ns is not None
                and self.epoch is not None and self.epoch.completion_reason is None
                and not self.confirmed_latched and self.carried_suspicion_evidence == 0
                and self.suspected_since_ns is None and not self.qualified_progress_seen
                and self.last_command is not None and item.plc_command != self.last_command
                and abs(self.last_command - anchor.resolved_command_anchor) >= self.material_delta
                and abs(item.plc_command - anchor.resolved_command_anchor) < self.material_delta
                and abs(item.measured_speed - anchor.resolved_measurement_anchor) < self.minimum_motion):
            reason = "RESOLVED_BASELINE_DEMAND_CANCELED_NO_EVIDENCE"
            self._close_epoch(item, reason)
            self.watch_events.append({
                "time_ns": item.time_ns, "event": "CANCEL",
                "watch_id": f"motion-watch:{self.watch_number}", "reason": reason,
            })
            # Historical events and resolved matched anchors remain untouched.
            # The inherited evaluator publishes state from the cleared obligation;
            # no output-only STEADY patch and no invented measured resolution.
            self.epoch = None
            self.progress_pair = None
            self.oldest_unresolved_demand_ns = None
            self.direction = None
            self.directional_obligation = None
            self.latest_demand = 0.0
        return super().update(item)
