"""R4.5C offline lifecycle candidate; frozen parents and production are untouched."""

from dataclasses import asdict, replace

from v0_2.examples.phase5_r5_2_1r4_3_startup_engine import StartupTrackingQualifier
from v0_2.examples.phase5_r5_2_1r4_2_directional_engine import DirectionalTrackingObligation
from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation


class WatchLifecycleTrackingQualifier(StartupTrackingQualifier):
    """Evaluate old interval-end measurements before applying command transitions.

    Plain ReleasedObservation uses the certified frozen delayed-actuator fixture
    domain. The optional provenance explicitly rejects known post-command data.
    This is not a hardware clock/provenance adapter.
    """

    def __init__(self, profile, classifier):
        super().__init__(profile, classifier)
        self.response_history = []
        self.lifecycle_events = []
        self.consumed_samples = set()
        self.previous_observation = None
        self.episode_progress = False
        self._evaluation_allowed = True

    def _valid(self, item):
        return self._evaluation_allowed and super()._valid(item)

    def _process_invalid(self, item):
        if self._evaluation_allowed:
            super()._process_invalid(item)

    def _process_recovery(self, item):
        return super()._process_recovery(item) if self._evaluation_allowed else False

    def _start_epoch(self, item, direction, reason):
        retained = self.oldest_unresolved_demand_ns is not None
        if retained and self.epoch is None:
            reason = 'REISSUE_RETAINED_HISTORY'
        prior_pair = self.progress_pair
        progress = self.episode_progress
        super()._start_epoch(item, direction, reason)
        if retained and reason == "REISSUE_RETAINED_HISTORY":
            self.progress_pair = prior_pair or self.progress_pair
            self.qualified_progress_seen = progress
            self.directional_obligation = DirectionalTrackingObligation(
                direction, item.command_timestamp_ns, item.plc_command,
                self.resolved_pair.resolved_anchor_pair_id if self.resolved_pair else "startup",
                self.progress_pair.progress_pair_id if self.progress_pair else None,
            )

    def _resolve(self, item):
        super()._resolve(item)
        self.episode_progress = False

    def _consume(self, item, record, epoch, start, demand):
        if epoch is None or epoch.completion_reason is not None or start is None:
            return
        opened = self._response_open(epoch.epoch_start_ns, demand)
        key = (self.watch_number, epoch.tracking_epoch_id, item.measurement_record_id)
        if (record['valid'] and opened is not None
                and item.sample_ns >= opened - self.release_delay_ns
                and key not in self.consumed_samples):
            self.consumed_samples.add(key)
            self.response_history.append({
                'event': 'QUALIFIED_RESPONSE_OPPORTUNITY_CONSUMED',
                'logical_episode_id': f'motion-watch:{self.watch_number}',
                'directional_obligation_id': epoch.tracking_epoch_id,
                'source_measurement_record_id': item.measurement_record_id,
                'sample_ns': item.sample_ns, 'release_ns': item.release_ns,
                'evaluation_tick_ns': item.time_ns, 'watch_start_ns': start,
                'old_command': item.plc_command,
                'command_timestamp_ns': item.command_timestamp_ns,
                'matched_reference_ids': [record['resolved_anchor_pair_id'], record['progress_pair_id']],
                'eligibility_open_ns': opened,
            })

    def _retained(self):
        return (self.confirmed_latched or self.carried_suspicion_evidence > 0
                or self.suspected_since_ns is not None or self.episode_progress
                or any(e['logical_episode_id'] == f'motion-watch:{self.watch_number}'
                       for e in self.response_history))

    def _withdraw(self, item):
        retained = self._retained()
        self._close_epoch(item, 'DIRECTION_WITHDRAWN_HISTORY_RETAINED' if retained else
                          'DIRECTION_WITHDRAWN_NO_RETAINED_HISTORY')
        self.lifecycle_events.append({'time_ns': item.time_ns,
            'event': 'CLOSE_DIRECTIONAL_OBLIGATION', 'history_retained': retained,
            'watch_id': f'motion-watch:{self.watch_number}'})
        self.epoch = None
        self.direction = None
        self.directional_obligation = None
        self.latest_demand = 0.0
        if retained:
            if self.resolved_pair is None:
                self.startup_demand_suspended = True
        else:
            self.watch_events.append({'time_ns': item.time_ns, 'event': 'CANCEL',
                'watch_id': f'motion-watch:{self.watch_number}',
                'reason': 'WITHDRAWN_WITHOUT_QUALIFIED_HISTORY'})
            self.oldest_unresolved_demand_ns = None
            self.progress_pair = None
            self.startup_observation = None
            self.episode_progress = False

    def update(self, item, *, provenance='CERTIFIED_INTERVAL_END'):
        if not isinstance(item, ReleasedObservation):
            raise TypeError('Only released observations may enter the qualifier')
        if self.last_time_ns is not None and item.time_ns <= self.last_time_ns:
            raise ValueError('Strictly increasing causal observations required')
        if provenance not in ('CERTIFIED_INTERVAL_END', 'POST_COMMAND_EFFECT', 'UNKNOWN'):
            raise ValueError('Unknown measurement provenance classification')
        entering_state = self.state
        transitions_before = len(self.transitions)
        active = self.epoch is not None and self.epoch.completion_reason is None
        epoch = replace(self.epoch) if active else None
        start = self.oldest_unresolved_demand_ns
        demand = self.latest_demand
        command_changed = self.last_command is not None and item.plc_command != self.last_command
        valid = super()._valid(item)
        duplicate = item.measurement_record_id in {e['source_measurement_record_id'] for e in self.response_history}
        old_context = item
        old_attribution = valid and not duplicate and provenance == 'CERTIFIED_INTERVAL_END'
        if command_changed:
            old_attribution = old_attribution and item.sample_ns <= item.command_timestamp_ns
        # Evaluate an entering obligation using its prior released command. The
        # parent performs its unchanged measured progress/fault qualification.
        if active and command_changed and valid:
            prior = self.previous_observation
            old_context = replace(item, plc_command=self.last_command,
                                  command_timestamp_ns=prior.command_timestamp_ns)
        self._evaluation_allowed = not valid or old_attribution
        try:
            record = super().update(old_context)
        finally:
            self._evaluation_allowed = True
        self._consume(old_context, record, epoch, start, demand)
        if valid and not old_attribution:
            self.state = 'TRACKING_FAULT_CONFIRMED' if self.confirmed_latched else entering_state
        if record['qualified_progress'] and self.oldest_unresolved_demand_ns is not None:
            self.episode_progress = True
        if active and command_changed and valid:
            anchor = (self.resolved_pair.resolved_command_anchor if self.resolved_pair else
                      self.startup_observation.measured_speed)
            net = item.plc_command - anchor
            if abs(net) < self.material_delta and not self.confirmed_latched:
                if self.oldest_unresolved_demand_ns is not None:
                    self._withdraw(item)
                self.state = 'TRACKING_PROGRESS' if record['qualified_progress'] else 'STEADY_TRACKING'
            elif abs(net) >= self.material_delta and not self.confirmed_latched:
                direction = 1 if net > 0 else -1
                if self.epoch is None or self.epoch.completion_reason is not None or direction != self.direction:
                    reason = 'MATERIAL_REVERSAL' if self.epoch is not None else 'REISSUE_RETAINED_HISTORY'
                    self._close_epoch(item, reason)
                    self._start_epoch(item, direction, reason)
                    self.state = 'HANDOFF_PENDING'
                else:
                    self.epoch.latest_command = item.plc_command
                    self.latest_demand = max(self.latest_demand, abs(net))
                    self.epoch_events.append({'time_ns': item.time_ns, 'event': 'SAME_DIRECTION_UPDATE',
                        'epoch_id': self.epoch.tracking_epoch_id,
                        'oldest_unresolved_demand_ns': self.oldest_unresolved_demand_ns})
            self.last_command = item.plc_command
        # A retained inactive episode reissues through the unchanged parent start
        # hook; supply the new direction's causal lower bound without resetting age.
        self.previous_observation = item
        del self.transitions[transitions_before:]
        if self.state != entering_state:
            self.transitions.append({'time_ns': item.time_ns, 'from': entering_state,
                'to': self.state, 'measurement_record_id': item.measurement_record_id})
        record.update(state=self.state, plc_command=item.plc_command,
            valid=valid, measured_speed=item.measured_speed,
            measurement_attribution='OLD_OBLIGATION' if active and old_attribution else 'NO_OLD_CREDIT',
            epoch_id=self.epoch.tracking_epoch_id if self.epoch else None,
            epoch_expected_direction=self.epoch.expected_direction if self.epoch else None,
            directional_obligation=asdict(self.directional_obligation) if self.directional_obligation else None,
            watch_id=f'motion-watch:{self.watch_number}' if self.oldest_unresolved_demand_ns is not None else None,
            oldest_unresolved_demand_ns=self.oldest_unresolved_demand_ns,
            progress_pair_id=self.progress_pair.progress_pair_id if self.progress_pair else None,
            gross_command_demand=item.plc_command-self.resolved_pair.resolved_command_anchor if self.resolved_pair else None,
            startup_demand_suspended=self.startup_demand_suspended,
            opportunity_consumed=any(e['logical_episode_id']==f'motion-watch:{self.watch_number}'
                for e in self.response_history) and self.oldest_unresolved_demand_ns is not None,
            history_retained=self.oldest_unresolved_demand_ns is not None,
            current_direction_active=self.epoch is not None and self.epoch.completion_reason is None)
        return record

    def snapshot(self):
        result = super().snapshot()
        result['response_history'] = list(self.response_history)
        result['lifecycle_events'] = list(self.lifecycle_events)
        return result
