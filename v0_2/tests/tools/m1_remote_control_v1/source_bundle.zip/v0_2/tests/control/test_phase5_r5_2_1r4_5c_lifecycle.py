"""Executable predicates for immutable R4.5B ST-01..16, not a new ITQ golden."""
import json
from dataclasses import asdict, replace
from pathlib import Path

import pytest

from v0_2.examples.phase5_r5_2_1r4_5c_lifecycle_engine import WatchLifecycleTrackingQualifier
from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation
from v0_2.examples.phase5_r5_2_1r_validation import synthetic

ROOT = Path(__file__).resolve().parents[3]
load = lambda path: json.loads((ROOT / path).read_text(encoding='utf-8'))
REG = load('phase5_r5_2_1r4_5b_watch_retention_semantics_registration.json')
PROFILE = load('phase5_r5_2_2_fixture_tracking_profile.json')
CLASSIFIER = load('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']


def inputs(case):
    definition = next(x for x in REG['semantic_test_definitions'] if x['id'] == case)
    data = definition['input']
    rows = [dict(x) for x in data.get('rows', data.get('base_rows', []))]
    if case == 'ST-12':
        rows = [asdict(x) for x in synthetic(PROFILE, {0: .7, 1400000000: .5, 2600000000: .7},
                                            duration_ns=4000000000, initial_speed=.5)]
    elif case == 'ST-13':
        # Instantiate the registered genuine-progress precondition, no state seeding.
        rows = inputs('ST-03')
        rows[3]['measured_speed'] = rows[4]['measured_speed'] = .54
    elif case == 'ST-15':
        rows = load(data['source'])['observations']
    elif case == 'ST-16':
        # Prior genuine consumed history is a registered semantic precondition.
        # Keep the reference fixture's outage/reversal suffix byte-for-byte values.
        rows = inputs('ST-02')[:-1] + [dict(inputs('ST-02')[-1], plc_command=.8,
                                          command_timestamp_ns=200000000)]
        rows += [dict(x) for x in load(data['source'])['observations'] if x['time_ns'] >= 800000000]
    if case == 'ST-09':
        rows[-1].update(sample_ns=rows[-2]['sample_ns'],
                        measurement_record_id=rows[-2]['measurement_record_id'])
    if 'append_command_at_ns' in data:
        tick = data['append_command_at_ns']
        rows.append(dict(rows[-1], time_ns=tick, sample_ns=tick, release_ns=tick,
                         plc_command=data['append_command_value'], command_timestamp_ns=tick,
                         measurement_record_id='semantic-reissue', measured_speed=data['measurement_at_command']))
    return rows


def replay(case, rows=None):
    rows = inputs(case) if rows is None else rows
    q = WatchLifecycleTrackingQualifier(PROFILE, CLASSIFIER)
    for row in rows:
        provenance = 'POST_COMMAND_EFFECT' if case == 'ST-08' and row['time_ns'] == 600000000 else 'CERTIFIED_INTERVAL_END'
        q.update(ReleasedObservation(**row), provenance=provenance)
    return q.snapshot()


def checks(case, result):
    records = result['records']; last = records[-1]
    starts = [x for x in result['watch_events'] if x['event'] == 'START']
    consumed = result['response_history']
    if case in ('ST-01', 'ST-04', 'ST-06'):
        return {'closed': not last['history_retained'], 'no_active_direction': not last['current_direction_active'],
                'steady': last['state'] == 'STEADY_TRACKING', 'no_consumed': not consumed,
                'no_fault': last['carried_suspicion_evidence'] == 0}
    if case in ('ST-02', 'ST-03', 'ST-07'):
        out = {'consumed': bool(consumed), 'retained': last['history_retained'],
               'inactive': not last['current_direction_active'], 'one_watch': len(starts) == 1}
        if case == 'ST-02':
            out.update(steady=last['state']=='STEADY_TRACKING', counter_zero=last['carried_suspicion_evidence']==0,
                       attribution=last['measurement_attribution']=='OLD_OBLIGATION')
        if case == 'ST-07':
            out['recovery_only'] = consumed[0]['evaluation_tick_ns'] == 800000000
        return out
    if case == 'ST-05':
        return {'no_consumed': not consumed, 'no_progress': not last['qualified_progress'],
                'no_fault_count': last['carried_suspicion_evidence']==0,
                'insufficient': last['state']=='INSUFFICIENT_MEASUREMENT', 'history_not_erased':last['history_retained']}
    if case == 'ST-08':
        return {'no_old_consumed':not consumed, 'no_old_credit':not last['qualified_progress'] and last['carried_suspicion_evidence']==0}
    if case == 'ST-09':
        return {'one_consumed_source':len(consumed)==1, 'no_duplicate_fault_count':last['carried_suspicion_evidence']==records[-2]['carried_suspicion_evidence'],
                'history_retained':last['history_retained']}
    if case in ('ST-10','ST-11'):
        retained = case == 'ST-11'
        return {'watch_start_count':len(starts)==(1 if retained else 2),
                'watch_provenance':last['oldest_unresolved_demand_ns']==(200000000 if retained else 1000000000),
                'no_stale_confirmation':not last['confirmed_latched'],
                'direction_active':last['current_direction_active'],
                'retained_consumed_if_required':not retained or last['opportunity_consumed'],
                'fault_count_not_erased':not retained or last['carried_suspicion_evidence']==records[-2]['carried_suspicion_evidence']}
    if case == 'ST-12':
        at={x['time_ns']:x for x in records}
        return {'actual_prior_evidence':at[1200000000]['carried_suspicion_evidence']==1,
                'paused_evidence_preserved':at[1400000000]['carried_suspicion_evidence']==at[1200000000]['carried_suspicion_evidence'],
                'no_confirmation_during_pause_or_reissue':all(not x['confirmed_latched'] for x in records if 1400000000<=x['time_ns']<=2600000000),
                'one_watch':len(starts)==1,'original_provenance':at[2600000000]['oldest_unresolved_demand_ns']==0,
                'eventual_confirmed':result['confirmed_latched']}
    if case == 'ST-13':
        progress=records[-2]
        return {'genuine_unresolved_progress':progress['qualified_progress'] and progress['history_retained'],
                'retained':last['history_retained'],'inactive':not last['current_direction_active'],
                'unchanged_checkpoint':last['progress_pair_id']==progress['progress_pair_id'],
                'no_fake_progress':not last['qualified_progress']}
    if case == 'ST-14':
        return {'active':last['current_direction_active'], 'retained':last['history_retained'],
                'no_cancel':not any(x['event']=='CANCEL' for x in result['watch_events'])}
    if case == 'ST-15':
        return {'genuine_progress':any(x['qualified_progress'] for x in records),
                'legitimate_resolution':any(x['event']=='RESOLVE' for x in result['watch_events']),
                'progress_before_steady':any(x['state']=='TRACKING_PROGRESS' for x in records[:-1]) and last['state']=='STEADY_TRACKING',
                'consumed_archived':bool(consumed) and not last['opportunity_consumed']}
    if case == 'ST-16':
        invalid=[x for x in records if not x['valid']]
        times={x['time_ns'] for x in invalid}
        return {'prior_consumed':any(x['evaluation_tick_ns']==600000000 for x in consumed),
                'invalid_no_consumed':not any(x['evaluation_tick_ns'] in times for x in consumed),
                'invalid_retains_history':all(x['history_retained'] for x in invalid),
                'existing_reversal':any(x['event']=='SUPERSEDE' for x in result['direction_events']),
                'no_future_credit':all(x['sample_ns']<=x['release_ns']<=x['evaluation_tick_ns'] for x in consumed)}
    raise ValueError(case)


@pytest.mark.parametrize('case',[x['id'] for x in REG['semantic_test_definitions']])
def test_frozen_semantics(case):
    predicates=checks(case,replay(case))
    assert all(predicates.values()), predicates
