"""WCDEV development tests, not frozen ITQ or historical evidence."""
import json
from dataclasses import asdict
from pathlib import Path
import pytest
from v0_2.examples.phase5_r5_2_1r4_5_withdrawal_engine import WithdrawalCancellationTrackingQualifier
from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation
from v0_2.examples.phase5_r5_2_1r_validation import synthetic

ROOT = Path(__file__).resolve().parents[3]
load = lambda p: json.loads((ROOT / p).read_text(encoding='utf-8'))
PROFILE = load('phase5_r5_2_2_fixture_tracking_profile.json')
CLASSIFIER = load('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']


def cases():
    path = 'v0_2/tests/data/tracking_qualification/'
    withdrawal = load(path + 'ITQ-013_dt0p2_input.json')['observations']
    evidence = load(path + 'ITQ-014_dt0p2_input.json')['observations']
    return {
        'WCDEV-01': withdrawal,
        'WCDEV-02': [r for r in evidence if r['time_ns'] <= 800000000],
        'WCDEV-03': [asdict(x) for x in synthetic(PROFILE,
            {200000000: 0.8, 400000000: 0.7}, duration_ns=800000000, initial_speed=0.5)],
        'WCDEV-04': [r for r in withdrawal if r['time_ns'] <= 800000000] +
            [r for r in evidence if r['time_ns'] >= 1000000000],
        'WCDEV-05': withdrawal,
    }


def replay(rows):
    q = WithdrawalCancellationTrackingQualifier(PROFILE, CLASSIFIER)
    for row in rows:
        q.update(ReleasedObservation(**row))
    return q.snapshot()


def checks(name, snapshot):
    r = snapshot['records']
    cancel = [e for e in snapshot['watch_events'] if e['event'] == 'CANCEL']
    starts = [e for e in snapshot['watch_events'] if e['event'] == 'START']
    if name == 'WCDEV-01':
        return {'cancel_once': len(cancel) == 1, 'steady': snapshot['state'] == 'STEADY_TRACKING',
            'no_stale_obligation': r[-1]['watch_id'] is None and r[-1]['epoch_id'] is None and r[-1]['directional_obligation'] is None,
            'no_fake_progress': not any(x['qualified_progress'] for x in r)}
    if name == 'WCDEV-02':
        before = next(x for x in r if x['time_ns'] == 400000000)
        return {'actual_evidence_exists': before['carried_suspicion_evidence'] > 0,
            'evidence_retained': all(x['carried_suspicion_evidence'] >= before['carried_suspicion_evidence'] for x in r if x['time_ns'] >= 600000000),
            'watch_preserved': r[-1]['watch_id'] == before['watch_id'], 'no_cancel': not cancel}
    if name == 'WCDEV-03':
        return {'material_remains': abs(r[-1]['gross_command_demand']) >= PROFILE['TrackingQualificationProfile']['material_command_delta']['value'],
            'watch_active': r[-1]['watch_id'] is not None, 'no_cancel': not cancel}
    if name == 'WCDEV-04':
        reissue = next(x for x in r if x['time_ns'] == 1000000000)
        return {'cancel_once': len(cancel) == 1, 'new_watch': len(starts) == 2 and starts[0]['watch_id'] != starts[1]['watch_id'],
            'causal_reissue_age': reissue['oldest_unresolved_demand_ns'] == 1000000000,
            'no_stale_same_sample_fault': reissue['state'] != 'TRACKING_FAULT_CONFIRMED' and reissue['fault_evidence_before_evaluation'] == 0,
            'persistent_new_stuck_detected': snapshot['confirmed_latched']}
    if name == 'WCDEV-05':
        return {'one_original_anchor': len(snapshot['resolved_pair_events']) == 1,
            'anchors_preserved': all(x['resolved_command_anchor'] == 0.5 and x['resolved_measurement_anchor'] == 0.5 for x in r),
            'no_fake_progress': not any(x['qualified_progress'] for x in r),
            'cleared_checkpoint': r[-1]['progress_pair_id'] is None}
    raise ValueError(name)


@pytest.mark.parametrize('name', ['WCDEV-01', 'WCDEV-02', 'WCDEV-03', 'WCDEV-04', 'WCDEV-05'])
def test_wcdev(name):
    result = checks(name, replay(cases()[name]))
    assert all(result.values()), result
