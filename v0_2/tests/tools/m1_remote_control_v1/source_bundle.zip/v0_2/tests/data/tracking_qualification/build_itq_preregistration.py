"""Build the R4.4 preregistration without importing or executing the tracking engine.

Inputs are generated solely from frozen actuator/profile parameters. This is a
test-data builder, not a candidate oracle. Never derive expectations from output.
"""

from __future__ import annotations

import hashlib
import json
from math import exp
from pathlib import Path

from v0_2.actuators.pump import PumpActuator, PumpActuatorConfig
from v0_2.control.inner_loop import ActuatorCommand

ROOT = Path(__file__).resolve().parents[4]
HERE = Path(__file__).resolve().parent
PROFILE = ROOT / "phase5_r5_2_2_fixture_tracking_profile.json"
CONTRACT = ROOT / "contracts/15A_tracking_safety_policy_amendment.md"
ENGINE = ROOT / "v0_2/examples/phase5_r5_2_1r_semantic_engine.py"
MANIFEST = ROOT / "phase5_r5_2_1r4_4_itq_preregistration.json"
EVIDENCE = ROOT / "phase5_r5_2_1r4_4_itq_preregistration_evidence.json"
REPORT = ROOT / "PHASE5_R5_2_1R4_4_INDEPENDENT_TRACKING_QUALIFICATION_PREREGISTRATION.md"
NS = 1_000_000_000
DT = 200_000_000


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_bytes(canonical(value) + b"\n")


def spec(number, title, hazards, mode, commands, *, initial=.5, duration=6., outage=(), stuck_at=None,
         terminal="STEADY_TRACKING", safety="NORMAL", milestones=(), evidence="RESOLVED",
         direction="CURRENT_NET_DEMAND", watch="RESOLVED_OR_NONE", forbidden=(), mesh="CANONICAL",
         rationale="Accepted tracking semantics, frozen fixture profile, Contract15A and causal released measurement authority."):
    return dict(id=f"ITQ-{number:03d}", title=title, hazards=hazards, mode=mode, commands=commands,
                initial=initial, duration=duration, outage=outage, stuck_at=stuck_at, terminal=terminal,
                safety=safety, milestones=list(milestones), evidence=evidence, direction=direction,
                watch=watch, forbidden=list(forbidden), mesh=mesh, rationale=rationale)


CASES = [
    spec(1,"Normal material rise",["A"],"NOMINAL",[(0,.5),(.2,.7)],milestones=["HANDOFF_PENDING","TRACKING_PROGRESS","STEADY_TRACKING"],mesh="ALL"),
    spec(2,"Normal large fall",["A","E"],"NOMINAL",[(0,.8),(.2,.5)],initial=.8,milestones=["HANDOFF_PENDING","TRACKING_PROGRESS","STEADY_TRACKING"],mesh="ALL"),
    spec(3,"Silent stuck material rise",["B"],"STUCK",[(0,.5),(.2,.8)],terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["HANDOFF_PENDING","TRACKING_FAULT_SUSPECTED","TRACKING_FAULT_CONFIRMED"],evidence="RETAIN_QUALIFIED_FAILURE",watch="UNRESOLVED",mesh="ALL"),
    spec(4,"Frozen sluggish response",["C"],"SLOW_RAMP_0_1",[(0,.5),(.2,.8)],duration=8.,milestones=["HANDOFF_PENDING","TRACKING_PROGRESS","STEADY_TRACKING"],mesh="ALL",rationale="Existing R5.2 test-only SLOW_RAMP_0_1 (0.1 fraction/s, tau 2 s), with qualified released progress before confirmation opportunity."),
    spec(5,"Continuous rise with response",["D","X"],"NOMINAL",[(0,.5),(.2,.6),(.4,.7),(.6,.8)],duration=8.,milestones=["TRACKING_PROGRESS","STEADY_TRACKING"],mesh="ALL"),
    spec(6,"Continuous fall with response",["E","X"],"NOMINAL",[(0,.8),(.2,.7),(.4,.6),(.6,.5)],initial=.8,duration=8.,milestones=["TRACKING_PROGRESS","STEADY_TRACKING"],mesh="ALL"),
    spec(7,"Submaterial increments accumulate while stuck",["F","B"],"STUCK",[(0,.4),(.2,.45),(.4,.5),(.6,.55),(.8,.6), (1.,.65)],initial=.4,duration=8.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["TRACKING_FAULT_SUSPECTED","TRACKING_FAULT_CONFIRMED"],evidence="RETAIN_QUALIFIED_FAILURE",watch="UNRESOLVED",mesh="ALL"),
    spec(8,"Submaterial increments with response",["F","A"],"NOMINAL",[(0,.4),(.2,.45),(.4,.5),(.6,.55),(.8,.6),(1.,.65)],initial=.4,duration=8.,milestones=["TRACKING_PROGRESS","STEADY_TRACKING"]),
    spec(9,"Submaterial alternating jitter",["G"],"NOMINAL",[(0,.5),(.2,.53),(.4,.49),(.6,.54),(.8,.5),(1.,.52),(1.2,.5)],duration=5.,evidence="NO_MATERIAL_OBLIGATION",watch="NONE",forbidden=["TRACKING_FAULT_CONFIRMED","ENDLESS_FRESH_WATCH"]),
    spec(10,"Valid-measurement reversal responds",["H","V"],"NOMINAL",[(0,.5),(.2,.8),(2.,.4)],duration=8.,milestones=["TRACKING_PROGRESS","TRACKING_PROGRESS","STEADY_TRACKING"],mesh="ALL"),
    spec(11,"Stuck actuator reversal",["H","B"],"STUCK",[(0,.5),(.2,.8),(1.2,.3)],duration=8.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["TRACKING_FAULT_CONFIRMED"],evidence="RETAIN_QUALIFIED_FAILURE",watch="UNRESOLVED",mesh="ALL"),
    spec(12,"Material net reversal in sensor outage",["I","M","N","P"],"STUCK",[(0,.5),(.2,.8),(.8,.3)],outage=[(.4,1.4)],duration=8.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["INSUFFICIENT_MEASUREMENT","TRACKING_FAULT_CONFIRMED"],evidence="PRESERVE_AGE_AND_SUSPICION",direction="SUPERSEDE_TO_CURRENT_NEGATIVE_NET_DEMAND",watch="PRESERVE_OLDEST_UNRESOLVED",forbidden=["PERMANENT_HANDOFF_PENDING","RESET_WATCH_ON_REVERSAL"],mesh="ALL"),
    spec(13,"Withdrawal before qualified evidence",["J"],"STUCK",[(0,.5),(.2,.8),(.4,.5)],duration=4.,evidence="CANCEL_IF_NO_QUALIFIED_FAILURE",watch="CANCELLED",forbidden=["TRACKING_FAULT_CONFIRMED"]),
    spec(14,"Withdrawal after suspicion and reissue",["K","L"],"STUCK",[(0,.5),(.2,.8),(.6,.5),(1.,.8)],duration=8.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["TRACKING_FAULT_SUSPECTED","TRACKING_FAULT_CONFIRMED"],evidence="PRESERVE_QUALIFIED_FAILURE_THROUGH_WITHDRAWAL",direction="PAUSE_THEN_REESTABLISH_POSITIVE",watch="PRESERVE_OLDEST_UNRESOLVED",forbidden=["EVIDENCE_ERASURE","SAME_SAMPLE_STALE_CONFIRMATION"],rationale="Frozen 0.2 s actuator delay and 0.03 expected suspicion opening support evidence at 0.6 s; withdrawal pauses direction and 1.0 s reissue cannot reuse stale evidence to confirm immediately."),
    spec(15,"Response during outage, recovery without command",["M","N","O"],"NOMINAL",[(0,.5),(.2,.8)],outage=[(.4,1.4)],duration=8.,milestones=["INSUFFICIENT_MEASUREMENT","TRACKING_PROGRESS","STEADY_TRACKING"],evidence="FIRST_VALID_RECOVERY_ONLY",mesh="ALL"),
    spec(16,"Stuck during outage, recovery without command",["M","N","P"],"STUCK",[(0,.5),(.2,.8)],outage=[(.4,1.4)],duration=8.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["INSUFFICIENT_MEASUREMENT","TRACKING_FAULT_CONFIRMED"],evidence="PRESERVE_UNRESOLVED_DEMAND",watch="PRESERVE_OLDEST_UNRESOLVED",mesh="ALL"),
    spec(17,"Fixed command continued response and resolved plateau",["Q","R"],"NOMINAL",[(0,.5),(.2,.8)],duration=9.,milestones=["TRACKING_PROGRESS","STEADY_TRACKING"],evidence="RESOLVE_FROM_MEASURED_PROGRESS_WITHOUT_NEW_COMMAND"),
    spec(18,"Intermittent subqualified movement then stuck",["S"],"INTERMITTENT",[(0,.5),(.2,.8)],duration=8.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["TRACKING_FAULT_CONFIRMED"],evidence="SUBQUALIFIED_MOVEMENT_DOES_NOT_ERASE_FAILURE",watch="UNRESOLVED",forbidden=["UNLIMITED_FRESH_GRACE"]),
    spec(19,"Finite repeated short pulses then held demand",["T"],"STUCK",[(0,.5),(.2,.8),(.6,.5),(1.,.8),(1.4,.5),(1.8,.8),(2.2,.5),(2.6,.8)],duration=9.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["TRACKING_FAULT_CONFIRMED"],evidence="NO_UNLIMITED_FRESH_GRACE",watch="PRESERVE_IF_QUALIFIED_FAILURE",forbidden=["PERMANENT_HANDOFF_PENDING","UNLIMITED_FRESH_GRACE"]),
    spec(20,"Same-sample progress and resolution",["U"],"FROZEN_R52_DELAY_0_6",[(0,.648)],initial=.9,duration=1.2,milestones=["TRACKING_PROGRESS","STEADY_TRACKING"],evidence="PUBLIC_PROGRESS_BEFORE_STEADY",forbidden=["DIRECT_HANDOFF_TO_STEADY_WITHOUT_PROGRESS"],rationale="Accepted R4.3B compatibility contract; released input comes from earlier frozen R5.2 DELAY_0_6 diagnostic, not R4.3B output. At 1.0 s released displacement and tracking tolerance support same-sample qualified progress plus internal resolution."),
    spec(21,"Intervening invalid sample after progress",["U","M"],"FROZEN_R52_DELAY_0_6",[(0,.648)],initial=.9,outage=[(1.2,1.4)],duration=1.2,terminal="INSUFFICIENT_MEASUREMENT",milestones=["TRACKING_PROGRESS","INSUFFICIENT_MEASUREMENT"],evidence="RECHECK_CURRENT_SAMPLE_BEFORE_STEADY",forbidden=["MECHANICAL_STEADY_DURING_INVALID_SAMPLE"],rationale="Accepted R4.3B compatibility contract; 1.2 s INVALID release intervenes after the 1.0 s progress/inner resolution. Input is from frozen R5.2 DELAY_0_6 trace, not candidate output."),
    spec(22,"Post-startup silent stuck",["W"],"POST_STARTUP_STUCK",[(0,.5),(.2,.7),(3.,.9)],initial=.5,stuck_at=3.,duration=10.,terminal="TRACKING_FAULT_CONFIRMED",safety="FAULT",milestones=["STEADY_TRACKING","TRACKING_FAULT_SUSPECTED","TRACKING_FAULT_CONFIRMED"],evidence="NEW_UNRESOLVED_FAILURE_AFTER_SETTLED_PERIOD",mesh="ALL"),
    spec(23,"Long-run healthy moving command",["X","D","E"],"NOMINAL",[(0,.5)]+[(round(t*.2,1), round(.5+.2*(1 if (t//20)%2==0 else -1)*(t%20)/20,4)) for t in range(1,151)],duration=32.,milestones=["TRACKING_PROGRESS"],evidence="NO_FALSE_CONFIRMED_FAULT",forbidden=["FALSE_POSITIVE_TRACKING_FAULT"],mesh="ALL"),
]


class Sluggish(PumpActuator):
    """Exact test-only SLOW_RAMP_0_1 behavior registered in R5.2."""
    def _advance_segment(self, seconds):
        if seconds <= 0:
            return
        exact = self.target + (self.actual - self.target) * exp(-seconds / 2.0)
        delta = min(0.1 * seconds, max(-0.1 * seconds, exact - self.actual))
        self.actual = min(self.config.maximum, max(self.config.minimum, self.actual + delta))


class Intermittent(PumpActuator):
    """Deterministic freeze-then-hold; subqualified movement uses existing 0.01 floor."""
    def _advance_segment(self, seconds):
        if self.actual < 0.509:
            self.actual = min(0.509, self.actual + min(0.2 * seconds, max(0., self.target - self.actual)))


def observations(case, physics_dt):
    if case["mode"] == "FROZEN_R52_DELAY_0_6":
        source = json.loads((ROOT/"phase5_r5_2_silent_tracking_fault_evidence.json").read_text(encoding="utf-8"))
        source_rows = source["cases"]["DELAY_0_6"]["speed_only_diagnostic"]["records"][:7]
        result=[]
        for source_row in source_rows:
            row=source_row["observation"]
            t=row["timestamp_ns"]
            invalid=any(round(start*NS)<=t<round(end*NS) for start,end in case["outage"])
            result.append(dict(time_ns=t,plc_command=row["current_plc_command"],
                               command_timestamp_ns=row["command_timestamp_ns"],
                               measured_speed=None if invalid else row["released_measured_pump_speed"],
                               sample_ns=None if invalid else row["measurement_sample_ns"],
                               release_ns=None if invalid else row["measurement_release_ns"],
                               quality="MISSING" if invalid else row["measurement_quality"],
                               measurement_record_id=f"itq-measurement:{case['id']}:{t}"))
        return result
    profile = json.loads(PROFILE.read_text(encoding="utf-8"))
    a = profile["ActuatorTrackingProfile"]
    config = PumpActuatorConfig(a["speed_min"]["value"], a["speed_max"]["value"],
                                a["lag_time_constant_s"]["value"], a["speed_rate_limit_per_s"]["value"],
                                round(a["command_delay_s"]["value"] * NS))
    cls = {"SLOW_RAMP_0_1": Sluggish, "INTERMITTENT": Intermittent}.get(case["mode"], PumpActuator)
    actuator = cls(config, case["initial"])
    commands = {round(t*NS): v for t,v in case["commands"]}
    duration = round(case["duration"]*NS)
    step = round(physics_dt*NS)
    assert DT % step == 0 and duration % step == 0
    rows = []
    current = case["initial"]
    command_time = 0
    for t in range(0, duration+step, step):
        if t in commands:
            current = commands[t]
            command_time = t
            actuator.command(ActuatorCommand(f"itq-command:{case['id']}:{t}", t, "PLC", f"itq-cycle:{t}",
                                             "itq-target", "itq-envelope", current, current,
                                             "PREREGISTERED_TEST_INPUT", "OPEN_LOOP", ()), t)
        if t > 0:
            if case["mode"] == "STUCK" or (case["mode"] == "POST_STARTUP_STUCK" and t > round(case["stuck_at"]*NS)):
                actuator.fault_stuck = True
            actuator.advance(t-step,t)
        if t % DT == 0:
            invalid = any(round(start*NS) <= t < round(end*NS) for start,end in case["outage"])
            row = dict(time_ns=t, plc_command=current, command_timestamp_ns=command_time,
                       measured_speed=None if invalid else round(actuator.actual,12),
                       sample_ns=None if invalid else t, release_ns=None if invalid else t,
                       quality="MISSING" if invalid else "VALID", measurement_record_id=f"itq-measurement:{case['id']}:{t}")
            rows.append(row)
    return rows


def make_expected(case):
    fault = case["terminal"] == "TRACKING_FAULT_CONFIRMED"
    events = []
    for i,state in enumerate(case["milestones"]):
        events.append({"state":state,"occurrence":i+1,"timing_normativity":"ORDER_NORMATIVE",
                       "relation":"AFTER_PREVIOUS_MILESTONE" if i else "AFTER_MATERIAL_COMMAND_OR_INVALID_RELEASE"})
    if case["id"] in ("ITQ-020","ITQ-021"):
        events[0]["timing_normativity"] = "EXACT_NORMATIVE"
        events[0]["time_ns"] = 1_000_000_000
        events[0]["relation"] = "ONE_PUBLIC_TRACKING_PROGRESS_REQUIRED_BEFORE_STEADY"
    if case["outage"] and case["outage"][0][1] <= case["duration"]:
        events.append({"state":"FIRST_VALID_RECOVERY_MEASUREMENT","occurrence":1,
                       "timing_normativity":"EXACT_NORMATIVE","time_ns":round(case["outage"][0][1]*NS),
                       "relation":"FIXED_RELEASE_GRID_ONLY_NOT_EXACT_TRACKER_TRANSITION"})
    return {"schema":"itq-expected-v1","case_id":case["id"],"title":case["title"],
            "hazards":case["hazards"],"basis":case["rationale"],"expected_public_state_milestones":events,
            "expected_terminal_state":case["terminal"],"terminal_timing_normativity":"ORDER_NORMATIVE",
            "fault_expected":fault,"expected_evidence_behavior":case["evidence"],
            "expected_direction_behavior":case["direction"],"expected_watch_behavior":case["watch"],
            "forbidden_outcomes":list(dict.fromkeys(case["forbidden"] + (["FALSE_POSITIVE_TRACKING_FAULT"] if not fault else ["FALSE_NEGATIVE_TRACKING_FAULT"]))),
            "safety":{"highest":case["safety"],"allowed_intermediate":["NORMAL","DEGRADED"] if fault else ["NORMAL","DEGRADED"],
                      "forbidden":["FAULT"] if not fault else [],"confirmed_fault_latched":fault,
                      "sensor_invalidity_note":"Independent sensor severity is outside tracking mapping; no invented actuator FAULT."},
            "timing_rules":{"EXACT_NORMATIVE":"Only fixed release grid and one public progress publication where specified",
                            "ORDER_NORMATIVE":"Milestones and terminal result order, not identical physical time across dt",
                            "WINDOW_NORMATIVE":"NOT_USED; no new window introduced",
                            "NON_NORMATIVE":"Incidental transition sample/time unless explicitly fixed above"},
            "acceptance":{"all_milestones_in_order":True,"terminal_required_by_duration_ns":round(case["duration"]*NS),
                          "no_forbidden_outcome":True,"prefix_causality_required":True,"deterministic_repeat_required":True,
                          "cross_mesh":"CAUSAL_PHYSICAL_TIME_NOT_SAMPLE_INDEX" if case["mesh"]=="ALL" else "NOT_APPLICABLE"},
            "measurement_authority":"released VALID speed only; no ACTUAL/TRUE/future/unreleased/flow/DP confirmation",
            "same_sample_reissue_guard":{"time_ns":1_000_000_000,"forbid_confirmed_on_this_sample":True,
                                         "timing_normativity":"EXACT_NORMATIVE"} if case["id"]=="ITQ-014" else None}


def validate_input(data):
    rows=data["observations"]
    assert rows and rows[0]["time_ns"]==0 and rows[-1]["time_ns"]==data["duration_ns"]
    assert len(rows)==data["duration_ns"]//DT+1
    for i,row in enumerate(rows):
        assert row["time_ns"]==i*DT
        assert .3 <= row["plc_command"] <= .9
        assert row["command_timestamp_ns"] <= row["time_ns"]
        if row["quality"]=="VALID":
            assert row["sample_ns"]==row["release_ns"]==row["time_ns"]
            assert row["measured_speed"] is not None and .3 <= row["measured_speed"] <= .9
        else:
            assert row["quality"]=="MISSING" and row["measured_speed"] is None
            assert row["sample_ns"] is None and row["release_ns"] is None
    return {"timestamps_monotonic":True,"commands_in_profile":True,"measurement_range_valid":True,
            "invalid_windows_explicit":True,"event_order_possible":True,"units_consistent":True,
            "candidate_engine_not_executed":True}


def main():
    HERE.mkdir(parents=True,exist_ok=True)
    records=[]
    validations={}
    for case in CASES:
        variants=[]
        for dt in ([.2,.1,.05] if case["mesh"]=="ALL" else [.2]):
            suffix=str(dt).replace(".","p")
            input_path=HERE/f"{case['id']}_dt{suffix}_input.json"
            rows=observations(case,dt)
            command_timeline=([{"time_ns":r["time_ns"],"speed_fraction":r["plc_command"]} for r in rows]
                              if case["mode"]=="FROZEN_R52_DELAY_0_6" else
                              [{"time_ns":round(t*NS),"speed_fraction":v} for t,v in case["commands"]])
            input_data={"schema":"itq-input-v1","case_id":case["id"],"title":case["title"],
                        "hazards":case["hazards"],"initial_condition":{"speed_fraction":case["initial"],"tracking_state":"STEADY_TRACKING"},
                        "command_timeline":command_timeline,
                        "measurement_timeline":{"sample_cadence_ns":DT,"release_delay_ns":0,"invalid_windows_ns":[[round(s*NS),round(e*NS)] for s,e in case["outage"]]},
                        "actuator_fixture_behavior":{"mode":case["mode"],"stuck_at_ns":None if case["stuck_at"] is None else round(case["stuck_at"]*NS),
                                                     "source":"frozen nominal PumpActuator, R5.2 test-only sluggish, or R5.2 frozen DELAY_0_6 released trace; intermittent subqualified motion uses existing 0.01 floor"},
                        "duration_ns":round(case["duration"]*NS),"physics_dt_ns":round(dt*NS),"decision_cadence_ns":DT,
                        "observations":rows,"candidate_input_whitelist":["time_ns","plc_command","command_timestamp_ns","measured_speed","sample_ns","release_ns","quality","measurement_record_id"]}
            validations[input_path.relative_to(ROOT).as_posix()]=validate_input(input_data)
            save(input_path,input_data)
            variants.append({"physics_dt_ns":round(dt*NS),"input_path":input_path.relative_to(ROOT).as_posix(),"input_sha256":sha(input_path)})
        expected_path=HERE/f"{case['id']}_expected.json"
        save(expected_path,make_expected(case))
        records.append({"case_id":case["id"],"title":case["title"],"hazards":case["hazards"],
                        "fixture_variants":variants,"expected_path":expected_path.relative_to(ROOT).as_posix(),
                        "expectation_sha256":sha(expected_path),"mesh":case["mesh"],"terminal":case["terminal"]})
    source_paths=[ENGINE,ROOT/"v0_2/safety/supervisor.py",ROOT/"v0_2/control/directional_outer.py",
                  ROOT/"v0_2/control/inner_loop.py",ROOT/"v0_2/plant/controlled_loop.py",ROOT/"v0_2/measurement/local_sensor.py",
                  ROOT/"v0_2/actuators/pump.py",PROFILE,CONTRACT]
    source_hashes={p.relative_to(ROOT).as_posix():sha(p) for p in source_paths}
    hazard={k:[r["case_id"] for r in records if k in r["hazards"]] for k in "ABCDEFGHIJKLMNOPQRSTUVWX"}
    assert all(hazard.values())
    norm={"EXACT_NORMATIVE":"fixed fixture release or explicitly required public progress publication only",
          "ORDER_NORMATIVE":"causal state/event ordering", "WINDOW_NORMATIVE":"unused; no new timing window",
          "NON_NORMATIVE":"incidental tracker transition time"}
    core={"schema":"itq-preregistration-v1","suite_name":"INDEPENDENT_TRACKING_QUALIFICATION_SUITE",
          "ITQ_SUITE_VERSION":"1.0-preregistered","ITQ_SUITE_STATUS":"CANDIDATE_FOR_USER_APPROVED_FREEZE",
          "execution_status":"PREREGISTERED_NOT_EXECUTED","R4_4_GATE":"INDEPENDENT_TRACKING_QUALIFICATION_SUITE_PREREGISTERED",
          "FULL_P_HISTORY_VALIDATION_AVAILABLE":"NO","CAN_PRODUCTION_PORT_START":"NO",
          "historical_evidence":{"S":"historical","C":"historical","P15":"FROZEN_RECONSTRUCTED_HISTORICAL_FIXTURE/PASS",
                                 "P1-P14_P16-P20":"NOT_RECOVERABLE_FROM_CURRENT_EVIDENCE"},
          "candidate_engine_sha256_reference_only":source_hashes[ENGINE.relative_to(ROOT).as_posix()],
          "tracking_profile_sha256":sha(PROFILE),"Contract15A_sha256":sha(CONTRACT),
          "source_hashes_before_after":{p:{"before":h,"after":sha(ROOT/p)} for p,h in source_hashes.items()},
          "cases":records,"hazard_coverage":hazard,"timing_normativity_definitions":norm,
          "planned_execution_matrix":{"all_mesh_cases":[r["case_id"] for r in records if r["mesh"]=="ALL"],
                                      "canonical_only_cases":[r["case_id"] for r in records if r["mesh"]=="CANONICAL"],
                                      "physics_mesh_ns":[200_000_000,100_000_000,50_000_000],"decision_cadence_ns":DT,
                                      "prefixes":"at every command, invalidity boundary, recovery, progress and terminal boundary; truncate future input and compare prefix public outputs",
                                      "repeats":2},
          "acceptance_gate":{"all_required_hazards_covered":True,"all_inputs_and_expectations_hashed":True,
                             "candidate_not_executed":True,"false_positive":"CONFIRMED in legitimate actuator response case",
                             "false_negative":"stuck case lacks required CONFIRMED by registered duration",
                             "evidence_erasure":"qualified unresolved evidence lost solely due to withdrawal/reversal/reissue",
                             "direction_lock":"old direction remains after material opposite net demand and blocks evaluation",
                             "fresh_grace":"repeated manipulation indefinitely postpones qualification under persistent material stuck demand",
                             "same_sample_false_fault":"stale evidence confirms immediately on reissue/re-establishment without new opportunity"},
          "anti_bias":"No case has been run against R4.3B; expectations authored from contracts/profile/causal reasoning.",
          "production_port":"PROHIBITED","phase6":"PROHIBITED","user_freeze_approval":"REQUIRED"}
    core_hash=hashlib.sha256(canonical(core)).hexdigest()
    aggregate=hashlib.sha256(canonical({"manifest_core_sha256":core_hash,"inputs_and_expectations":[
        {"case_id":r["case_id"],"fixture_sha256":[v["input_sha256"] for v in r["fixture_variants"]],"expectation_sha256":r["expectation_sha256"]} for r in records],
        "normativity":norm})).hexdigest()
    manifest={**core,"manifest_core_sha256":core_hash,"aggregate_sha256":aggregate,
              "aggregate_method":"SHA256(canonical JSON of manifest_core_sha256, ordered case input/expectation digests, normativity); excludes aggregate field to avoid self-reference"}
    save(MANIFEST,manifest)
    evidence={"schema":"itq-preregistration-evidence-v1","suite_version":"1.0-preregistered","fixture_count":sum(len(r["fixture_variants"]) for r in records),
              "case_count":len(records),"case_ids":[r["case_id"] for r in records],"all_hashes":{
                  "manifest_sha256":sha(MANIFEST),"manifest_core_sha256":core_hash,"aggregate_sha256":aggregate,
                  "tracking_profile_sha256":sha(PROFILE),"Contract15A_sha256":sha(CONTRACT),
                  "R4_3B_engine_sha256_reference":sha(ENGINE),"source_hashes":source_hashes,
                  "fixture_and_expectation_hashes":[{"case_id":r["case_id"],"inputs":r["fixture_variants"],"expected_sha256":r["expectation_sha256"]} for r in records]},
              "structural_validation":validations,"production_source_hashes_unchanged":all(sha(ROOT/p)==h for p,h in source_hashes.items()),
              "candidate_execution":"NOT_PERFORMED","status":"CANDIDATE_FOR_USER_APPROVED_FREEZE",
              "R4_4_GATE":"INDEPENDENT_TRACKING_QUALIFICATION_SUITE_PREREGISTERED"}
    save(EVIDENCE,evidence)
    report=["# Phase 5R5.2.1R4.4 — ITQ preregistration", "",
            "Status: **CANDIDATE_FOR_USER_APPROVED_FREEZE**. Candidate execution: **NOT PERFORMED**.","",
            "## Purpose and evidence separation", "",
            "This new, independent qualification suite covers tracking risk classes not recoverable from P history. It is not recovered P1–P20 and is not historical regression reconstruction. Historical evidence remains S, C, and frozen P15 only; P1–P14 and P16–P20 remain NOT_RECOVERABLE_FROM_CURRENT_EVIDENCE. FULL_P_HISTORY_VALIDATION_AVAILABLE = NO.","",
            "## Frozen dependencies and philosophy", "",
            f"Frozen numerical profile SHA-256 `{sha(PROFILE)}`; Contract15A SHA-256 `{sha(CONTRACT)}`; R4.3B engine reference SHA-256 `{sha(ENGINE)}`. Real hardware: CALIBRATION_REQUIRED. No numerical threshold, timer, response delay, noise model, hardware limit or public state was added. Cases use released VALID speed only; flow/DP are not tracking-confirmation authority. No ACTUAL/TRUE/future/unreleased input is exposed to the evaluator.","",
            "## Case inventory and qualification matrix", "",
            "| ITQ case | Hazard class | Normal/Fault | Measurement | Command pattern | Expected terminal | Timing |", "|---|---|---|---|---|---|---| "]
    for c in CASES:
        report.append(f"| {c['id']} {c['title']} | {','.join(c['hazards'])} | {'Fault' if c['safety']=='FAULT' else 'Normal'} | {'outage/recovery' if c['outage'] else 'valid'} | {len(c['commands'])} events | {c['terminal']} | ORDER; fixed releases EXACT |")
    report += ["","## Hazard coverage matrix","","| Hazard/behavior | ITQ cases | Historical evidence also exists? | Remaining gap |","|---|---|---|---|"]
    descriptions={"A":"normal response","B":"silent stuck","C":"sluggish","D":"continuous increase","E":"continuous decrease","F":"small-command accumulation","G":"jitter","H":"reversal","I":"outage reversal","J":"withdrawal before evidence","K":"withdrawal after evidence","L":"reissue","M":"sensor invalidity","N":"sensor recovery","O":"response in outage","P":"stuck in outage","Q":"measured response/no new command","R":"plateau","S":"intermittent response","T":"repeated short pulses","U":"same-sample progress/resolution","V":"reversal after progress","W":"post-startup stuck","X":"long-run normal"}
    historical={"A":"S1/S3/S8","B":"S2/S6/S8","C":"R5.2 sluggish fixture (not S/C/P15 equivalence)",
                "D":"S8","E":"S9","F":"S8","G":"S7","H":"S9/S16/P15",
                "I":"No recovered S/C/P15 equivalent","J":"No recovered S/C/P15 equivalent",
                "K":"No recovered S/C/P15 equivalent","L":"No recovered S/C/P15 equivalent",
                "M":"S10/S11","N":"S10/S12","O":"S10","P":"S12",
                "Q":"S15 related","R":"S1 related","S":"S5 related","T":"S16 related",
                "U":"S3/S14","V":"S9 related","W":"S5/S13","X":"No recovered S/C/P15 equivalent"}
    for k in descriptions:
        report.append(f"| {k} {descriptions[k]} | {', '.join(hazard[k])} | {historical[k]} | None in preregistered scope; no historical equivalence claimed |")
    report += ["","## Case purpose, outcomes and rationale","", "Each case's complete commands, released measurement timeline, validity, deterministic actuator behavior, duration, cadence, public milestones, terminal result, evidence/direction/watch semantics, explicit forbidden outcomes and per-case hashes are in the paired JSON input/expectation files. Rationale is recorded in each expectation JSON and derives from frozen contract/profile, accepted tracking semantics and causality—not candidate output.","",
               "## Timing, mesh, Safety and causality", "", "EXACT_NORMATIVE applies only to fixture release grid and the required one public TRACKING_PROGRESS publication in ITQ-020/021; ORDER_NORMATIVE applies to milestone order and terminal outcomes. WINDOW_NORMATIVE is unused (no new window). Incidental transition samples are NON_NORMATIVE. Physical mesh variants are frozen at 0.2/0.1/0.05 s for ALL-marked cases; remaining cases use 0.2 s. Compare causal/physical behavior, never identical sample indices across dt. Sensor decision cadence remains the frozen 0.2 s. Every case has a planned prefix-causality check at command/invalid/recovery/progress/terminal boundaries and a deterministic repeat; no stochastic input. Highest Safety is NORMAL in legitimate-response cases or FAULT in confirmed stuck cases; intermediate DEGRADED is allowed, not required. Independent sensor-fault severity is outside this tracking mapping. CONFIRMED latches under existing policy.","",
               "## Anti-bias, limitations and freeze recommendation", "", "No R4.3B behavioral execution occurred. Input and expected JSON were authored before any ITQ result and SHA-256 hashed; post-result edits invalidate preregistration. Normal response sizes, stuck, continuous ramps, accumulation, jitter, reversal, outage/recovery, withdrawal/reissue, same-sample publication, pulses, post-startup stuck and long-run behavior are explicitly covered. The finite pulse case cannot prove a universal unbounded guarantee; hardware calibration remains required. No historical P gap is closed by ITQ. User review is required before final freeze. Recommended next phase only: 5R5.2.1R4.4A freeze and blind execution; not authorized now.","",
               f"Aggregate SHA-256: `{aggregate}`. Manifest core SHA-256: `{core_hash}`.","",
               "R4_4_GATE = INDEPENDENT_TRACKING_QUALIFICATION_SUITE_PREREGISTERED. CAN_PRODUCTION_PORT_START = NO. Phase 6 = NO. Commit/push = NO."]
    REPORT.write_text("\n".join(report)+"\n",encoding="utf-8")
    print(json.dumps({"cases":len(records),"fixtures":evidence["fixture_count"],"aggregate_sha256":aggregate,"status":evidence["status"]}))


if __name__=="__main__":
    main()
