"""R2 orchestration only; approved comparator and candidate semantics immutable.

All expectations come from frozen files. This runner is hashed before the first
candidate import; it never generates or changes a behavioral expectation.
"""
import ast
import hashlib
import json
import platform
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from .verify_itq_preregistration import ROOT, canonical, sha
from .verify_execution_baseline_v101 import check
from .itq_execution_spec_v101 import compare_snapshot, TRACKING_CONTRIBUTION, SEVERITY_ORDER
from .run_itq_blind import run_candidate, prefixes

STEM='phase5_r5_2_1r4_4a2_r2_itq_blind_qualification'
EVIDENCE=ROOT/(STEM+'_evidence.json')
MANIFEST=ROOT/(STEM+'_run_manifest.json')
REPORT=ROOT/'PHASE5_R5_2_1R4_4A2_R2_ITQ_FULL_BLIND_QUALIFICATION_REPORT.md'
def now(): return datetime.now(timezone.utc).isoformat()
def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
def digest(v): return hashlib.sha256(canonical(v)).hexdigest()
def save(p,v): p.write_bytes(canonical(v)+b'\n')
def audit_authority():
    paths=['v0_2/examples/'+n for n in ('phase5_r5_2_1r_semantic_engine.py','phase5_r5_2_1r4_paired_engine.py','phase5_r5_2_1r4_1_deferred_engine.py','phase5_r5_2_1r4_2_directional_engine.py','phase5_r5_2_1r4_3_startup_engine.py')]
    forbidden={'actual_speed','true_speed','raw_speed','measured_flow_kg_s','measured_dp_pa','future_measurement'}
    hits=[]
    for p in paths:
        for n in ast.walk(ast.parse((ROOT/p).read_text(encoding='utf-8'))):
            if isinstance(n,ast.Attribute) and n.attr in forbidden: hits.append({'path':p,'line':n.lineno,'field':n.attr})
            if isinstance(n,ast.Subscript) and isinstance(n.slice,ast.Constant) and n.slice.value in forbidden: hits.append({'path':p,'line':n.lineno,'field':n.slice.value})
    return {'status':'PASS' if not hits else 'FAIL','paths':paths,'forbidden_accesses':hits,'scope':'All candidate inheritance modules; released observations only. Fixture generator physical state is not exposed to candidate.'}
def preflight():
    result=check(); m=load('phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json')
    r1=load('phase5_r5_2_1r4_4a2_r1_comparator_restore_evidence.json')
    assert r1['R4_4A2_R1_GATE']=='APPROVED_COMPARATOR_RESTORED_AND_BASELINE_REVERIFIED'
    assert result['execution_baseline_hash']=='242a6bc5e4f00aa54e0242b3450b95d3c2ea9daebf68e3a7d941ca5da177a3ac'
    assert sha(ROOT/'v0_2/tests/data/tracking_qualification/itq_execution_spec_v101.py')=='456966aa0a6951cecedd55e63cc61f86c91b2c318f7d5d34d1b81e0ea43a47b8'
    assert sha(ROOT/'phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json')=='a1d6b4dca3b6c1346874b53d67bd3d6b17af6e5a1fff631b62a8828ed7a78967'
    a=audit_authority(); assert a['status']=='PASS',a
    assert not any(n.startswith('v0_2.examples') for n in sys.modules)
    return m,result,a
def hashes(m):
    paths=set(m['protected_source_sha256'])
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'v0_2').rglob('*.py'))
    paths.update(p.relative_to(ROOT).as_posix() for p in (ROOT/'v0_2/tests/data').rglob('*.json'))
    paths.update(p.name for p in ROOT.glob('phase5*.json') if not p.name.startswith(STEM))
    paths.update(p.name for p in ROOT.glob('PHASE5*.md') if p!=REPORT)
    return {p:sha(ROOT/p) for p in sorted(paths)}
def immutable(frozen):
    mismatches=[p for p,h in frozen.items() if sha(ROOT/p)!=h]
    if mismatches: raise RuntimeError('BLIND_SOURCE_OR_FIXTURE_MUTATED:'+','.join(mismatches))
def forensic(result,snapshot,expected,rows):
    records=snapshot['records']; idx=len(records)-1; error=result['errors'][0]
    # Missing ORDER milestones are decidable only at the registered horizon.
    # Exact mismatches and forbidden fault events are decidable at their sample.
    if error.startswith('EXACT_MILESTONE_TIME:'):
        fields=error.split(':'); actual=int(fields[2].split('!=')[0]); expected_time=int(fields[2].split('!=')[1])
        idx=next((i for i,r in enumerate(records) if r['time_ns']==min(actual,expected_time)),idx)
    elif error in ('FALSE_POSITIVE_TRACKING_FAULT','FORBIDDEN_PUBLIC_STATE','FORBIDDEN_SAFETY_STATE','MAX_ALLOWED_SAFETY_EXCEEDED'):
        idx=next((i for i,r in enumerate(records) if r['state']=='TRACKING_FAULT_CONFIRMED'),idx)
    elif error=='SAME_SAMPLE_STALE_CONFIRMATION':
        idx=next(i for i,r in enumerate(records) if r['time_ns']==expected['same_sample_reissue_guard']['time_ns'])
    record=records[idx]
    return {'first_divergence_time_ns':record['time_ns'],'divergence_basis':'Frozen rule violation; missing milestone/terminal divergence becomes decidable at horizon. No invented earlier expected transition.','errors':result['errors'],'input_prefix':rows[:idx+1],'expected':expected,'actual_record':record,'released_input':rows[idx],'tracking_state':record['state'],'Safety_contribution':TRACKING_CONTRIBUTION[record['state']],'public_reason':'PUBLIC_STATE_DERIVED_TRACKING_CONTRIBUTION; candidate publishes no independent Safety reason code','anchor_and_evidence_source':'Contemporaneous actual_record plus prefix snapshot, not final-run anchor','prefix_snapshot':None}
def historical(profile,classifier):
    from v0_2.examples import phase5_r5_2_1r1_validation as r1
    from v0_2.examples.phase5_r5_2_1r4_3_history_validation import s_acceptance,c_acceptance
    from v0_2.examples.phase5_r5_2_1r_validation import build_cases,R52_EVIDENCE,R522_EVIDENCE
    read=lambda p:json.loads(p.read_text(encoding='utf-8'))
    ss=build_cases(profile,read(R52_EVIDENCE),read(R522_EVIDENCE))
    cs={k:v for k,v in r1.cases(profile).items() if k!='C9'}
    from dataclasses import asdict
    replay=lambda source:run_candidate([asdict(x) for x in source],profile,classifier)
    s_snap={k:replay(v) for k,v in ss.items()}; c_snap={k:replay(v) for k,v in cs.items()}
    s=s_acceptance(s_snap); c=c_acceptance(c_snap)
    tests=subprocess.run([sys.executable,'-m','pytest','-q','v0_2/tests/control/test_phase5_r5_2_1r4_3_startup.py'],cwd=ROOT,text=True,capture_output=True)
    found=re.search(r'(\d+) passed',tests.stdout)
    count=int(found[1]) if found else sum(len(l.split()[0]) for l in tests.stdout.splitlines() if l.split() and set(l.split()[0])=={'.'})
    frozen=load('phase5_r5_2_1_p15_reconstructed_history_freeze.json'); data=load(frozen['input_path'])
    assert sha(ROOT/frozen['input_path'])==frozen['input_file_sha256'] and digest(data)==frozen['input_canonical_sha256']
    rows=data['observations']; p15=run_candidate(rows,profile,classifier)
    starts=[e for e in p15['epoch_events'] if e['event']=='START']; anchors=p15['resolved_pair_events']; progress=[r for r in p15['records'] if r['qualified_progress']]
    repeat=[digest(run_candidate(rows,profile,classifier)) for _ in range(10)]
    pchecks={'exact_epoch_starts':[e['time_ns'] for e in starts]==[600000000,3400000000],
             'exact_directions':[e['expected_direction'] for e in starts]==[1,1],
             'exact_anchors':[e['new']['resolved_command_anchor'] for e in anchors]==[0.35,0.51,0.67],
             'initial_anchor_direct':bool(anchors) and anchors[0]['reason']=='DIRECTLY_OBSERVED_INITIAL_STEADY_BASELINE',
             'stage_progress':len(starts)==2 and len(anchors)==3 and all(any(starts[i]['time_ns']<r['time_ns']<=anchors[i+1]['time_ns'] for r in progress) for i in range(2)),
             'resolved_after_trigger':len(starts)==2 and len(anchors)==3 and all(anchors[i+1]['time_ns']>starts[i]['time_ns'] for i in range(2)),
             'anchor_epoch_provenance':[e['new']['source_epoch_id'] for e in anchors[1:]]==[e['epoch_id'] for e in starts],
             'final_steady':p15['state']=='STEADY_TRACKING','no_fault':not p15['confirmed_latched'] and all(r['state']!='TRACKING_FAULT_CONFIRMED' for r in p15['records']),
             'repeats10':len(set(repeat))==1,'all_prefixes':all(run_candidate(rows[:n],profile,classifier)['records']==p15['records'][:n] for n in range(1,len(rows)+1))}
    return {'executed_after_ITQ':True,'startup':{'pass':count,'total':50,'returncode':tests.returncode,'stdout':tests.stdout,'stderr':tests.stderr},'C':{'pass':sum(c.values()),'total':len(c),'criteria':c,'fresh_snapshot_hashes':{k:digest(v) for k,v in c_snap.items()}},'S':{'pass':sum(s.values()),'total':len(s),'criteria':s,'fresh_snapshot_hashes':{k:digest(v) for k,v in s_snap.items()}},'P15':{'status':'PASS' if all(pchecks.values()) else 'FAIL','class':frozen['freeze_status'],'checks':pchecks,'snapshot':p15,'repeat_sha256_10x':repeat,'normativity':frozen['normativity_table']},'pass':count==50 and tests.returncode==0 and len(c)==11 and all(c.values()) and len(s)==17 and all(s.values()) and all(pchecks.values())}
def report(e):
    text=['# R4.4A2-R2：完整独立盲测资格报告','',f"ITQ_SUITE_RESULT = {e['ITQ_SUITE_RESULT']}",f"R4_4A2_R2_GATE = {e['R4_4A2_R2_GATE']}",f"R4_3B_CANDIDATE_QUALIFICATION_STATUS = {e['R4_3B_CANDIDATE_QUALIFICATION_STATUS']}",'','## 基线与执行审计','',json.dumps(e['baseline_verification'],ensure_ascii=False),f"冻结时间 {e['freeze_timestamp_utc']}；第一次候选导入/执行 {e.get('first_candidate_import_execution_utc')}。runner 原字节 hash 在运行前冻结；运行中及结束核验所有受保护源。",'本次不沿用任何旧 PASS/FAIL。R1 已恢复批准 comparator，已知 namespace 问题只接受于冻结 51 变体。','', '## 51 变体结果','','| Case | Variant | Expected | Actual | Result | First divergence |','| :--- | :--- | :--- | :--- | :--- | :--- |']
    for v in e['variants']:
        text.append(f"| {v['case_id']} | {v['variant_path']} | {v.get('expected_terminal','')} | {v.get('actual_terminal','')} | {v['status']} | {(v.get('forensics') or {}).get('first_divergence_time_ns','—')} |")
    text+=['','## 23 案例与 Hazard A–X','','| Case | Result |','| :--- | :--- |']+[f"| {k} | {v} |" for k,v in e['case_results'].items()]
    text+=['','| Hazard | Cases | Result | Evidence |','| :--- | :--- | :--- | :--- |']+[f"| {k} | {','.join(v['cases'])} | {v['result']} | 对应 variants 的原始 snapshot、错误、前缀和重复 hash |" for k,v in e['hazard_results'].items()]
    text+=['','## Safety、方向、测量权限与时间规则','','使用未修改 compare_snapshot；终态、全程上限、允许中间态、禁止态分别比较，严重度序与原规则不变。ITQ-012 使用 epoch_expected_direction 及两种批准 outage carriers，缺失/冲突按原 INVALID_EXECUTION 处理。完整 released input 和 actual snapshot 在机器证据中；测量无效样本只能 INSUFFICIENT_MEASUREMENT。static authority audit 覆盖全部继承模块，trace 只传递原八个 ReleasedObservation 字段；未传入 TRUE/ACTUAL/flow/DP/future 数据。','EXACT 只比冻结 exact 时间；ORDER 比顺序；WINDOW 不加窗口；NON_NORMATIVE 不增加时刻门禁。mesh 只运行原 51 变体，每个网格独立满足原因果/物理规则，不强求相同样本下标。','', '## Prefix、重复、mesh 与失败取证','','每个命令变化、测量 invalid/recovery 边界、进展/确认/末态按原 prefix 实现截断并重跑，完整 causal records 比对。原 repeats=2，canonical snapshot hashes 必须完全相同。每项失败的规则、判定时刻、输入前缀、当前 command/measurement/quality、方向载体、watch/evidence、anchors/checkpoints、public state 与 Safety contribution 保存于机器证据。未发明候选没有发布的 reason；缺少 ORDER milestone 在冻结 horizon 才可确认为缺失。']
    for v in e['variants']:
        if v['status']=='FAIL': text += ['',f"### {v['case_id']} / {v['variant_path']}",str(v['errors']),f"首个可判定违反时刻 ns：{v['forensics']['first_divergence_time_ns']}。期望末态 {v['expected_terminal']}，实际 {v['actual_terminal']}。完整 prefix snapshot 在 evidence。"]
    text+=['','## 历史回归（与 ITQ 独立）','',json.dumps({k:v for k,v in e['historical'].items() if k!='P15'},ensure_ascii=False),f"P15：{e['historical'].get('P15',{}).get('status','NOT_RUN')}；保留 FROZEN_RECONSTRUCTED_HISTORICAL_FIXTURE 原分类与 normativity。",'','## 不变范围与限制','',f"Integrity error: {e.get('integrity_error')}。源码 hash before/after、所有期望/input/errata hash、runner hash 和完整结果存于 evidence。没有改 candidate、comparator、fixture、expectation、errata、profile、Contract15A 或生产；没有 commit/push 或 Phase 6。",'P1–P14、P16–P20 = NOT_RECOVERABLE_FROM_CURRENT_EVIDENCE；FULL_P_HISTORY_VALIDATION_AVAILABLE = NO。ITQ 不是恢复 P 历史。真实硬件 CALIBRATION_REQUIRED。CAN_PRODUCTION_PORT_START_NOW = NO。', '', '## NEXT ACTION','',e['next_action'],'STOP，等待用户审阅。']
    REPORT.write_text('\n'.join(text)+'\n',encoding='utf-8')
def run():
    if any(p.exists() for p in (EVIDENCE,MANIFEST,REPORT)): raise RuntimeError('R2_ARTIFACT_ALREADY_EXISTS_DO_NOT_OVERWRITE')
    m,baseline,authority=preflight(); prereg=load('phase5_r5_2_1r4_4_itq_preregistration.json'); errata=load('phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json')
    profile=load('phase5_r5_2_2_fixture_tracking_profile.json'); classifier=load('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    frozen=hashes(m)
    assert len(m['planned_execution_matrix'])==51 and prereg['planned_execution_matrix']['repeats']==2
    freeze={'schema':'r2-immutable-run-freeze-v1','freeze_timestamp_utc':now(),'user_authorization':'80528823-5c99-400b-9831-ebb0f48c0cb3 attachment; R2 complete blind authorization','baseline_verification':baseline,'execution_baseline_components':m['execution_baseline_components'],'runner_sha256':sha(Path(__file__)),'protected_hashes':frozen,'ordered_matrix':m['planned_execution_matrix'],'candidate_not_imported_before_freeze':not any(n.startswith('v0_2.examples') for n in sys.modules),'measurement_authority_audit':authority}
    save(MANIFEST,freeze)
    evidence={**freeze,'freeze_manifest_sha256':sha(MANIFEST),'variants':[],'integrity_error':None,'historical':{'status':'NOT_RUN'},'first_candidate_import_execution_utc':None}
    try:
        for entry in m['planned_execution_matrix']:
            immutable(frozen)
            v={'case_id':entry['case_id'],'variant_path':entry['input_path'],'physics_dt_ns':entry['physics_dt_ns'],'start_utc':now(),'input_sha256':entry['input_sha256'],'expectation_sha256':entry['expectation_sha256']}
            fixture=load(entry['input_path']); expected=load(entry['expectation_path']); rows=fixture['observations']
            if evidence['first_candidate_import_execution_utc'] is None: evidence['first_candidate_import_execution_utc']=now()
            snapshot=run_candidate(rows,profile,classifier)
            comparison=compare_snapshot(snapshot,expected,errata['all_case_interpretations'][entry['case_id']],fixture)
            v.update({'expected_terminal':expected['expected_terminal_state'],'actual_terminal':snapshot['state'],'status':comparison['status'],'errors':comparison['errors'],'snapshot':snapshot,'fixture_released_inputs':rows,'Safety_dimensions':errata['all_case_interpretations'][entry['case_id']]})
            if comparison['status']=='INVALID_EXECUTION':
                v['end_utc']=now(); evidence['variants'].append(v); raise RuntimeError('APPROVED_COMPARATOR_INVALID_EXECUTION:'+str(comparison['errors']))
            pref=prefixes(rows,snapshot,profile,classifier); repeated=run_candidate(rows,profile,classifier); repeat_hashes=[digest(snapshot),digest(repeated)]
            input_fields={'time_ns','plc_command','command_timestamp_ns','measured_speed','sample_ns','release_ns','quality','measurement_record_id'}
            trace_ok=all(set(r)==input_fields and (r['quality']!='VALID' or r['sample_ns']<=r['release_ns']<=r['time_ns']) for r in rows)
            if not trace_ok: raise RuntimeError('RELEASED_INPUT_AUTHORITY_INTEGRITY_FAILURE')
            if not pref['pass']: v['errors'].append('PREFIX_CAUSALITY_FAILURE')
            if repeat_hashes[0]!=repeat_hashes[1]: v['errors'].append('NONDETERMINISM')
            v.update({'prefix_causality':pref,'repeatability_sha256_2x':repeat_hashes,'trace_authority':'PASS','canonical_snapshot_sha256':repeat_hashes[0],'status':'FAIL' if v['errors'] else 'PASS','forensics':None})
            if v['status']=='FAIL':
                v['forensics']=forensic(v,snapshot,expected,rows)
                n=len(v['forensics']['input_prefix']); v['forensics']['prefix_snapshot']=run_candidate(rows[:n],profile,classifier)
            immutable(frozen); v['end_utc']=now(); evidence['variants'].append(v)
            save(EVIDENCE,{**evidence,'status':'RUNNING_NOT_FINAL'})
            print(json.dumps({'case':v['case_id'],'dt':v['physics_dt_ns'],'status':v['status'],'errors':v['errors']}),flush=True)
        assert len(evidence['variants'])==51
        evidence['ITQ_completed_validly_utc']=now()
        evidence['historical']=historical(profile,classifier)
        immutable(frozen)
    except Exception as ex:
        evidence['integrity_error']=type(ex).__name__+':'+str(ex)
    evidence['source_hashes_after']={p:sha(ROOT/p) for p in frozen}
    if any(evidence['source_hashes_after'][p]!=h for p,h in frozen.items()): evidence['integrity_error']='PROTECTED_SOURCE_MUTATED'
    complete=len(evidence['variants'])==51 and not evidence['integrity_error']
    evidence['case_results']={c['case_id']:('PASS' if len([v for v in evidence['variants'] if v['case_id']==c['case_id']])==len(c['fixture_variants']) and all(v['status']=='PASS' for v in evidence['variants'] if v['case_id']==c['case_id']) else ('FAIL' if complete else 'NOT_QUALIFYING')) for c in prereg['cases']}
    evidence['hazard_results']={h:{'cases':ids,'result':'PASS' if complete and all(evidence['case_results'][c]=='PASS' for c in ids) else ('FAIL' if complete else 'NOT_QUALIFYING')} for h,ids in prereg['hazard_coverage'].items()}
    passed=complete and all(v['status']=='PASS' for v in evidence['variants'])
    evidence['ITQ_SUITE_RESULT']='INVALID_EXECUTION' if not complete else ('PASS' if passed else 'FAIL')
    evidence['R4_4A2_R2_GATE']='BLIND_QUALIFICATION_INTEGRITY_FAILURE' if not complete else ('INDEPENDENT_TRACKING_QUALIFICATION_BLIND_FAILURE' if not passed else ('INDEPENDENT_TRACKING_QUALIFICATION_BLIND_PASS' if evidence['historical']['pass'] else 'HISTORICAL_REGRESSION_AFTER_BLIND_QUALIFICATION'))
    qualified=passed and evidence['historical'].get('pass',False)
    evidence['R4_3B_CANDIDATE_QUALIFICATION_STATUS']='QUALIFIED_FOR_PRODUCTION_PORT_REVIEW' if qualified else ('NOT_QUALIFIED' if complete else 'NOT_QUALIFIED_IN_THIS_RUN')
    evidence.update({'FULL_P_HISTORY_VALIDATION_AVAILABLE':'NO','REAL_HARDWARE_TRACKING_CALIBRATION':'CALIBRATION_REQUIRED','CAN_PRODUCTION_PORT_START_NOW':'NO','phase6_started':False,'git_commit_push':False,'end_utc':now(),'next_action':'PHASE 5R5.3R-B PRODUCTION TRACKING PORT PREREQUISITE & CHANGE-PLAN REVIEW' if qualified else ('Review exact independent behavioral failures; separate candidate revision, never change frozen tests.' if complete else 'Review integrity defect; no candidate qualification conclusion.')})
    save(EVIDENCE,evidence); report(evidence)
    print(json.dumps({'suite':evidence['ITQ_SUITE_RESULT'],'gate':evidence['R4_4A2_R2_GATE'],'variants':len(evidence['variants']),'pass':sum(v['status']=='PASS' for v in evidence['variants']),'fail':sum(v['status']=='FAIL' for v in evidence['variants']),'integrity_error':evidence['integrity_error'],'historical_pass':evidence['historical'].get('pass')}),flush=True)
if __name__=='__main__':
    if sys.argv[1:] == ['--preflight']: print(json.dumps(preflight()[1:]))
    elif sys.argv[1:]==['run']: run()
    else: raise SystemExit('Use --preflight or run')
