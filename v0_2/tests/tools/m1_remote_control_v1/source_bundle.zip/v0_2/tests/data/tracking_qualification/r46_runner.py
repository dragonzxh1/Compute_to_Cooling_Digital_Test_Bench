"""Independent full-51 R4.6 runner, inert until separate hash-bound approval."""
import argparse
import hashlib
import json
import os
import sys
import uuid
from pathlib import Path

from .r45c_i_evidence import (PersistenceFailure, artifact, atomic_json, canonical,
                            now, run_stage, sha, validate_artifacts)
from .r45c_i_startup_guard import judge_persisted
from .r46_prefix import materialize

ROOT = Path(__file__).resolve().parents[4]
FREEZE = ROOT/'phase5_r5_2_1r4_6_a1_qualification_execution_freeze_manifest.json'
WORKER = 'v0_2.tests.data.tracking_qualification.r46_worker'
SCOPE = 'R4.6_FULL_FROZEN_ITQ_POST_REPAIR'


def validate_authorization(path):
    a = json.loads(Path(path).read_bytes())
    if (a.get('EXECUTION_AUTHORIZED')!='GRANTED' or a.get('scope')!=SCOPE
        or a.get('approved_freeze_raw_sha256')!=sha(FREEZE)
        or a.get('approved_freeze_canonical_sha256')!=hashlib.sha256(canonical(json.loads(FREEZE.read_bytes()))).hexdigest()):
        raise RuntimeError('SEPARATE_USER_HASH_BOUND_R46_AUTHORIZATION_REQUIRED')
    return a


def integrity(approval):
    f = json.loads(FREEZE.read_bytes())
    if (sha(FREEZE)!=approval['approved_freeze_raw_sha256'] or
        hashlib.sha256(canonical(f)).hexdigest()!=approval['approved_freeze_canonical_sha256']):
        raise RuntimeError('FREEZE_DRIFT')
    ref = f['protected_inventory_reference']
    if sha(ROOT/ref['path'])!=ref['raw_sha256']:
        raise RuntimeError('PROTECTED_INVENTORY_REFERENCE_DRIFT')
    old = json.loads((ROOT/ref['path']).read_bytes())
    protected = {**old['protected_raw_hashes'],**old['harness_raw_hashes']}
    if len(protected)!=ref['count'] or hashlib.sha256(canonical(protected)).hexdigest()!=ref['combined_canonical_sha256']:
        raise RuntimeError('PROTECTED_INVENTORY_DRIFT')
    for p,h in {**protected,**f['package_raw_hashes'],**f['dependency_raw_hashes']}.items():
        if sha(ROOT/p)!=h:
            raise RuntimeError('HASH_DRIFT:'+p)
    for p,h in f['upstream_canonical_hashes'].items():
        if hashlib.sha256(canonical(json.loads((ROOT/p).read_bytes()))).hexdigest()!=h:
            raise RuntimeError('CANONICAL_DRIFT:'+p)
    from .run_r45c_policy_a_development import verify_environment
    return verify_environment()


def plan(matrix):
    full = [{'id':'U-fresh','kind':'U'}]
    full += [{'id':f'ST-{i:02}','kind':'ST','case':f'ST-{i:02}'} for i in range(1,17)]
    full += [{'id':f'ITQ-{i:02}-full','kind':'ITQ','entry':e} for i,e in enumerate(matrix,1)]
    full += [{'id':'Startup-original','kind':'STARTUP'}, {'id':'C-history','kind':'C'},
             {'id':'S-history','kind':'S'}, {'id':'P15-history','kind':'P15'}]
    stages = []
    for s in full:
        stages.append(s)
        if s['kind']!='STARTUP':
            stages.append({'id':s['id']+'-prefix-repeat','kind':'PREFIX_REPEAT',
                           'source_stage':s['id'],'source_kind':s['kind'],
                           **({'entry':s['entry']} if 'entry' in s else {})})
    return stages


def load_worker(directory, exitcode, stage):
    if exitcode!=0:
        return {'status':'INVALID','error':'WORKER_PROCESS_NONZERO'}
    r = json.loads((directory/'stdout.raw').read_bytes())
    if r.get('status')=='INVALID':
        return r
    checks = r.get('checks')
    counts = {'U':14,'ITQ':1,'C':12,'S':18,'P15':9,'PREFIX_REPEAT':3}
    st_counts = [5,7,4,5,5,5,5,2,3,6,6,14,5,3,4,5]
    count = st_counts[int(stage['case'][3:])-1] if stage['kind']=='ST' else counts[stage['kind']]
    if not isinstance(checks,dict) or len(checks)!=count or any(type(v) is not bool for v in checks.values()):
        raise ValueError('INCOMPLETE_CHECK_INVENTORY')
    if stage['kind']=='PREFIX_REPEAT':
        cases = r.get('cases')
        if not isinstance(cases,dict) or not cases:
            raise ValueError('MISSING_PREFIX_REPEAT_RECORDS')
        for c in cases.values():
            lengths, hashes = c['selected_prefix_lengths'], c['repeat_hashes']
            if not lengths or lengths!=sorted(set(lengths)) or any(type(n) is not int or n<1 for n in lengths):
                raise ValueError('INVALID_PREFIX_LENGTHS')
            if not hashes or any(not isinstance(h,str) or len(h)!=64 for h in hashes):
                raise ValueError('INVALID_REPEAT_HASH_RECORDS')
            if all(checks.values()) and (c['prefix_failures'] or len(hashes)!=c['required_full_snapshot_count'] or len(set(hashes))!=1):
                raise ValueError('PREFIX_REPEAT_GATE_RECORD_CONTRADICTION')
    if stage['kind']!='PREFIX_REPEAT':
        cases = r.get('cases',{'one':r})
        historical_ids = {
            'C':{'C1','C2','C3_normal','C3_stuck','C4','C5','C6','C7','C8_normal','C8_stuck','C10','C11','C12'},
            'S':{'S1','S2','S3','S4','S5','S6','S7','S8_normal','S8_stuck','S9_up_down','S9_down_up',
                 'S10','S11','S12','S13','S14','S15','S16','S16_variant'}}
        if stage['kind'] in historical_ids and set(cases)!=historical_ids[stage['kind']]:
            raise ValueError('INCOMPLETE_HISTORICAL_CASE_INVENTORY')
        for c in cases.values():
            rows, records = c['inputs'], c['snapshot']['records']
            if not rows or len(rows)!=len(records) or any(x['time_ns']!=y['time_ns'] for x,y in zip(rows,records)):
                raise ValueError('INCOMPLETE_STRUCTURED_RECORDS')
        if stage['kind']=='ITQ':
            fixture = json.loads((ROOT/stage['entry']['input_path']).read_bytes())
            if r['inputs']!=fixture['observations'] or r['comparison']['status'] not in ('PASS','FAIL'):
                raise ValueError('INVALID_ITQ_STRUCTURED_RESULT')
    return r


def gate_worker(r, rc):
    if rc!=0 or r.get('status')=='INVALID':
        return {'status':'INVALID','reason':'PROCESS_PARSER_OR_COMPARATOR_INTEGRITY'}
    c = r['checks']
    return {'status':'PASS' if all(c.values()) else 'FAIL',
            'failed_predicates':[k for k,v in c.items() if not v]}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--authorization',required=True)
    p.add_argument('--output-root',default=str(ROOT/'artifacts/r46-qualification-executions'))
    args = p.parse_args()
    if Path.cwd().resolve()!=ROOT:
        raise RuntimeError('RUN_FROM_FROZEN_WORKSPACE_ROOT')
    auth_path = Path(args.authorization).resolve()
    a = validate_authorization(auth_path)
    f = json.loads(FREEZE.read_bytes())
    stages = plan(f['exact_matrix'])
    if stages!=f['planned_stages']:
        raise RuntimeError('STAGE_PLAN_DRIFT')
    output_root = Path(args.output_root).resolve()
    if not output_root.is_relative_to(ROOT):
        raise RuntimeError('OUTPUT_ROOT_OUTSIDE_WORKSPACE')
    os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD']='1'
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    run_id = 'r46-'+uuid.uuid4().hex
    directory = output_root/run_id
    directory.mkdir(parents=True,exist_ok=False)
    path = directory/'run_manifest.json'
    result = {'schema':'r46-full-qualification-run-v1','execution_id':run_id,
        'status':'IN_PROGRESS','started_at':now(),'authorization':artifact(auth_path),
        'freeze':artifact(FREEZE),'stages':[],'prefix_inventories':[],'data_references':[],
        'stage_inventory':[{**s,'status':'NOT_RUN'} for s in stages],
        'candidate_status':'DEVELOPMENT_VALIDATED_NOT_REQUALIFIED',
        'CAN_PRODUCTION_PORT_START':'NO','FULL_P_HISTORY_VALIDATION_AVAILABLE':'NO',
        'REAL_HARDWARE':'CALIBRATION_REQUIRED','PHASE6':'NO','GIT_COMMIT_PUSH':'NO'}
    atomic_json(path,result)
    def guard():
        validate_artifacts([result['authorization'],result['freeze'],*result['prefix_inventories'],*result['data_references']])
        for prior in result['stages']:
            validate_artifacts([prior['manifest'],*prior['artifacts']])
        return integrity(a)
    try:
        result['environment_before']=guard()
        signature = json.loads((ROOT/f['startup_signature_path']).read_bytes())
        for s in stages:
            env = guard()
            record = next(x for x in result['stage_inventory'] if x['id']==s['id'])
            record['status']='IN_PROGRESS'
            atomic_json(path,result,replace=True)
            stage_dir = directory/s['id']
            metadata = {'execution_id':run_id,'environment':env,'freeze':artifact(FREEZE),
                        'candidate_sha256':f['candidate_sha256']}
            if s['kind']=='STARTUP':
                argv = [sys.executable,'-B','-m','pytest','-q',signature['source_path'],'-o','addopts=',
                    '-p','no:cacheprovider','-p','v0_2.tests.data.tracking_qualification.r45c_startup_development_adapter',
                    '-p','v0_2.tests.data.tracking_qualification.r45c_i_pytest_capture',
                    '--c2c-evidence-dir',str(stage_dir),'--junitxml',str(stage_dir/'junit.xml')]
                parser = lambda d,rc:json.loads((d/'pytest_results.json').read_bytes())
                gate = lambda r,rc:judge_persisted(stage_dir,rc,signature)
            else:
                argv = [sys.executable,'-B','-m',WORKER,'--authorization',str(auth_path),'--kind',s['kind']]
                data = None
                if 'case' in s:
                    argv += ['--case',s['case']]
                if s['kind']=='ITQ':
                    data = directory/(s['id']+'-input-reference.json')
                    atomic_json(data,s['entry'])
                elif s['kind']=='PREFIX_REPEAT':
                    data = directory/(s['id']+'-reference.json')
                    atomic_json(data,{'source_result':str(directory/s['source_stage']/'structured_result.json'),
                                     'source_kind':s['source_kind'],**({'entry':s['entry']} if 'entry' in s else {})})
                elif s.get('case')=='ST-12':
                    data = directory/'U-fresh'/'structured_result.json'
                if data is not None:
                    argv += ['--data',str(data)]
                    metadata['source_data_artifact']=artifact(data)
                    result['data_references'].append(metadata['source_data_artifact'])
                    atomic_json(path,result,replace=True)
                parser = lambda d,rc,stage=s:load_worker(d,rc,stage)
                gate = gate_worker
            stage = run_stage(stage_dir,s['id'],argv,metadata,parser,gate)
            result['stages'].append(stage)
            record['status']=stage['gate']['status']
            atomic_json(path,result,replace=True)
            guard()
            if stage['gate']['status']!='PASS':
                invalid = stage['gate']['status']=='INVALID'
                result.update(status='INVALID' if invalid else 'COMPLETE',stopped_at=s['id'],
                    R4_6_GATE='INVALID_QUALIFICATION_EXECUTION' if invalid else 'FULL_FROZEN_ITQ_POST_REPAIR_REQUALIFICATION_FAIL')
                if not invalid:
                    result['candidate_status']='NOT_QUALIFIED'
                break
            if s['kind']=='ITQ':
                refs = materialize(stage_dir,s['entry'],run_id,ROOT)
                result['prefix_inventories'].extend(refs)
                atomic_json(path,result,replace=True)
                guard()
        else:
            result.update(status='COMPLETE',R4_6_GATE='FULL_FROZEN_ITQ_POST_REPAIR_REQUALIFICATION_PASS',
                candidate_status='REQUALIFIED_FOR_FROZEN_FIXTURE_DOMAIN',
                ORIGINAL_STARTUP_HISTORICAL_RESULT='49/50',VERSIONED_STARTUP_COMPATIBILITY_RESULT='PASS',
                versioned_sources=['U-fresh','U-fresh-prefix-repeat','ST-12','ST-12-prefix-repeat'],
                ITQ_FULL_51_QUALIFICATION='PASS',prefix_coverage='HISTORICAL_CONDITIONAL_NOT_EXHAUSTIVE')
        result['environment_after']=guard()
        result['finished_at']=now()
        atomic_json(path,result,replace=True)
    except Exception as ex:
        for r in result['stage_inventory']:
            if r['status']=='IN_PROGRESS':
                r['status']='INVALID'
        result.update(status='INVALID',R4_6_GATE='INVALID_QUALIFICATION_EXECUTION',
            candidate_status='DEVELOPMENT_VALIDATED_NOT_REQUALIFIED',error=type(ex).__name__+':'+str(ex),finished_at=now())
        atomic_json(path,result,replace=True)
    print(json.dumps({'execution_id':run_id,'gate':result['R4_6_GATE'],'manifest':artifact(path)},separators=(',',':')))


if __name__=='__main__':
    main()
