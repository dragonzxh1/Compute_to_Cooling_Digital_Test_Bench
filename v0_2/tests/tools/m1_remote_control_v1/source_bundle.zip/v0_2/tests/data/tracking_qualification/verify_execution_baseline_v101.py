"""Read-only check of R4.4A1's candidate execution baseline, no candidate import."""

import hashlib
import json
from pathlib import Path

from .verify_itq_preregistration import ROOT, canonical, sha, verify
from .itq_execution_spec_v101 import validate_expectation


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def check():
    original=verify()
    manifest=load(ROOT/"phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json")
    components=manifest["execution_baseline_components"]
    computed=hashlib.sha256(canonical(components)).hexdigest()
    assert computed==manifest["EXECUTION_BASELINE_HASH"]
    assert original["aggregate_sha256"]==components["original_suite_aggregate"]
    assert sha(ROOT/"phase5_r5_2_1r4_4a_itq_freeze_manifest.json")==components["original_freeze_sha256"]
    assert sha(ROOT/"phase5_r5_2_1r4_4_itq_preregistration.json")==components["original_preregistration_file_sha256"]
    here=Path(__file__).parent
    for field,name in (("harness_source_sha256","itq_execution_spec_v101.py"),
                       ("harness_tests_sha256","test_execution_spec_v101.py"),
                       ("baseline_validator_sha256","verify_execution_baseline_v101.py")):
        assert sha(here/name)==components[field]
    errata_path=ROOT/"phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json"
    assert sha(errata_path)==components["errata_sha256"]
    errata=load(errata_path)
    assert errata["ITQ_EXECUTION_SPEC_VERSION"]==components["execution_spec_version"]
    assert errata["candidate_output_used_to_choose_interpretation"] is False
    assert errata["timing_changes"] is False
    assert errata["field_mapping"]==components["comparison_semantics"]["field_mapping"]
    count=0
    for entry in manifest["planned_execution_matrix"]:
        assert sha(ROOT/entry["input_path"])==entry["input_sha256"]
        assert sha(ROOT/entry["expectation_path"])==entry["expectation_sha256"]
        expected=load(ROOT/entry["expectation_path"])
        interpretation=errata["all_case_interpretations"][entry["case_id"]]
        result=validate_expectation(expected,interpretation,load(ROOT/entry["input_path"]))
        assert result["status"]=="CONSISTENT",result
        timing={k:expected[k] for k in ("expected_public_state_milestones","terminal_timing_normativity","timing_rules","same_sample_reissue_guard","acceptance")}
        assert hashlib.sha256(canonical(timing)).hexdigest()==interpretation["unchanged_timing_sha256"]
        count+=1
    assert count==51 and len({v["case_id"] for v in manifest["planned_execution_matrix"]})==23
    for path,value in manifest["protected_source_sha256"].items():
        assert sha(ROOT/path)==value
    frozen=load(ROOT/"phase5_r5_2_1r4_4a_itq_freeze_manifest.json")
    assert sha(here/"run_itq_blind.py")==frozen["runner_sha256"]
    assert manifest["status"]=="CANDIDATE_FOR_USER_APPROVED_RERUN_FREEZE"
    assert manifest["candidate_executed_in_A1"] is False
    return {"integrity":"PASS","execution_baseline_hash":computed,"static_consistent_variants":count,
            "candidate_executed":False,"rerun_freeze_approved":False}


if __name__=="__main__":
    print(json.dumps(check(),sort_keys=True))
