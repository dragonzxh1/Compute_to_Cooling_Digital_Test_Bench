"""A1 synthetic/static checks only; never import or replay candidate behavior."""
import ast
import hashlib
import json
import sys
import tempfile
from pathlib import Path

from .r45c_i_evidence import artifact, atomic_json, canonical, sha, run_stage
from .r46_prefix import SELECTOR_SHA, SELECTOR_SOURCE, build, mandatory, materialize, select, verify_materialized
from .r46_runner import plan, gate_worker, load_worker, validate_authorization

ROOT = Path(__file__).resolve().parents[4]


def main():
    checks = {}
    def test(name, value):
        checks[name]=bool(value)
    def rejects(name, fn):
        try:
            fn()
        except Exception:
            test(name,True)
        else:
            test(name,False)
    rows = [{'time_ns':i,'plc_command':c,'quality':q} for i,(c,q) in enumerate([
        (.5,'VALID'),(.5,'VALID'),(.7,'VALID'),(.7,'INVALID'),(.7,'MISSING'),(.7,'VALID'),(.7,'VALID')])]
    records = [{'time_ns':i,'state':s} for i,s in enumerate([
        'STEADY_TRACKING','TRACKING_PROGRESS','HANDOFF_PENDING','INSUFFICIENT_MEASUREMENT',
        'TRACKING_FAULT_SUSPECTED','TRACKING_FAULT_CONFIRMED','TRACKING_FAULT_CONFIRMED'])]
    test('mandatory_boundaries',mandatory(rows)==[1,3,4,6,7])
    selection = select(rows,records)
    test('progress_trigger',selection['output_triggered_progress_lengths']==[2])
    test('every_confirmed_sample',selection['output_triggered_confirmed_lengths']==[6,7])
    test('suspected_not_a_trigger',5 not in selection['selected_prefix_lengths'])
    test('nonvalid_to_nonvalid_not_boundary',5 not in mandatory(rows))
    test('union_sorted_unique',selection['selected_prefix_lengths']==[1,2,3,4,6,7])
    test('not_exhaustive',len(selection['selected_prefix_lengths'])<len(rows))
    rejects('empty_rows_rejected',lambda:mandatory([]))
    rejects('incomplete_records_rejected',lambda:select(rows,records[:-1]))
    rejects('wrong_record_timestamp_rejected',lambda:select(rows,[dict(records[0],time_ns=-1)]+records[1:]))
    # Extract only the frozen selector function AST; replace replay with a fake.
    # This proves fidelity without importing run_itq_blind or a candidate.
    tree = ast.parse((ROOT/SELECTOR_SOURCE).read_text())
    func = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='prefixes')
    ns = {'run_candidate':lambda prefix,p,c:{'records':records[:len(prefix)]}}
    exec(compile(ast.Module(body=[func],type_ignores=[]),'<frozen-selector-only>','exec'),ns)
    original = ns['prefixes'](rows,{'records':records},None,None)
    test('original_selector_sha',sha(ROOT/SELECTOR_SOURCE)==SELECTOR_SHA)
    test('original_selector_equivalence',original['checked_prefix_lengths']==selection['selected_prefix_lengths'])
    test('synthetic_prefix_original_pass',original['pass'])
    registration = json.loads((ROOT/'phase5_r5_2_1r4_6_a_full_itq_requalification_registration.json').read_bytes())
    matrix = registration['exact_matrix']
    test('matrix_23_cases',len({e['case_id'] for e in matrix})==23)
    test('matrix_51_variants',len(matrix)==51)
    test('mandatory_674',sum(len(e['input_only_mandatory_prefix_lengths']) for e in matrix)==674)
    test('universe_2298',sum(e['observation_count'] for e in matrix)==2298)
    test('fixture_hashes',all(sha(ROOT/e['input_path'])==e['input_sha256'] and sha(ROOT/e['expectation_path'])==e['expectation_sha256'] for e in matrix))
    test('mandatory_inventory_consistent',all(mandatory(json.loads((ROOT/e['input_path']).read_bytes())['observations'])==e['input_only_mandatory_prefix_lengths'] for e in matrix))
    stages = plan(matrix)
    test('143_independent_stages',len(stages)==143)
    test('51_full_itq_stages',sum(s['kind']=='ITQ' for s in stages)==51)
    test('51_itq_prefix_stages',sum(s['kind']=='PREFIX_REPEAT' and s['source_kind']=='ITQ' for s in stages)==51)
    test('unique_stage_ids',len({s['id'] for s in stages})==len(stages))
    schema = json.loads((ROOT/'phase5_r5_2_1r4_6_a1_selected_inventory_schema.json').read_bytes())
    with tempfile.TemporaryDirectory(prefix='r46-synthetic-') as t:
        root = Path(t)
        fixture = root/'synthetic_input.json'
        atomic_json(fixture,{'observations':rows})
        entry = {'case_id':'SYNTHETIC-NOT-ITQ','physics_dt_ns':200000000,'input_path':str(fixture),
                 'input_sha256':sha(fixture),'observation_count':len(rows),
                 'input_only_mandatory_prefix_lengths':mandatory(rows),'eligible_prefix_universe':{'first':1,'last':len(rows)}}
        result = {'inputs':rows,'snapshot':{'records':records},'checks':{'frozen_comparator':True},'comparison':{'status':'PASS'}}
        payload = json.dumps(result,separators=(',',':'))
        stage = run_stage(root/'full','synthetic-full',[sys.executable,'-B','-c','print('+repr(payload)+')'],{},
            lambda d,rc:json.loads((d/'stdout.raw').read_bytes()),lambda r,rc:gate_worker(r,rc))
        test('write_before_gate_synthetic',stage['status']=='COMPLETE' and stage['gate']['status']=='PASS')
        refs = materialize(root/'full',entry,'synthetic-execution',ROOT)
        inv = verify_materialized(root/'full',entry,ROOT)
        test('schema_fields_complete',set(schema['required_fields'])==set(inv))
        test('raw_canonical_hashes_separate',all('RAW_FILE_SHA256' in r and 'CANONICAL_JSON_SHA256' in r for r in refs))
        rebuilt = build(rows,records,entry,inv['execution_id'],inv['generation_timestamp'],inv['full_run_raw_output'],inv['full_run_structured_output'])
        test('byte_deterministic_materialization',(root/'full/selected_prefix_inventory.json').read_bytes()==canonical(rebuilt)+b'\n')
        test('canonical_deterministic_materialization',canonical(inv)==canonical(rebuilt))
        rejects('missing_mandatory_rejected',lambda:build(rows,records,{**entry,'input_only_mandatory_prefix_lengths':[1]},'x','t',{},{}))
        rejects('invalid_universe_rejected',lambda:build(rows,records,{**entry,'eligible_prefix_universe':{'first':1,'last':8}},'x','t',{},{}))
        changed = dict(inv,selected_prefix_lengths=[1,2,3,4,5,6,7])
        atomic_json(root/'full/selected_prefix_inventory.json',changed,replace=True)
        rejects('inventory_hash_tamper_rejected',lambda:verify_materialized(root/'full',entry,ROOT))
        atomic_json(root/'full/selected_prefix_inventory_hashes.json',artifact(root/'full/selected_prefix_inventory.json'),replace=True)
        rejects('inventory_semantic_tamper_rejected',lambda:verify_materialized(root/'full',entry,ROOT))
        atomic_json(root/'full/selected_prefix_inventory.json',inv,replace=True)
        atomic_json(root/'full/selected_prefix_inventory_hashes.json',artifact(root/'full/selected_prefix_inventory.json'),replace=True)
        atomic_json(root/'full/structured_result.json',{},replace=True)
        rejects('source_hash_tamper_rejected',lambda:verify_materialized(root/'full',entry,ROOT))
        fail = run_stage(root/'failure','synthetic-fail',[sys.executable,'-B','-c',"print('{\"checks\":{\"a\":false}}')"],{},
            lambda d,rc:json.loads((d/'stdout.raw').read_bytes()),gate_worker)
        test('valid_fail_not_invalid',fail['gate']['status']=='FAIL' and fail['status']=='COMPLETE')
        bad = run_stage(root/'bad','synthetic-invalid',[sys.executable,'-B','-c',"print('not-json')"],{},
            lambda d,rc:json.loads((d/'stdout.raw').read_bytes()),gate_worker)
        test('malformed_not_behavioral_fail',bad['gate']['status']=='INVALID')
        atomic_json(root/'denied.json',{'EXECUTION_AUTHORIZED':'NO','scope':'R4.6_FULL_FROZEN_ITQ_POST_REPAIR'})
        rejects('no_authorization_rejected',lambda:validate_authorization(root/'denied.json'))
        atomic_json(root/'stdout.raw',{})
        rejects('incomplete_worker_result_rejected',lambda:load_worker(root,0,{'kind':'U'}))
        atomic_json(root/'stdout.raw',{'cases':{},'checks':{'all_cases_visited':True,'prefix_causality':True,'determinism':True}},replace=True)
        rejects('empty_prefix_evidence_rejected',lambda:load_worker(root,0,{'kind':'PREFIX_REPEAT'}))
        # Acceptance groups (C11/S17) are not source trace counts (C13/S19).
        historical = {
            'C':['C1','C2','C3_normal','C3_stuck','C4','C5','C6','C7','C8_normal','C8_stuck','C10','C11','C12'],
            'S':['S1','S2','S3','S4','S5','S6','S7','S8_normal','S8_stuck','S9_up_down','S9_down_up',
                 'S10','S11','S12','S13','S14','S15','S16','S16_variant']}
        for k,ids in historical.items():
            fake = {'cases':{i:{'inputs':rows,'snapshot':{'records':records}} for i in ids},
                    'checks':{str(i):True for i in range(12 if k=='C' else 18)}}
            atomic_json(root/'stdout.raw',fake,replace=True)
            test(k+'_source_trace_inventory_not_acceptance_count',load_worker(root,0,{'kind':k})==fake)
            fake['cases'].pop(ids[-1])
            atomic_json(root/'stdout.raw',fake,replace=True)
            rejects(k+'_missing_trace_invalid',lambda kind=k:load_worker(root,0,{'kind':kind}))
    forbidden = [k for k in sys.modules if k.startswith('v0_2.examples.phase5_r5') or k.endswith('test_phase5_r5_2_1r4_5c_lifecycle')]
    test('no_candidate_or_behavior_modules_imported',not forbidden)
    for p in ['r46_prefix.py','r46_worker.py','r46_runner.py','r46_selfcheck.py']:
        ast.parse((Path(__file__).parent/p).read_text())
    test('syntax_static_parse',True)
    result = {'schema':'r46-a1-static-synthetic-checks-v1','behavioral_execution_count':0,
              'check_count':len(checks),'passed':sum(checks.values()),'checks':checks,
              'behavior_modules_imported':forbidden}
    print(json.dumps(result,sort_keys=True,separators=(',',':')))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__=='__main__':
    main()
