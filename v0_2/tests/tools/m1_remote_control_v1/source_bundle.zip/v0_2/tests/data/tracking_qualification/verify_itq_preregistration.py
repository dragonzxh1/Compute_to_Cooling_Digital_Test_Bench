"""Read-only ITQ preregistration integrity check. Does not import the candidate."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    manifest_path = ROOT / "phase5_r5_2_1r4_4_itq_preregistration.json"
    evidence_path = ROOT / "phase5_r5_2_1r4_4_itq_preregistration_evidence.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
    assert manifest["execution_status"] == "PREREGISTERED_NOT_EXECUTED"
    assert manifest["ITQ_SUITE_STATUS"] == "CANDIDATE_FOR_USER_APPROVED_FREEZE"
    assert manifest["FULL_P_HISTORY_VALIDATION_AVAILABLE"] == "NO"
    assert evidence["all_hashes"]["manifest_sha256"] == sha(manifest_path)
    core = {k:v for k,v in manifest.items() if k not in ("manifest_core_sha256","aggregate_sha256","aggregate_method")}
    core_hash = hashlib.sha256(canonical(core)).hexdigest()
    assert core_hash == manifest["manifest_core_sha256"]
    assert evidence["all_hashes"]["manifest_core_sha256"] == core_hash
    digest_records = []
    for case in manifest["cases"]:
        expected_path = ROOT / case["expected_path"]
        expected = json.loads(expected_path.read_text(encoding="utf-8"))
        assert expected["case_id"] == case["case_id"]
        assert sha(expected_path) == case["expectation_sha256"]
        input_hashes = []
        for variant in case["fixture_variants"]:
            path = ROOT / variant["input_path"]
            data = json.loads(path.read_text(encoding="utf-8"))
            assert data["case_id"] == case["case_id"]
            assert data["physics_dt_ns"] == variant["physics_dt_ns"]
            assert sha(path) == variant["input_sha256"]
            assert all(.3 <= row["plc_command"] <= .9 for row in data["observations"])
            assert all(data["observations"][i]["time_ns"] < data["observations"][i+1]["time_ns"]
                       for i in range(len(data["observations"])-1))
            input_hashes.append(variant["input_sha256"])
        digest_records.append({"case_id":case["case_id"],"fixture_sha256":input_hashes,
                               "expectation_sha256":case["expectation_sha256"]})
    aggregate = hashlib.sha256(canonical({"manifest_core_sha256":core_hash,
                                          "inputs_and_expectations":digest_records,
                                          "normativity":manifest["timing_normativity_definitions"]})).hexdigest()
    assert aggregate == manifest["aggregate_sha256"] == evidence["all_hashes"]["aggregate_sha256"]
    for path, item in manifest["source_hashes_before_after"].items():
        assert item["before"] == item["after"] == sha(ROOT / path)
    assert evidence["candidate_execution"] == "NOT_PERFORMED"
    return {"case_count":len(manifest["cases"]),"fixture_count":sum(len(c["fixture_variants"]) for c in manifest["cases"]),
            "aggregate_sha256":aggregate,"integrity":"PASS","candidate_executed":False}


if __name__ == "__main__":
    print(json.dumps(verify(), sort_keys=True))
