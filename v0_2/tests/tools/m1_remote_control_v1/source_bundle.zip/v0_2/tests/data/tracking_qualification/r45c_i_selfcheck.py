"""Synthetic infrastructure checks only; never import/replay candidate or tests."""
import argparse
import copy
import hashlib
import importlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

from .r45c_i_evidence import (PersistenceFailure, artifact, atomic_bytes, atomic_json,
                            canonical, run_stage, sha)
from .r45c_i_startup_guard import judge_startup, judge_persisted

ROOT=Path(__file__).resolve().parents[4]


def synthetic_result(signature):
    ids=[f'synthetic.py::normal_{i}' for i in range(49)]+[signature['nodeid']]
    reports=[]
    for n in ids:
        for when in ('setup','call','teardown'):
            failed=n==signature['nodeid'] and when=='call'
            reports.append({'nodeid':n,'when':when,'outcome':'failed' if failed else 'passed',
                'wasxfail':None,'failure_identity':dict(signature) if failed else None})
    return {'schema':'c2c-pytest-structured-v1','session_complete':True,
            'exit_status':1,'collected_nodeids':ids,'reports':reports,'collection_errors':[]}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output-dir',required=True)
    args=p.parse_args()
    output=Path(args.output_dir).resolve()
    if not output.is_relative_to(ROOT):
        raise ValueError('SELF_CHECK_OUTPUT_MUST_BE_WITHIN_WORKSPACE')
    output.mkdir(parents=True,exist_ok=False)
    signature=json.loads((ROOT/'phase5_r5_2_1r4_5c_i_startup_legacy_signature.json').read_bytes())
    good=synthetic_result(signature)
    checks={}
    def check(name,condition):
        checks[name]=bool(condition)
    check('accept_exact_legacy_signature',judge_startup(good,1,signature)['status']=='PASS')
    call_index=next(i for i,r in enumerate(good['reports']) if r['outcome']=='failed')
    def changed(change):
        result=copy.deepcopy(good); change(result); return result
    cases={
        'reject_50_of_50':changed(lambda r:r['reports'][call_index].update(outcome='passed')),
        'reject_48_of_50':changed(lambda r:r['reports'][1].update(outcome='failed')),
        'reject_wrong_failed_node':changed(lambda r:(r['reports'][call_index].update(outcome='passed'),r['reports'][1].update(outcome='failed'))),
        'reject_wrong_assertion_same_node':changed(lambda r:r['reports'][call_index]['failure_identity'].update(assertion_line_1based=145)),
        'reject_wrong_assertion_expression':changed(lambda r:r['reports'][call_index]['failure_identity'].update(assertion_ast='different expression')),
        'reject_changed_source_hash':changed(lambda r:r['reports'][call_index]['failure_identity'].update(source_raw_sha256='0'*64)),
        'reject_49_pass_1_skip':changed(lambda r:r['reports'][call_index].update(outcome='skipped')),
        'reject_49_pass_1_error':changed(lambda r:r['reports'][call_index-1].update(outcome='failed')),
        'reject_incomplete_session':changed(lambda r:r.update(session_complete=False)),
        'reject_missing_failure_identity':changed(lambda r:r['reports'][call_index].update(failure_identity=None)),
        'reject_wrong_exception':changed(lambda r:r['reports'][call_index]['failure_identity'].update(exception_type='KeyError')),
        'reject_xfail':changed(lambda r:r['reports'][call_index].update(wasxfail='manufactured')),
        'reject_changed_collection':changed(lambda r:r['collected_nodeids'].pop()),
        'reject_duplicate_reports':changed(lambda r:r['reports'].__setitem__(0,dict(r['reports'][1]))),
        'reject_collection_error':changed(lambda r:r['collection_errors'].append('synthetic collection failure'))}
    for name,result in cases.items():
        check(name,judge_startup(result,1,signature)['status']!='PASS')
    check('reject_wrong_exitcode',judge_startup(good,0,signature)['status']!='PASS')
    atomic_json(output/'synthetic_guard_records.json',{'good':good,'negative_cases':cases})
    # Dummy subprocess: 2 MiB stdout, 64 KiB stderr. No pytest or candidate.
    argv=[sys.executable,'-B','-c',"import sys;sys.stdout.buffer.write(b'x'*2097152);sys.stderr.buffer.write(b'y'*65536)"]
    stage_dir=output/'large-dummy-stage'
    meta={'execution_id':'SYNTHETIC_ONLY','environment':{'hash':'SYNTHETIC_NOT_QUALIFICATION'},
          'harness_hashes':{},'candidate_hash':'NOT_EXECUTED','frozen_semantic_hashes':{},'protected_source_hashes':{}}
    gate_observations=[]
    def parser(d,rc):
        stdout,stderr=(d/'stdout.raw').read_bytes(),(d/'stderr.raw').read_bytes()
        return {'checks':{'all_stdout':stdout==b'x'*2097152,'all_stderr':stderr==b'y'*65536},
                'stdout_length':len(stdout),'stderr_length':len(stderr)}
    def gate(result,rc):
        pre=json.loads((stage_dir/'stage_manifest.json').read_bytes())
        gate_observations.append(pre['evidence_status']=='PERSISTED_BEFORE_GATE'
            and (stage_dir/'structured_result.json').is_file() and (stage_dir/'parser_result.json').is_file())
        return {'status':'PASS' if rc==0 and all(result['checks'].values()) else 'FAIL'}
    stage=run_stage(stage_dir,'dummy',argv,meta,parser,gate)
    check('large_raw_bytes_fully_persisted',stage['gate']['status']=='PASS')
    check('write_before_gate',all(gate_observations))
    original=sha(stage_dir/'stdout.raw')
    display='small intentionally truncated display'
    check('display_truncation_does_not_change_artifact',sha(stage_dir/'stdout.raw')==original and len(display)<128)
    check('raw_hash_matches_reread',original==hashlib.sha256(b'x'*2097152).hexdigest())
    summary=json.dumps({'stage_id':'dummy','status':stage['gate']['status'],'manifest':stage['manifest']})
    check('compact_console_summary',len(summary.encode())<1024)
    # Complete mock native pytest files; do not launch pytest.
    d=output/'synthetic-startup-stage';d.mkdir()
    atomic_bytes(d/'stdout.raw',b'synthetic raw stdout')
    atomic_bytes(d/'stderr.raw',b'')
    atomic_bytes(d/'junit.xml',b'<testsuites/>')
    atomic_json(d/'pytest_results.json',good)
    atomic_json(d/'structured_result.json',good)
    atomic_json(d/'stage_manifest.json',{'artifacts':[artifact(f) for f in d.iterdir()]})
    check('persisted_guard_reads_authoritative_file',judge_persisted(d,1,signature)['status']=='PASS')
    # Missing or altered raw data is never accepted.
    raw=(d/'stdout.raw').read_bytes(); (d/'stdout.raw').unlink()
    try:judge_persisted(d,1,signature); rejected=False
    except PersistenceFailure:rejected=True
    check('reject_missing_raw_artifact',rejected)
    atomic_bytes(d/'stdout.raw',raw+b'changed')
    try:judge_persisted(d,1,signature); rejected=False
    except PersistenceFailure:rejected=True
    check('reject_mismatched_artifact_hash',rejected)
    atomic_bytes(d/'stdout.raw',raw,replace=True)
    # A synthetically malformed JSON worker result is persisted INVALID.
    def invalid_parser(d,rc):return json.loads((d/'stdout.raw').read_bytes())
    bad=run_stage(output/'invalid-dummy-stage','invalid-dummy',
        [sys.executable,'-B','-c',"print('{broken')"],meta,invalid_parser,
        lambda r,rc:{'status':'INVALID' if r.get('status')=='INVALID' else 'FAIL'})
    check('malformed_structured_result_preserved_invalid',bad['status']=='INVALID')
    value={'number':0.0}
    rawjson=b'{ "number": 0.0 }\n'
    check('raw_canonical_hashes_distinct',hashlib.sha256(rawjson).hexdigest()!=hashlib.sha256(canonical(value)).hexdigest())
    check('canonical_recipe_reproducible',canonical(json.loads(rawjson))==canonical(value))
    # Imports only, no main()/execute()/candidate constructors.
    for name in ('r45c_i_evidence','r45c_i_startup_guard','r45c_i_pytest_capture','r45c_i_worker','r45c_i_runner'):
        importlib.import_module('v0_2.tests.data.tracking_qualification.'+name)
    check('harness_import_validation',True)
    # Invoke capture hooks with fabricated report objects, not a pytest session
    # or a test function. This tests path/line/AST identity and durable logging.
    capture=importlib.import_module('v0_2.tests.data.tracking_qualification.r45c_i_pytest_capture')
    hook_dir=output/'synthetic-hook-events';hook_dir.mkdir()
    capture._directory=hook_dir
    capture._state={'reports':[],'collection_errors':[],'collected_nodeids':[], 'session_complete':False}
    fake=SimpleNamespace(nodeid=signature['nodeid'],when='call',outcome='failed',failed=True,
        c2c_exception_type='AssertionError',longrepr=SimpleNamespace(reprcrash=SimpleNamespace(
            path=signature['source_path'],lineno=144,message='assert False')))
    capture.pytest_runtest_logreport(fake)
    captured=capture._state['reports'][-1]['failure_identity']
    check('capture_hook_exact_legacy_identity',all(captured[k]==signature[k] for k in (
        'source_path','source_raw_sha256','assertion_line_1based','assertion_ast','semantic_identifier','exception_type')))
    fake.longrepr.reprcrash.lineno=145
    capture.pytest_runtest_logreport(fake)
    check('capture_hook_wrong_line_not_recognized',capture._state['reports'][-1]['failure_identity']['semantic_identifier']=='UNRECOGNIZED_ASSERTION')
    fake.longrepr.reprcrash.lineno=144;fake.c2c_exception_type='KeyError'
    capture.pytest_runtest_logreport(fake)
    check('capture_hook_wrong_exception_not_recognized',capture._state['reports'][-1]['failure_identity']['semantic_identifier']=='UNRECOGNIZED_ASSERTION')
    check('capture_hook_events_durably_saved',len((hook_dir/'pytest_reports.jsonl').read_bytes().splitlines())==3)
    atomic_json(hook_dir/'synthetic_captured_reports.json',capture._state)
    check('candidate_not_imported',not any(n.endswith('phase5_r5_2_1r4_5c_lifecycle_engine') for n in sys.modules))
    result={'schema':'r45c-i-synthetic-selfcheck-v1','checks':checks,'pass':all(checks.values()),
            'test_kind':'INFRASTRUCTURE_SYNTHETIC_ONLY','candidate_executions':0,'behavioral_tests_executed':0,
            'dummy_subprocesses':2,'large_capture_stage':stage,'invalid_capture_stage':bad}
    atomic_json(output/'selfcheck_result.json',result)
    print(json.dumps({'pass':result['pass'],'checks':len(checks),'failed':[k for k,v in checks.items() if not v],
                      'artifact':artifact(output/'selfcheck_result.json')},separators=(',',':')))
    if not result['pass']:raise SystemExit(1)


if __name__=='__main__':main()
