"""Versioned ITQ execution-spec adapter; never imports or runs R4.3B.

The original R4.4 inputs/expectations and R4.4A runner remain untouched.
This module consumes static records supplied by a future A2 runner.
"""

from __future__ import annotations

from collections.abc import Mapping

VERSION = "1.0.1"
PUBLIC_STATES = frozenset({"STEADY_TRACKING", "HANDOFF_PENDING", "TRACKING_PROGRESS",
                           "TRACKING_FAULT_SUSPECTED", "TRACKING_FAULT_CONFIRMED",
                           "INSUFFICIENT_MEASUREMENT"})
TRACKING_CONTRIBUTION = {
    "STEADY_TRACKING": "NORMAL", "HANDOFF_PENDING": "NORMAL", "TRACKING_PROGRESS": "NORMAL",
    "TRACKING_FAULT_SUSPECTED": "DEGRADED", "TRACKING_FAULT_CONFIRMED": "FAULT",
    "INSUFFICIENT_MEASUREMENT": "NORMAL",
}
SEVERITY_ORDER = {"NORMAL": 0, "FF_DISABLED": 1, "DEGRADED": 2,
                  "DERATE_REQUESTED": 3, "PROTECTED": 4, "FAULT": 5}


class HarnessSchemaError(ValueError):
    """Candidate record or frozen expectation cannot be compared safely."""


def _direction_value(value: object, field: str) -> int | None:
    if value is None:
        return None
    if type(value) is not int or value not in (-1, 1):
        raise HarnessSchemaError(f"{field}: required -1, +1 or null")
    return value


def recovery_epoch_direction(record: Mapping) -> int | None:
    """The retained epoch's expected physical-motion direction after recovery.

    A closed epoch may still be retained. This value is not a general alias
    for the current deferred/outage obligation or proof that an epoch is active.
    """
    if "epoch_expected_direction" not in record:
        raise HarnessSchemaError("missing epoch_expected_direction")
    return _direction_value(record["epoch_expected_direction"], "epoch_expected_direction")


def outage_obligation_direction(record: Mapping) -> int | None:
    """Current direction during an invalid-measurement interval.

    R4.3B has two explicit lifecycle carriers: startup_outage_direction before
    a resolved pair and directional_obligation after one. Neither is silently
    replaced with epoch_expected_direction, which may describe a closed epoch.
    """
    if "startup_outage_direction" not in record or "directional_obligation" not in record:
        raise HarnessSchemaError("missing outage direction carrier fields")
    values = []
    for field in ("startup_outage_direction", "directional_obligation"):
        carrier = record[field]
        if carrier is None:
            continue
        if not isinstance(carrier, Mapping) or "direction" not in carrier:
            raise HarnessSchemaError(f"{field}: malformed direction carrier")
        values.append(_direction_value(carrier["direction"], f"{field}.direction"))
    if len(values) > 1 and values[0] != values[1]:
        raise HarnessSchemaError("conflicting outage direction carriers")
    return values[0] if values else None


def safety_errors(records: list[dict], expected: dict, erratum: dict) -> list[str]:
    if not records:
        raise HarnessSchemaError("empty candidate record sequence")
    safety = expected.get("safety")
    if not isinstance(safety, Mapping):
        raise HarnessSchemaError("missing frozen safety expectation")
    for key in ("highest", "allowed_intermediate", "forbidden"):
        if key not in safety:
            raise HarnessSchemaError(f"missing frozen safety.{key}")
    if safety["highest"] != erratum["original_highest_value"]:
        raise HarnessSchemaError("errata/original safety.highest mismatch")
    if safety["allowed_intermediate"] != erratum["original_allowed_intermediate"]:
        raise HarnessSchemaError("errata/original intermediate mismatch")
    if safety["forbidden"] != erratum["original_forbidden"]:
        raise HarnessSchemaError("errata/original forbidden mismatch")
    terminal = erratum["terminal_safety_state"]
    max_allowed = erratum["max_allowed_safety_severity"]
    intermediates = erratum["allowed_intermediate_safety_states"]
    forbidden = erratum["forbidden_safety_states"]
    if any(x not in SEVERITY_ORDER for x in [terminal, max_allowed, *intermediates, *forbidden]):
        raise HarnessSchemaError("unknown safety severity in errata")
    if SEVERITY_ORDER[terminal] > SEVERITY_ORDER[max_allowed]:
        raise HarnessSchemaError("terminal severity exceeds registered maximum")
    if any(SEVERITY_ORDER[x] > SEVERITY_ORDER[max_allowed] for x in intermediates):
        raise HarnessSchemaError("allowed intermediate exceeds registered maximum")
    states = [r.get("state") for r in records]
    if any(state not in PUBLIC_STATES for state in states):
        raise HarnessSchemaError("unknown/missing public tracking state")
    contributions = [TRACKING_CONTRIBUTION[state] for state in states]
    errors=[]
    if contributions[-1] != terminal:
        errors.append(f"TERMINAL_SAFETY:{contributions[-1]}!={terminal}")
    if max(SEVERITY_ORDER[x] for x in contributions) > SEVERITY_ORDER[max_allowed]:
        errors.append("MAX_ALLOWED_SAFETY_EXCEEDED")
    if any(x != terminal and x not in intermediates for x in contributions[:-1]):
        errors.append("UNLISTED_INTERMEDIATE_SAFETY")
    if any(x in forbidden for x in contributions):
        errors.append("FORBIDDEN_SAFETY_STATE")
    return errors


def _milestone_errors(records: list[dict], expected: dict) -> list[str]:
    errors=[]
    cursor=0
    for item in expected["expected_public_state_milestones"]:
        state=item["state"]
        mode=item["timing_normativity"]
        if mode not in ("EXACT_NORMATIVE", "ORDER_NORMATIVE", "WINDOW_NORMATIVE", "NON_NORMATIVE"):
            raise HarnessSchemaError("unknown timing normativity")
        if state == "FIRST_VALID_RECOVERY_MEASUREMENT":
            # Fixture-level fixed release is validated against the released
            # input separately, never inferred from candidate state.
            continue
        match=next((i for i in range(cursor,len(records)) if records[i]["state"]==state),None)
        if match is None:
            errors.append(f"ORDER_MILESTONE_MISSING:{state}")
            continue
        when=records[match].get("time_ns")
        if type(when) is not int:
            raise HarnessSchemaError("missing/wrong-type record time_ns")
        if mode == "EXACT_NORMATIVE":
            if "time_ns" not in item or type(item["time_ns"]) is not int:
                raise HarnessSchemaError("exact milestone lacks frozen timestamp")
            if when != item["time_ns"]:
                errors.append(f"EXACT_MILESTONE_TIME:{state}:{when}!={item['time_ns']}")
        elif mode == "WINDOW_NORMATIVE":
            bounds=item.get("frozen_window_ns")
            if not isinstance(bounds,list) or len(bounds)!=2 or any(type(x) is not int for x in bounds):
                raise HarnessSchemaError("window milestone lacks frozen window")
            if not bounds[0] <= when <= bounds[1]:
                errors.append(f"WINDOW_MILESTONE_TIME:{state}:{when}")
        cursor=match+1
    return errors


def compare_static(records: list[dict], expected: dict, erratum: dict,
                   *, invalid_windows_ns: list[list[int]] | None = None) -> dict:
    """Compare supplied static records; no candidate invocation or import."""
    try:
        if expected.get("case_id") != erratum.get("case_id"):
            raise HarnessSchemaError("case identity mismatch")
        errors=safety_errors(records,expected,erratum)
        errors.extend(_milestone_errors(records,expected))
        states=[r["state"] for r in records]
        if states[-1] != expected["expected_terminal_state"]:
            errors.append("TERMINAL_PUBLIC_STATE_MISMATCH")
        if expected["fault_expected"] and "TRACKING_FAULT_CONFIRMED" not in states:
            errors.append("FALSE_NEGATIVE_TRACKING_FAULT")
        if not expected["fault_expected"] and "TRACKING_FAULT_CONFIRMED" in states:
            errors.append("FALSE_POSITIVE_TRACKING_FAULT")
        if any(state in states for state in expected["forbidden_outcomes"] if state in PUBLIC_STATES):
            errors.append("FORBIDDEN_PUBLIC_STATE")
        if expected["expected_direction_behavior"] == "SUPERSEDE_TO_CURRENT_NEGATIVE_NET_DEMAND":
            if not invalid_windows_ns:
                raise HarnessSchemaError("direction case lacks frozen invalid window")
            start,end=invalid_windows_ns[0]
            during=[r for r in records if start <= r["time_ns"] < end and not r.get("valid",True)]
            after=[r for r in records if r["time_ns"] >= end and r.get("valid",False)]
            if not during or not after:
                errors.append("DIRECTION_EVALUATION_OPPORTUNITY_MISSING")
            else:
                during_directions=[outage_obligation_direction(r) for r in during]
                after_directions=[recovery_epoch_direction(r) for r in after]
                if -1 not in during_directions:
                    errors.append("OUTAGE_DIRECTION_NOT_SUPERSEDED")
                if -1 not in after_directions:
                    errors.append("RECOVERY_EPOCH_DIRECTION_NOT_NEGATIVE")
        return {"status":"FAIL" if errors else "PASS","errors":list(dict.fromkeys(errors))}
    except (HarnessSchemaError,KeyError,TypeError) as error:
        return {"status":"INVALID_EXECUTION","errors":[str(error)]}


def validate_expectation(expected: dict, erratum: dict, fixture: dict) -> dict:
    """Static consistency only: no candidate records and no behavioral verdict."""
    try:
        if expected["schema"] != "itq-expected-v1":
            raise HarnessSchemaError("unsupported expectation schema")
        if expected["case_id"] != erratum["case_id"] or fixture["case_id"] != expected["case_id"]:
            raise HarnessSchemaError("case identity mismatch")
        terminal=expected["expected_terminal_state"]
        if terminal not in PUBLIC_STATES or type(expected["fault_expected"]) is not bool:
            raise HarnessSchemaError("invalid terminal/fault classification")
        if erratum["terminal_safety_state"] != TRACKING_CONTRIBUTION[terminal]:
            raise HarnessSchemaError("terminal contribution contradicts Contract15A")
        original=expected["safety"]
        if erratum["allowed_intermediate_safety_states"] != original["allowed_intermediate"]:
            raise HarnessSchemaError("errata changes original allowed intermediate set")
        if erratum["forbidden_safety_states"] != original["forbidden"]:
            raise HarnessSchemaError("errata changes original forbidden set")
        original_bound=max([TRACKING_CONTRIBUTION[terminal],*original["allowed_intermediate"]],key=SEVERITY_ORDER.get)
        if erratum["max_allowed_safety_severity"] != original_bound:
            raise HarnessSchemaError("errata maximum not derived from original allowed set")
        if expected["fault_expected"] != (terminal == "TRACKING_FAULT_CONFIRMED"):
            raise HarnessSchemaError("fault classification inconsistent with terminal")
        # This static dummy record validates only Safety schema dimensions;
        # it is not a candidate trace or an ITQ behavioral result.
        safety_errors([{"state":terminal}],expected,erratum)
        if terminal in erratum["forbidden_safety_states"] or any(
                x in erratum["forbidden_safety_states"] for x in erratum["allowed_intermediate_safety_states"]):
            raise HarnessSchemaError("forbidden severity also explicitly allowed")
        if expected["terminal_timing_normativity"] != "ORDER_NORMATIVE":
            raise HarnessSchemaError("unsupported frozen terminal normativity")
        if expected["acceptance"]["terminal_required_by_duration_ns"] != fixture["duration_ns"]:
            raise HarnessSchemaError("registered observation horizon mismatch")
        for milestone in expected["expected_public_state_milestones"]:
            mode=milestone["timing_normativity"]
            if mode not in ("EXACT_NORMATIVE","ORDER_NORMATIVE","WINDOW_NORMATIVE","NON_NORMATIVE"):
                raise HarnessSchemaError("unknown milestone timing mode")
            if milestone["state"] not in PUBLIC_STATES | {"FIRST_VALID_RECOVERY_MEASUREMENT"}:
                raise HarnessSchemaError("unknown milestone state/event")
            if mode == "EXACT_NORMATIVE":
                if type(milestone.get("time_ns")) is not int or not 0 <= milestone["time_ns"] <= fixture["duration_ns"]:
                    raise HarnessSchemaError("exact milestone lacks in-domain frozen timestamp")
            if mode == "WINDOW_NORMATIVE":
                window=milestone.get("frozen_window_ns")
                if not isinstance(window,list) or len(window)!=2 or any(type(x) is not int for x in window) or window[0]>window[1]:
                    raise HarnessSchemaError("no admissible frozen window")
            if milestone["state"] == "FIRST_VALID_RECOVERY_MEASUREMENT":
                released=next((row for row in fixture["observations"] if row["time_ns"]==milestone["time_ns"]),None)
                if released is None or released["quality"] != "VALID" or released["release_ns"] != milestone["time_ns"]:
                    raise HarnessSchemaError("fixture recovery release mismatch")
        return {"status":"CONSISTENT","case_id":expected["case_id"],"behavior_evaluated":False}
    except (HarnessSchemaError,KeyError,TypeError) as error:
        return {"status":"INCONSISTENT","errors":[str(error)],"behavior_evaluated":False}


def compare_snapshot(snapshot: dict, expected: dict, erratum: dict, fixture: dict) -> dict:
    """Future-run entry point preserving the original comparator's other checks.

    Snapshot and released input are supplied by a future authorized runner.
    This function has no candidate execution capability.
    """
    if validate_expectation(expected,erratum,fixture)["status"] != "CONSISTENT":
        return {"status":"INVALID_EXECUTION","errors":["inconsistent execution expectation"]}
    result=compare_static(snapshot.get("records",[]),expected,erratum,
                          invalid_windows_ns=fixture["measurement_timeline"]["invalid_windows_ns"])
    if result["status"] == "INVALID_EXECUTION":
        return result
    try:
        records=snapshot["records"]
        rows=fixture["observations"]
        if len(records)!=len(rows):
            raise HarnessSchemaError("candidate/input record count mismatch")
        errors=list(result["errors"])
        for record,row in zip(records,rows):
            if record["time_ns"] != row["time_ns"]:
                raise HarnessSchemaError("candidate/input timestamp mismatch")
            if row["quality"] != "VALID" and record["state"] != "INSUFFICIENT_MEASUREMENT":
                errors.append("INVALID_MEASUREMENT_EARNED_TRACKING_STATE")
        guard=expected.get("same_sample_reissue_guard")
        if guard:
            at=next((r for r in records if r["time_ns"]==guard["time_ns"]),None)
            if at and at["state"] == "TRACKING_FAULT_CONFIRMED":
                errors.append("SAME_SAMPLE_STALE_CONFIRMATION")
        if expected["safety"]["confirmed_fault_latched"] and snapshot.get("confirmed_latched") is not True:
            errors.append("FAULT_NOT_LATCHED")
        if "PERMANENT_HANDOFF_PENDING" in expected["forbidden_outcomes"] and records[-1]["state"]=="HANDOFF_PENDING":
            errors.append("DIRECTION_LOCK_OR_PENDING_TRAP")
        if expected["expected_watch_behavior"]=="PRESERVE_OLDEST_UNRESOLVED":
            starts=[e["watch_start_ns"] for e in snapshot["watch_events"] if e["event"]=="START"]
            carried=[e["watch_start_ns"] for e in snapshot["watch_events"] if e.get("event")=="CARRY_ACROSS_REVERSAL"]
            if len(starts)>1 or (starts and any(x!=starts[0] for x in carried)):
                errors.append("WATCH_AGE_ERASURE")
        return {"status":"FAIL" if errors else "PASS","errors":list(dict.fromkeys(errors))}
    except (HarnessSchemaError,KeyError,TypeError) as error:
        return {"status":"INVALID_EXECUTION","errors":[str(error)]}
