"""Strict historical failure identity; no terminal-summary parsing."""
import ast
import json
from pathlib import Path

from .r45c_i_evidence import validate_artifacts


def judge_startup(result, returncode, signature):
    invalid = lambda reason: {'status': 'INVALID', 'reason': reason}
    if (result.get('schema') != 'c2c-pytest-structured-v1' or not result.get('session_complete')
            or result.get('status') == 'INVALID' or result.get('collection_errors')):
        return invalid('INCOMPLETE_STARTUP_STRUCTURED_RESULT')
    ids, reports = result.get('collected_nodeids', []), result.get('reports', [])
    if len(ids) != 50 or len(set(ids)) != 50 or len(reports) != 150:
        return invalid('STARTUP_COLLECTION_OR_REPORT_INVENTORY')
    indexed = {(r.get('nodeid'), r.get('when')): r for r in reports}
    if len(indexed) != 150 or set(indexed) != {(n,w) for n in ids for w in ('setup','call','teardown')}:
        return invalid('STARTUP_PHASE_REPORT_INVENTORY')
    if any(r.get('wasxfail') is not None or r.get('outcome') not in ('passed','failed') for r in reports):
        return invalid('STARTUP_SKIP_XFAIL_OR_UNKNOWN_OUTCOME')
    if any(indexed[n,w]['outcome'] != 'passed' for n in ids for w in ('setup','teardown')):
        return invalid('STARTUP_SETUP_TEARDOWN_ERROR')
    passed = [n for n in ids if indexed[n,'call']['outcome'] == 'passed']
    failed = [n for n in ids if indexed[n,'call']['outcome'] == 'failed']
    counts = {'collected':len(ids), 'passed':len(passed), 'failed':len(failed), 'skipped':0, 'errors':0}
    if returncode != 1 or result.get('exit_status') != returncode or len(passed) != 49 or failed != [signature['nodeid']]:
        return {'status': 'FAIL', 'reason':'UNEXPECTED_ORIGINAL_STARTUP_RESULT', 'counts':counts}
    crash = indexed[failed[0],'call'].get('failure_identity')
    if not crash:
        return invalid('INSUFFICIENT_STARTUP_FAILURE_IDENTITY')
    required = ('source_path','source_raw_sha256','assertion_line_1based','assertion_ast',
                'semantic_identifier','exception_type')
    if any(crash.get(k) != signature[k] for k in required):
        return invalid('INSUFFICIENT_STARTUP_FAILURE_IDENTITY')
    return {'status':'PASS', 'ORIGINAL_STARTUP_HISTORICAL_RESULT':'49/50',
            'counts':counts, 'exact_legacy_failure':crash,
            'VERSIONED_STARTUP_COMPATIBILITY_RESULT':'PENDING_INDEPENDENT_VERSIONED_RESULTS'}


def judge_persisted(directory, returncode, signature):
    directory = Path(directory)
    manifest = json.loads((directory/'stage_manifest.json').read_bytes())
    validate_artifacts(manifest['artifacts'])
    paths = {Path(r['path']).name for r in manifest['artifacts']}
    if not {'stdout.raw','stderr.raw','structured_result.json','pytest_results.json','junit.xml'} <= paths:
        return {'status':'INVALID','reason':'MISSING_STARTUP_AUTHORITATIVE_ARTIFACT'}
    result = json.loads((directory/'structured_result.json').read_bytes())
    return judge_startup(result, returncode, signature)


def assertion_identity(source, lineno):
    tree = ast.parse(Path(source).read_text(encoding='utf-8'))
    matches = [n for n in ast.walk(tree) if isinstance(n, ast.Assert) and n.lineno == lineno]
    return ast.dump(matches[0], include_attributes=False) if len(matches) == 1 else None
