"""R4.6 dedicated worker. Separate frozen-qualification authorization required."""
import argparse
import json
from pathlib import Path


def execute(kind, case=None, data=None):
    if kind != 'PREFIX_REPEAT':
        # Reuse immutable support acceptance and approved ITQ comparator, not
        # the development runner, its targeted matrix or exhaustive ITQ prefix.
        from .r45c_i_worker import execute as observed
        return observed(kind, case, data)
    from . import run_r45c_g_frozen_development as old
    from . import run_r45c_development as development
    from v0_2.tests.control import test_phase5_r5_2_1r4_5c_lifecycle as st
    from .r46_prefix import verify_materialized
    reference = json.loads(Path(data).read_bytes())
    source_path = Path(reference['source_result'])
    source = json.loads(source_path.read_bytes())
    inv = None
    if reference['source_kind'] == 'ITQ':
        inv = verify_materialized(source_path.parent, reference['entry'], old.ROOT)
    results = {}
    for name, c in source.get('cases', {'one':source}).items():
        run = (lambda rows: development.replay(rows, st.PROFILE, st.CLASSIFIER)) if c['replay_kind']=='generic' else (lambda rows, k=c['replay_kind']:st.replay(k, rows))
        rows, snap = c['inputs'], c['snapshot']
        lengths = inv['selected_prefix_lengths'] if inv else list(range(1,len(rows)+1))
        failures = []
        for n in lengths:
            partial = run(rows[:n])
            if partial['records'] != snap['records'][:n]:
                failures.append(n)
                break
        hashes = [old.digest(snap)]
        # Original qualification P15: baseline + ten additional fresh replays.
        additional = 10 if reference['source_kind'] in ('C','S','P15') else 1
        if not failures:
            for _ in range(additional):
                hashes.append(old.digest(run(rows)))
                if hashes[-1] != hashes[0]:
                    break
        results[name] = {'selected_prefix_lengths':lengths, 'prefix_failures':failures,
                         'repeat_hashes':hashes, 'required_full_snapshot_count':additional+1}
        if failures or len(hashes)!=additional+1 or len(set(hashes))!=1:
            break
    return {'cases':results, 'checks':{
        'all_cases_visited':len(results)==len(source.get('cases', {'one':source})),
        'prefix_causality':all(not r['prefix_failures'] for r in results.values()),
        'determinism':all(len(r['repeat_hashes'])==r['required_full_snapshot_count'] and len(set(r['repeat_hashes']))==1 for r in results.values())}}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--authorization',required=True)
    p.add_argument('--kind',required=True)
    p.add_argument('--case')
    p.add_argument('--data')
    args = p.parse_args()
    from .r46_runner import validate_authorization, integrity
    approval = validate_authorization(args.authorization)
    integrity(approval)
    print(json.dumps(execute(args.kind,args.case,args.data),sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False))


if __name__=='__main__':
    main()
