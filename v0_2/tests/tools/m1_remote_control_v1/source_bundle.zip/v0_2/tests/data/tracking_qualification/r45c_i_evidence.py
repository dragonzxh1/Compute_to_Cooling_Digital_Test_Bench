"""Local authoritative artifacts; Python JSON numeric types are preserved."""
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path


class PersistenceFailure(RuntimeError):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def atomic_bytes(path, content, *, replace=False):
    path = Path(path)
    if path.exists() and not replace:
        raise PersistenceFailure('REFUSE_OVERWRITE:' + str(path))
    temp = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=path.parent, delete=False) as f:
            temp = Path(f.name)
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    except Exception as ex:
        raise PersistenceFailure('EXECUTION_EVIDENCE_PERSISTENCE_FAILURE:' + str(ex)) from ex
    finally:
        if temp is not None and temp.exists():
            temp.unlink()


def atomic_json(path, value, *, replace=False):
    atomic_bytes(path, canonical(value) + b'\n', replace=replace)


def artifact(path):
    path = Path(path)
    r = {'path': str(path.resolve()), 'RAW_FILE_SHA256': sha(path), 'bytes': path.stat().st_size}
    if path.suffix == '.json':
        value = json.loads(path.read_bytes())
        r['CANONICAL_JSON_SHA256'] = hashlib.sha256(canonical(value)).hexdigest()
    return r


def validate_artifacts(records):
    for r in records:
        if not Path(r['path']).is_file() or sha(r['path']) != r['RAW_FILE_SHA256']:
            raise PersistenceFailure('MISSING_OR_MISMATCHED_ARTIFACT:' + r['path'])


def run_stage(directory, stage_id, argv, metadata, parser, gate):
    """Raw/structured/pre-gate manifest durable before invoking acceptance gate.

    Child stdout/stderr go straight to files, never through console transport.
    IN_PROGRESS survives a crash; COMPLETE is only written after persisted gate.
    """
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=False)
    m = {**metadata, 'stage_id': stage_id, 'status': 'IN_PROGRESS',
         'argv': list(argv), 'working_directory': str(Path.cwd()),
         'python_executable': sys.executable, 'start_timestamp': now(), 'artifacts': []}
    manifest = directory / 'stage_manifest.json'
    atomic_json(manifest, m)
    stdout, stderr = directory/'stdout.raw', directory/'stderr.raw'
    try:
        with stdout.open('xb') as out, stderr.open('xb') as err:
            process = subprocess.run(argv, stdout=out, stderr=err, cwd=Path.cwd())
            out.flush(); os.fsync(out.fileno())
            err.flush(); os.fsync(err.fileno())
        m.update(end_timestamp=now(), process_exit_code=process.returncode)
        m['artifacts'] = [artifact(stdout), artifact(stderr)]
        atomic_json(manifest, m, replace=True)
        # Parser reads saved files; preserve malformed data and raw artifacts.
        try:
            result = parser(directory, process.returncode)
        except Exception as ex:
            result = {'status': 'INVALID', 'error': type(ex).__name__ + ':' + str(ex)}
        result_file = directory/'structured_result.json'
        atomic_json(result_file, result)
        # Native pytest/worker result artifacts are included as well.
        for p in sorted(directory.iterdir()):
            if p.is_file() and p not in (manifest, stdout, stderr):
                m['artifacts'].append(artifact(p))
        parsed = {'structured_result': artifact(result_file), 'exit_code': process.returncode,
                  'parse_complete': result.get('status') != 'INVALID'}
        parser_file = directory/'parser_result.json'
        atomic_json(parser_file, parsed)
        m['artifacts'].append(artifact(parser_file))
        m['evidence_status'] = 'PERSISTED_BEFORE_GATE'
        atomic_json(manifest, m, replace=True)
        validate_artifacts(m['artifacts'])
        decision = gate(result, process.returncode)
        gate_file = directory/'gate_result.json'
        atomic_json(gate_file, decision)
        m['artifacts'].append(artifact(gate_file))
        m.update(status='INVALID' if decision['status'] == 'INVALID' else 'COMPLETE',
                 gate=decision, final_timestamp=now())
        atomic_json(manifest, m, replace=True)
        validate_artifacts(m['artifacts'])
        return {'stage_id': stage_id, 'status': m['status'], 'gate': decision,
                'manifest': artifact(manifest), 'artifacts': m['artifacts']}
    except Exception as ex:
        m.update(status='INVALID', error=type(ex).__name__+':'+str(ex), end_timestamp=now())
        try:
            atomic_json(manifest, m, replace=True)
        except Exception:
            pass
        raise PersistenceFailure('EXECUTION_EVIDENCE_PERSISTENCE_FAILURE:' + str(ex)) from ex
