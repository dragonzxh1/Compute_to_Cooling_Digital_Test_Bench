"""Version I infrastructure: no behavior without separate hash-bound approval."""
import argparse
import json
import sys
import uuid
from pathlib import Path

from .r45c_i_evidence import (PersistenceFailure, artifact, atomic_json, canonical, now,
                            run_stage, sha, validate_artifacts)
from .r45c_i_startup_guard import judge_persisted

ROOT = Path(__file__).resolve().parents[4]
FREEZE = ROOT/'phase5_r5_2_1r4_5c_i_execution_harness_freeze.json'
WORKER = 'v0_2.tests.data.tracking_qualification.r45c_i_worker'


def validate_authorization(path):
    approval = json.loads(Path(path).read_bytes())
    if (approval.get('EXECUTION_AUTHORIZED') != 'GRANTED'
        or approval.get('scope') != 'R4.5C_FULL_DEVELOPMENT_ONLY'
        or approval.get('approved_harness_freeze_raw_sha256') != sha(FREEZE)):
        raise RuntimeError('SEPARATE_HASH_BOUND_USER_EXECUTION_AUTHORIZATION_REQUIRED')
    return approval


def load_worker(directory, exitcode):
    if exitcode != 0:
        return {'status':'INVALID','error':'WORKER_PROCESS_NONZERO'}
    return json.loads((directory/'stdout.raw').read_bytes())


def worker_gate(result, exitcode):
    if exitcode != 0 or result.get('status') == 'INVALID':
        return {'status':'INVALID','reason':'WORKER_OR_PARSER_INVALID'}
    checks = result.get('checks')
    if not isinstance(checks,dict) or not checks or any(type(v) is not bool for v in checks.values()):
        return {'status':'INVALID','reason':'INCOMPLETE_BOOLEAN_CHECK_INVENTORY'}
    return {'status':'PASS' if all(checks.values()) else 'FAIL',
            'failed_predicates':[k for k,v in checks.items() if not v]}


def plan(freeze):
    stages = [{'id':'U-initial','kind':'U'}, {'id':'U-fresh','kind':'U'}]
    stages += [{'id':f'ST-{i:02}','kind':'ST','case':f'ST-{i:02}'} for i in range(1,17)]
    stages += [{'id':f'ITQ-target-{i:02}','kind':'ITQ','entry':e} for i,e in enumerate(freeze['targeted_execution_matrix'],1)]
    stages += [{'id':'Startup-original','kind':'STARTUP'}, {'id':'C-history','kind':'C'},
               {'id':'S-history','kind':'S'}, {'id':'P15-history','kind':'P15'}]
    expanded = []
    for s in stages:
        expanded.append(s)
        if s['kind']!='STARTUP':
            expanded.append({'id':s['id']+'-prefix-repeat','kind':'PREFIX_REPEAT','source_stage':s['id']})
    return expanded


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--authorization', required=True)
    parser.add_argument('--output-root', default=str(ROOT/'artifacts/r45c-i-executions'))
    args = parser.parse_args()
    # Without explicit new authorization, no candidate import/launch occurs.
    authorization = validate_authorization(Path(args.authorization).resolve())
    freeze = json.loads(FREEZE.read_bytes())
    output_root = Path(args.output_root).resolve()
    if not output_root.is_relative_to(ROOT):
        raise RuntimeError('OUTPUT_ROOT_MUST_BE_IN_WORKSPACE')
    run_id = 'r45c-i-'+uuid.uuid4().hex
    directory = output_root/run_id
    directory.mkdir(parents=True,exist_ok=False)
    stages = plan(freeze)
    final_path = directory/'run_manifest.json'
    final = {'schema':'c2c-execution-run-v1','execution_id':run_id,'status':'IN_PROGRESS',
        'started_at':now(),'authorization':artifact(args.authorization),'harness_freeze':artifact(FREEZE),
        'frozen_baselines':freeze['upstream_canonical_hashes'],'source_hashes':freeze['protected_raw_hashes'],
        'harness_hashes':freeze['harness_raw_hashes'],'stages':[],
        'stage_inventory':[{**s,'status':'NOT_RUN'} for s in stages],
        'candidate_status':'DEVELOPMENT_VALIDATION_BLOCKED_NOT_REQUALIFIED',
        'full_51_qualification':'NOT_RUN','CAN_PRODUCTION_PORT_START':'NO',
        'FULL_P_HISTORY_VALIDATION_AVAILABLE':'NO','REAL_HARDWARE':'CALIBRATION_REQUIRED',
        'PHASE6':'NO','GIT_COMMIT_PUSH':'NO'}
    atomic_json(final_path,final)
    def integrity():
        validate_artifacts([final['authorization'],final['harness_freeze']])
        for p,h in {**freeze['protected_raw_hashes'],**freeze['harness_raw_hashes']}.items():
            if sha(ROOT/p)!=h:
                raise RuntimeError('HASH_DRIFT:'+p)
        import hashlib
        for p,h in freeze['upstream_canonical_hashes'].items():
            if hashlib.sha256(canonical(json.loads((ROOT/p).read_bytes()))).hexdigest()!=h:
                raise RuntimeError('CANONICAL_DRIFT:'+p)
        from .run_r45c_policy_a_development import verify_environment
        return verify_environment()
    try:
        env_before = integrity()
        final['environment_before'] = env_before
        atomic_json(final_path,final,replace=True)
        signature = json.loads((ROOT/freeze['startup_signature_path']).read_bytes())
        for s in stages:
            env = integrity()
            stage_dir = directory/s['id']
            next(x for x in final['stage_inventory'] if x['id']==s['id']).update(
                status='IN_PROGRESS',artifact_directory=str(stage_dir))
            atomic_json(final_path,final,replace=True)
            metadata = {'execution_id':run_id,'environment':env,'harness_hashes':freeze['harness_raw_hashes'],
                'candidate_hash':freeze['candidate_sha256'],'frozen_semantic_hashes':freeze['upstream_canonical_hashes'],
                'protected_source_hashes':freeze['protected_raw_hashes'],'authorization_sha256':sha(args.authorization)}
            if s['kind']=='STARTUP':
                argv = [sys.executable,'-B','-m','pytest','-q',signature['source_path'],'-o','addopts=',
                    '-p','no:cacheprovider','-p','v0_2.tests.data.tracking_qualification.r45c_startup_development_adapter',
                    '-p','v0_2.tests.data.tracking_qualification.r45c_i_pytest_capture',
                    '--c2c-evidence-dir',str(stage_dir),'--junitxml',str(stage_dir/'junit.xml')]
                def parse_pytest(d,rc):
                    result=json.loads((d/'pytest_results.json').read_bytes())
                    if result.get('collection_errors'):
                        result['status']='INVALID'
                    return result
                stage = run_stage(stage_dir,s['id'],argv,metadata,parse_pytest,
                    lambda r,rc:judge_persisted(stage_dir,rc,signature))
            else:
                argv = [sys.executable,'-B','-m',WORKER,'--kind',s['kind'],
                        '--authorization',str(Path(args.authorization).resolve())]
                if 'case' in s:
                    argv += ['--case',s['case']]
                data = None
                if s['kind']=='ITQ':
                    data = directory/(s['id']+'-input-reference.json')
                    atomic_json(data,s['entry'])
                elif s['kind']=='PREFIX_REPEAT':
                    data = directory/s['source_stage']/'structured_result.json'
                elif s.get('case')=='ST-12':
                    data = directory/'U-fresh'/'structured_result.json'
                if data is not None:
                    argv += ['--data',str(data)]
                    metadata['source_data_artifact'] = artifact(data)
                stage = run_stage(stage_dir,s['id'],argv,metadata,load_worker,worker_gate)
            final['stages'].append(stage)
            next(x for x in final['stage_inventory'] if x['id']==s['id'])['status']=stage['gate']['status']
            atomic_json(final_path,final,replace=True)
            print(json.dumps({'execution_id':run_id,'stage_id':s['id'],'status':stage['gate']['status'],
                              'manifest':stage['manifest']},separators=(',',':')),flush=True)
            integrity()
            if stage['gate']['status']!='PASS':
                final.update(status='INVALID' if stage['gate']['status']=='INVALID' else 'COMPLETE',
                    overall_gate='INVALID_EXECUTION' if stage['gate']['status']=='INVALID' else 'DEVELOPMENT_VALIDATION_FAILED_STOPPED',
                    stopped_at=s['id'])
                break
        else:
            # Compatibility derives from current separate persisted stages only.
            final.update(status='COMPLETE',ORIGINAL_STARTUP_HISTORICAL_RESULT='49/50',
                VERSIONED_STARTUP_COMPATIBILITY_RESULT='PASS',
                versioned_result_sources=['ST-12','ST-12-prefix-repeat','U-fresh','U-fresh-prefix-repeat'],
                overall_gate='WATCH_LIFECYCLE_REVISION_IMPLEMENTED_AND_DEVELOPMENT_VALIDATED',
                candidate_status='DEVELOPMENT_VALIDATED_NOT_REQUALIFIED')
        final['environment_after']=integrity()
        for stage in final['stages']:
            validate_artifacts([stage['manifest'],*stage['artifacts']])
        final['finished_at']=now()
        atomic_json(final_path,final,replace=True)
    except Exception as ex:
        for item in final['stage_inventory']:
            if item['status']=='IN_PROGRESS':
                item['status']='INVALID'
        final.update(status='INVALID',overall_gate='EXECUTION_EVIDENCE_PERSISTENCE_FAILURE'
            if isinstance(ex,PersistenceFailure) else 'INVALID_EXECUTION',
            error=type(ex).__name__+':'+str(ex),finished_at=now())
        atomic_json(final_path,final,replace=True)
    print(json.dumps({'execution_id':run_id,'gate':final['overall_gate'],
                      'run_manifest':artifact(final_path)},separators=(',',':')))


if __name__=='__main__':
    main()
