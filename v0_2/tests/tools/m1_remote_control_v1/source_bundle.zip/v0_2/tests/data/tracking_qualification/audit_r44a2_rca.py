"""Read-only provenance collector: no candidate imports, execution or restoration."""
import ast
import difflib
import hashlib
import json
import pathlib
import re
import subprocess

ROOT=pathlib.Path(__file__).resolve().parents[4]
SESSION=pathlib.Path('C:/Users/Aiden Zhang/.codex/sessions/2026/09/26/rollout-2026-09-26T14-08-48-01a0a525-b4e1-7671-82ca-7769895794e1_01a0dc54-9ffe-7742-889e-358bb0a34253.jsonl')
TARGET='itq_execution_spec_v101.py'
EXPECTED='456966aa0a6951cecedd55e63cc61f86c91b2c318f7d5d34d1b81e0ea43a47b8'
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def apply_memory(text, diff):
    old=text.splitlines(keepends=True); out=[]; cursor=0
    parts=diff.splitlines(keepends=True); i=0
    while i<len(parts):
        match=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',parts[i])
        if not match: i+=1; continue
        start=int(match[1])-1
        out.extend(old[cursor:start]); cursor=start; i+=1
        while i<len(parts) and not parts[i].startswith('@@'):
            line=parts[i]; i+=1
            if line.startswith((' ','-')):
                assert old[cursor].rstrip('\r\n')==line[1:].rstrip('\r\n'),(cursor,line)
                if line[0]==' ': out.append(old[cursor])
                cursor+=1
            elif line.startswith('+'): out.append(line[1:].rstrip('\r\n')+'\n')
            elif line.strip(): raise ValueError(line)
    out.extend(old[cursor:]); return ''.join(out)
def metadata(b):
    return {'size':len(b),'sha256':sha(b),'BOM':b.startswith(b'\xef\xbb\xbf'),'encoding':'UTF-8','CRLF':b.count(b'\r\n'),'LF':b.count(b'\n'),'trailing_newline':b.endswith(b'\n')}
def main():
    current=(ROOT/'v0_2/tests/data/tracking_qualification'/TARGET).read_bytes()
    events=[]; versions=[]; commands=[]; text=None
    for number,line in enumerate(SESSION.open(encoding='utf-8'),1):
        x=json.loads(line)
        if x.get('type')!='event_msg': continue
        item=x.get('payload',{}).get('item',{})
        if item.get('type')=='CommandExecution' and number<680:
            cmd=' '.join(item.get('command',[]))
            if any(s in cmd for s in ('prepare_r44a1_adjudication','verify_execution_baseline_v101','test_execution_spec_v101')):
                commands.append({'line':number,'timestamp':x['timestamp'],'command':cmd,'exit_code':item.get('exit_code'),'stdout':item.get('stdout')})
        for path,change in item.get('changes',{}).items():
            if not path.endswith(TARGET): continue
            if change['type']=='add': text=change['content']
            elif change['type']=='update': text=apply_memory(text,change['unified_diff'])
            b=text.encode('utf-8')
            versions.append((number,x['timestamp'],b))
            events.append({'line':number,'timestamp':x['timestamp'],'path':path,'change_type':change['type'],**metadata(b)})
    approved=next(((n,t,b) for n,t,b in versions if sha(b)==EXPECTED),None)
    diff=None; ast_equal=None; changed_functions=[]
    if approved:
        a=approved[2].decode(); c=current.decode()
        diff=''.join(difflib.unified_diff(a.splitlines(keepends=True),c.splitlines(keepends=True),fromfile='approved-log-reconstruction',tofile='current-working-file'))
        at=ast.parse(a); ct=ast.parse(c); ast_equal=ast.dump(at)==ast.dump(ct)
        af={n.name:ast.dump(n) for n in at.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        cf={n.name:ast.dump(n) for n in ct.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        changed_functions=[k for k in sorted(af.keys()|cf.keys()) if af.get(k)!=cf.get(k)]
    blobs=[]; matches=[]
    inventory=git('cat-file','--batch-all-objects','--batch-check=%(objectname) %(objecttype) %(objectsize)').decode().splitlines()
    for entry in inventory:
        oid,kind,size=entry.split()
        if kind!='blob' or not 8000<=int(size)<=25000: continue
        b=git('cat-file','blob',oid); blobs.append({'object':oid,'sha256':sha(b),'size':len(b)})
        if sha(b) in (EXPECTED,sha(current)): matches.append(blobs[-1])
    manifest=json.loads((ROOT/'phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json').read_text(encoding='utf-8'))
    protected={p:{'expected':h,'actual':sha((ROOT/p).read_bytes())} for p,h in manifest['protected_source_sha256'].items()}
    fixtures=[{'path':v['input_path'],'expected':v['input_sha256'],'actual':sha((ROOT/v['input_path']).read_bytes()),'expectation_path':v['expectation_path'],'expectation_expected':v['expectation_sha256'],'expectation_actual':sha((ROOT/v['expectation_path']).read_bytes())} for v in manifest['planned_execution_matrix']]
    result={'session_path':str(SESSION),'comparator_events':events,'commands':commands,'approved_recovery':{'exact_match':bool(approved),'session_line':approved[0] if approved else None,'timestamp':approved[1] if approved else None,'metadata':metadata(approved[2]) if approved else None},'current':metadata(current),'current_matches_prior_log_versions':[n for n,t,b in versions if b==current],'normalized_diff':diff,'ast_equal':ast_equal,'changed_functions':changed_functions,'git_object_inventory_count':len(inventory),'git_blobs_inspected':blobs,'git_matching_blobs':matches,'git_path_log':git('log','--all','--format=%H %aI %s','--','**/'+TARGET).decode(),'git_refs':git('show-ref').decode(),'git_reflog':git('reflog','--all','--format=%H %gD %gs').decode(),'git_stashes':git('stash','list').decode(),'protected_sources':protected,'fixtures_and_expectations':fixtures,'candidate_import_count':0,'candidate_execution_count':0}
    assert (ROOT/'v0_2/tests/data/tracking_qualification'/TARGET).read_bytes()==current
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__': main()
