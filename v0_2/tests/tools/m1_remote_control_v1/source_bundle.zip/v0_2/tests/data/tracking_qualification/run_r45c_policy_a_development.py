"""Versioned Policy A development validation; originals and candidate untouched.

Stop on a semantic defect before downstream development regression. Stdout only.
"""
import hashlib
import json
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[4]
ENV = 'phase5_r5_2_1r4_5c_d_environment_reregistration_manifest.json'
EXPECTED_ENV = 'f8bfda120c4b8954c20257d4aecc273b9bd792a5a50f534ea8e706d8237f4a3e'
EXPECTED_AMENDMENT = 'd86eaa34ba8720408b0001b97eb6a72a03bff52b8c97e951cd08154f1f167082'


def load(path):
    return json.loads((ROOT / path).read_text(encoding='utf-8-sig'))


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'),
                                   ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def verify_environment():
    # This helper reconstructs actual identity. No replay constructor is called.
    from . import run_r44a2_r4 as old
    with patch.object(old, 'ENV_MANIFEST', ENV), patch.object(old, 'ENV_HASH', EXPECTED_ENV):
        return old.environment()


def policy_a_checks(snapshot):
    """ST-12-POLICY-A-v1; predicates from approved amendment, not golden output.

    Uses unchanged ST-12 input. Fixed 1.2/1.4/2.6 times belong to that fixture;
    count 2 is the unchanged profile confirmation count, not a retuned threshold.
    """
    records = snapshot['records']
    at = {r['time_ns']: r for r in records}
    before, withdrawal, reissue = (at[t] for t in (1200000000, 1400000000, 2600000000))
    pause = [r for r in records if 1400000000 <= r['time_ns'] < 2600000000]
    start = [e for e in snapshot['watch_events'] if e['event'] == 'START']
    consumed = snapshot['response_history']
    count = load('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']['confirm_consecutive_qualified_samples']
    return {
        'ST12A-01_actual_prior_evidence': before['carried_suspicion_evidence'] == 1,
        'ST12A-02_old_evaluation_before_withdrawal': withdrawal['measurement_attribution'] == 'OLD_OBLIGATION'
            and any(e['evaluation_tick_ns'] == 1400000000 and e['old_command'] == .7 for e in consumed),
        'ST12A-03_post_evaluation_snapshot': withdrawal['carried_suspicion_evidence'] == count,
        'ST12A-04_earned_confirmed_latch_preserved': withdrawal['confirmed_latched']
            and all(r['confirmed_latched'] for r in records if r['time_ns'] >= 1400000000),
        'ST12A-05_one_watch_original_provenance': len(start) == 1
            and reissue['oldest_unresolved_demand_ns'] == 0,
        # Archived epoch direction is not an active directional obligation.
        # The freeze specifies inactivity, not a particular event name/null field.
        'ST12A-06_withdrawal_closes_direction_despite_latch':
            not withdrawal['current_direction_active']
            and withdrawal['directional_obligation'] is None,
        'ST12A-07_pause_preserves_post_snapshot_without_reevaluation':
            all(not r['current_direction_active'] and r['carried_suspicion_evidence'] == withdrawal['carried_suspicion_evidence']
                for r in pause)
            and not any(1400000000 < e['evaluation_tick_ns'] < 2600000000 for e in consumed),
        'ST12A-08_reissue_no_reset_or_new_stale_confirmation':
            reissue['oldest_unresolved_demand_ns'] == 0
            and reissue['carried_suspicion_evidence'] == withdrawal['carried_suspicion_evidence']
            and not any(t['time_ns'] == 2600000000 and t['to'] == 'TRACKING_FAULT_CONFIRMED'
                        for t in snapshot['transitions']),
        'ST12A-09_no_duplicate_source_credit': len({e['source_measurement_record_id'] for e in consumed}) == len(consumed),
        'ST12A-10_no_fake_progress_resolution_eventual_fault': snapshot['confirmed_latched']
            and not any(r['qualified_progress'] for r in records)
            and not any(e['event'] == 'RESOLVE' for e in snapshot['watch_events']),
    }


def main():
    amendment = load('phase5_r5_2_1r4_5c_c_same_tick_priority_amendment.json')
    approval = load('phase5_r5_2_1r4_5c_c_user_approved_priority_freeze.json')
    assert digest(amendment) == EXPECTED_AMENDMENT == approval['approved_amendment_canonical_sha256']
    assert approval['PRIORITY_SPEC_STATUS'] == 'FROZEN_USER_APPROVED'
    env_before = verify_environment()
    original = load('phase5_r5_2_1r4_5b_watch_retention_semantics_registration.json')
    approved = load('phase5_r5_2_1r4_5b_user_approved_semantic_freeze.json')
    assert digest(original) == approved['registration_canonical_sha256']
    assert digest(original['truth_table']) == approved['truth_table_canonical_sha256']
    assert digest(original['semantic_test_definitions']) == approved['semantic_tests_canonical_sha256']
    from v0_2.tests.control import test_phase5_r5_2_1r4_5c_lifecycle as st
    cases = []
    for definition in original['semantic_test_definitions']:
        case = definition['id']
        rows = st.inputs(case)
        result = st.replay(case, rows)
        checks = policy_a_checks(result) if case == 'ST-12' else st.checks(case, result)
        prefixes = [n for n in range(1, len(rows)+1)
                    if st.replay(case, rows[:n])['records'] != result['records'][:n]]
        repeats = [digest(result), digest(st.replay(case, rows))]
        passed = all(checks.values()) and not prefixes and len(set(repeats)) == 1
        cases.append({'case_id': 'ST-12-POLICY-A-v1' if case == 'ST-12' else case,
                      'status': 'PASS' if passed else 'FAIL', 'checks': checks,
                      'input_sha256': digest(rows), 'snapshot_sha256': digest(result),
                      'prefix_count': len(rows), 'prefix_failures': prefixes,
                      'repeat_hashes': repeats,
                      'released_inputs_on_failure': rows if not passed else None,
                      'snapshot_on_failure': result if not passed else None})
    passed = all(c['status'] == 'PASS' for c in cases)
    targeted = []
    historical = {'status': 'NOT_RUN'}
    if passed:
        from . import run_r45c_development as development
        from . import run_itq_blind as blind
        from . import run_r44a2_r4 as old
        from .itq_execution_spec_v101 import compare_snapshot
        from .verify_itq_preregistration import sha
        profile = st.PROFILE
        classifier = st.CLASSIFIER
        frozen = load('phase5_r5_2_1r4_5b_watch_retention_semantics_evidence.json')
        protected = dict(frozen['protected_sources']['before'])
        protected.update(frozen['frozen_itq']['before'])
        for path, expected in protected.items():
            assert sha(ROOT/path) == expected, path
        matrix = load('phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json')['planned_execution_matrix']
        errata = load('phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json')
        selected = {'ITQ-013','ITQ-014','ITQ-010','ITQ-012','ITQ-017','ITQ-019','ITQ-020','ITQ-021'}
        for entry in matrix:
            if entry['case_id'] not in selected:
                continue
            fixture, expected = load(entry['input_path']), load(entry['expectation_path'])
            rows = fixture['observations']
            snap = development.replay(rows, profile, classifier)
            compared = compare_snapshot(snap, expected, errata['all_case_interpretations'][entry['case_id']], fixture)
            if compared['status'] == 'INVALID_EXECUTION':
                raise RuntimeError(str(compared))
            with patch.object(blind, 'run_candidate', development.replay):
                prefixes = blind.prefixes(rows, snap, profile, classifier)
            repeats = [digest(snap), digest(development.replay(rows, profile, classifier))]
            targeted.append({**entry, **compared, 'prefix_causality': prefixes, 'repeat_hashes': repeats,
                             'snapshot_on_failure': snap if compared['status'] != 'PASS' else None})
        # Preserve historical bodies and scores. Versioned policy amendment is
        # reported separately; do not relabel the unchanged original ST12 test.
        def startup_with_summary(args, **kwargs):
            return development.startup_adapter(args + ['-o', 'addopts='], **kwargs)

        with patch.object(old, 'ENV_MANIFEST', ENV), patch.object(old, 'ENV_HASH', EXPECTED_ENV), \
             patch.object(old, 'run_candidate', development.replay), \
             patch.object(old.subprocess, 'run', startup_with_summary):
            h = old.historical(profile, classifier, protected)
        historical = {'startup': h['startup'],
                      'C': {k:h['C'][k] for k in ('pass','fail','total','criteria','fresh_snapshot_hashes')},
                      'S': {k:h['S'][k] for k in ('pass','fail','total','criteria','fresh_snapshot_hashes')},
                      'P15': {k:h['P15'][k] for k in ('status','checks','class','prefix_count','repeat_sha256_10x')},
                      'pass': h['pass']}
    complete_pass = (passed and len(targeted) == 12
                    and all(t['status'] == 'PASS' and t['prefix_causality']['pass']
                            and len(set(t['repeat_hashes'])) == 1 for t in targeted)
                    and historical.get('pass', False))
    evidence = {'schema': 'r45c-policy-a-development-rerun-v1',
                'classification': 'DEVELOPMENT_VALIDATION_NOT_REQUALIFICATION',
                'environment_before': env_before, 'environment_after': verify_environment(),
                'approved_amendment_hash': EXPECTED_AMENDMENT, 'semantic_tests': cases,
                'semantic_pass': sum(c['status'] == 'PASS' for c in cases), 'semantic_total': len(cases),
                'downstream_regression_status': 'NOT_RUN_SEMANTIC_GATE_FAILED' if not passed else 'EXECUTED',
                'targeted_ITQ': targeted, 'historical': historical,
                'CANDIDATE_STATUS': 'DEVELOPMENT_VALIDATED_NOT_REQUALIFIED' if complete_pass
                    else 'DEVELOPMENT_VALIDATION_FAILED_OR_COMPATIBILITY_BLOCKED_NOT_REQUALIFIED',
                'CAN_PRODUCTION_PORT_START': 'NO', 'FULL_P_HISTORY_VALIDATION_AVAILABLE': 'NO',
                'REAL_HARDWARE': 'CALIBRATION_REQUIRED', 'full_51_qualification_executed': False,
                'candidate_modified': False, 'original_tests_modified': False,
                'git_commit_push': False, 'phase6_started': False}
    print(json.dumps(evidence, ensure_ascii=False, separators=(',', ':')))


if __name__ == '__main__':
    main()
