"""Prepare R4.4A1 errata/evidence/freeze candidate without candidate execution.

Only original frozen JSON and pre-run specification/source text are used to
adjudicate expectations. The interrupted execution is hashed, never used as an
expectation oracle. Generated artifacts are separate from all frozen originals.
"""

from __future__ import annotations

import hashlib
import importlib.abc
import io
import json
import platform
import sys
import unittest
from pathlib import Path

from .itq_execution_spec_v101 import SEVERITY_ORDER, TRACKING_CONTRIBUTION, VERSION, validate_expectation
from .verify_itq_preregistration import ROOT, canonical, sha, verify

ORIGINAL_AGGREGATE="1aa88da29b09cfd18ea16b80fbe0c8ef886391f4246457f96782f198f18ef560"
ORIGINAL_FREEZE_HASH="9d000e38339c00ae158a97d850ab07a4a8b12df9640e845c25657b7eecc7e17d"
PREREG=ROOT/"phase5_r5_2_1r4_4_itq_preregistration.json"
FREEZE=ROOT/"phase5_r5_2_1r4_4a_itq_freeze_manifest.json"
ERRATA=ROOT/"phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json"
EVIDENCE=ROOT/"phase5_r5_2_1r4_4a1_itq_harness_repair_evidence.json"
NEW_MANIFEST=ROOT/"phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json"
REPORT=ROOT/"PHASE5_R5_2_1R4_4A1_ITQ_HARNESS_AND_EXPECTATION_ADJUDICATION_REPORT.md"
HARNESS=Path(__file__).with_name("itq_execution_spec_v101.py")
OLD_HARNESS=Path(__file__).with_name("run_itq_blind.py")
TESTS=Path(__file__).with_name("test_execution_spec_v101.py")


class DenyCandidateImports(importlib.abc.MetaPathFinder):
    def __init__(self):
        self.attempts=[]

    def find_spec(self, fullname, path=None, target=None):
        if fullname.startswith("v0_2.examples.phase5_r5_2_1"):
            self.attempts.append(fullname)
            raise RuntimeError(f"R4.4A1 prohibits candidate import/execution: {fullname}")
        return None


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path,value):
    path.write_bytes(canonical(value)+b"\n")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def main():
    guard=DenyCandidateImports()
    sys.meta_path.insert(0,guard)
    original_check=verify()
    assert original_check["aggregate_sha256"]==ORIGINAL_AGGREGATE
    assert sha(FREEZE)==ORIGINAL_FREEZE_HASH
    prereg=load(PREREG); frozen=load(FREEZE)
    assert sha(OLD_HARNESS)==frozen["runner_sha256"]
    assert [c["case_id"] for c in prereg["cases"]]==[f"ITQ-{i:03d}" for i in range(1,24)]
    assert sum(len(c["fixture_variants"]) for c in prereg["cases"])==51
    watched=dict(frozen["protected_source_sha256"])
    for directory in ("control","plant","measurement","actuators","thermal","hydraulics","coolant","cdu"):
        for path in (ROOT/"v0_2"/directory).glob("*.py"):
            watched.setdefault(path.relative_to(ROOT).as_posix(),sha(path))
    before={p:sha(ROOT/p) for p in watched}
    assert before==watched
    prior_evidence_path=ROOT/"phase5_r5_2_1r4_4a_itq_blind_execution_evidence.json"
    prior_hash=sha(prior_evidence_path)
    expected_prior_hash="7e7298c905286456742924baab3b558e462f661601d9c4c82a4c915914bb04b4"
    assert prior_hash==expected_prior_hash
    refs={
        "preregistration":{"path":PREREG.relative_to(ROOT).as_posix(),"sha256":sha(PREREG)},
        "original_freeze":{"path":FREEZE.relative_to(ROOT).as_posix(),"sha256":sha(FREEZE)},
        "Contract15A":{"path":"contracts/15A_tracking_safety_policy_amendment.md","sha256":sha(ROOT/"contracts/15A_tracking_safety_policy_amendment.md")},
        "pre_run_report":{"path":"PHASE5_R5_2_1R4_4_INDEPENDENT_TRACKING_QUALIFICATION_PREREGISTRATION.md","sha256":sha(ROOT/"PHASE5_R5_2_1R4_4_INDEPENDENT_TRACKING_QUALIFICATION_PREREGISTRATION.md"),"authority":"supporting pre-run text; hashed expected JSON/Contract15A are decisive"},
        "pre_run_builder":{"path":"v0_2/tests/data/tracking_qualification/build_itq_preregistration.py","sha256":sha(Path(__file__).with_name("build_itq_preregistration.py")),"pointer":"spec cases, make_expected: safety.highest sourced from normal/fault case.safety; intermediate DEGRADED explicitly allowed"},
        "direction_record_definition":{"path":"v0_2/examples/phase5_r5_2_1r4_2_directional_engine.py","sha256":sha(ROOT/"v0_2/examples/phase5_r5_2_1r4_2_directional_engine.py"),"pointer":"DirectionalObligationTrackingQualifier.update: epoch_expected_direction = self.epoch.expected_direction if epoch exists else None"},
        "legacy_epoch_record_definition":{"path":"v0_2/examples/phase5_r5_2_1r_semantic_engine.py","sha256":sha(ROOT/"v0_2/examples/phase5_r5_2_1r_semantic_engine.py"),"pointer":"OfflineTrackingQualifier.update: expected_direction = self.epoch.expected_direction if epoch exists else None; identical variable/projection, not obligation-lifecycle equivalence"},
        "startup_outage_definition":{"path":"v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py","sha256":sha(ROOT/"v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py"),"pointer":"_process_invalid and update publish startup_outage_direction / recover a new epoch"}}
    mapping={"verdict":"FIELD_MAPPING_REQUIRES_EXPLICIT_ADAPTER",
             "legacy_comparison_concept":"expected_direction at valid recovery = retained epoch expected motion direction; an epoch may already be completed",
             "explicit_epoch_adapter":{"source_field":"epoch_expected_direction","scope":"valid post-recovery epoch comparison only; does not itself prove active lifecycle","type":"exact int -1/+1 or null; bool/float/string rejected","missing_or_wrong_type":"INVALID_EXECUTION","fallback":"NONE"},
             "outage_obligation_adapter":{"source_fields":["startup_outage_direction.direction","directional_obligation.direction"],"scope":"current direction during invalidity; typed explicit lifecycle carriers","closed_epoch_fallback":"FORBIDDEN","conflicting_carriers":"INVALID_EXECUTION"},
             "semantic_boundary":"Epoch direction can be stale while an epoch is closed during outage. It is not globally equivalent to current directional obligation. The old failed access occurred in the valid-after-recovery epoch comparison, where explicit mapping is equivalent.",
             "original_intent_reference":"ITQ-012 expected_direction_behavior=SUPERSEDE_TO_CURRENT_NEGATIVE_NET_DEMAND; outage direction and recovery epoch are evaluated separately.",
             "candidate_output_renamed":False}
    interpretations={}; inventory=[]
    preserved_fields=("fault_expected","expected_public_state_milestones","expected_terminal_state","expected_evidence_behavior",
                      "expected_direction_behavior","expected_watch_behavior","terminal_timing_normativity","timing_rules",
                      "forbidden_outcomes","same_sample_reissue_guard","acceptance")
    timing_hashes={}
    for case in prereg["cases"]:
        expected=load(ROOT/case["expected_path"])
        assert sha(ROOT/case["expected_path"])==case["expectation_sha256"]==frozen["expectations"][case["case_id"]]["sha256"]
        safety=expected["safety"]
        terminal=TRACKING_CONTRIBUTION[expected["expected_terminal_state"]]
        assert safety["highest"]==terminal
        contradiction=any(SEVERITY_ORDER[s]>SEVERITY_ORDER[safety["highest"]] for s in safety["allowed_intermediate"])
        if contradiction:
            assert safety["highest"]=="NORMAL" and safety["allowed_intermediate"]==["NORMAL","DEGRADED"] and safety["forbidden"]==["FAULT"]
        maximum=max([terminal,*safety["allowed_intermediate"]],key=SEVERITY_ORDER.get)
        unchanged={key:expected[key] for key in preserved_fields}
        timing_hashes[case["case_id"]]=digest({k:expected[k] for k in ("expected_public_state_milestones","terminal_timing_normativity","timing_rules","same_sample_reissue_guard","acceptance")})
        interpretations[case["case_id"]]={"case_id":case["case_id"],"original_expected_path":case["expected_path"],
             "original_expected_sha256":case["expectation_sha256"],"original_highest_value":safety["highest"],
             "original_allowed_intermediate":safety["allowed_intermediate"],"original_forbidden":safety["forbidden"],
             "terminal_safety_state":terminal,"max_allowed_safety_severity":maximum,
             "allowed_intermediate_safety_states":safety["allowed_intermediate"],"forbidden_safety_states":safety["forbidden"],
             "scope":"tracking severity contribution only; independent sensor/multi-channel final Safety outside ITQ mapping",
             "verdict":"CONSISTENT_AFTER_SCHEMA_CLARIFICATION" if contradiction else "ORIGINAL_SAFETY_EXPECTATION_CONSISTENT",
             "contradiction":"literal highest NORMAL incompatible with explicitly allowed DEGRADED" if contradiction else None,
             "resolving_pre_run_evidence":{"terminal_pointer":"expected_terminal_state + Contract15A tracking contribution table",
                                          "allowed_pointer":"safety.allowed_intermediate explicitly permits DEGRADED, not requires it",
                                          "prohibition_pointer":"safety.forbidden prohibits FAULT; no pre-run prohibition on temporary DEGRADED",
                                          "classification_pointer":"fault_expected and pre-run case intent unchanged"},
             "unchanged_behavioral_intent_sha256":digest(unchanged),"unchanged_timing_sha256":timing_hashes[case["case_id"]]}
        inventory.append({"case_id":case["case_id"],"contradiction_found":contradiction,
                          "resolution":interpretations[case["case_id"]]["verdict"],"unresolved":False})
    assert sum(row["contradiction_found"] for row in inventory)==14
    errata={"schema":"itq-execution-spec-errata-v1","classification":"EXECUTION_SPEC_ERRATA",
            "ITQ_BEHAVIORAL_FIXTURE_VERSION":"1.0","original_suite_version":prereg["ITQ_SUITE_VERSION"],
            "ITQ_EXECUTION_SPEC_VERSION":VERSION,"ORIGINAL_ITQ_PREREGISTRATION_HASH":ORIGINAL_AGGREGATE,
            "original_freeze_sha256":ORIGINAL_FREEZE_HASH,"statements":[
                "THIS DOES NOT MODIFY ORIGINAL PREREGISTERED FIXTURES.","THIS DOES NOT MODIFY R4.3B.",
                "THIS RESOLVES EXECUTION-SPEC / MACHINE-REPRESENTATION DEFECTS ONLY."],
            "pre_run_sources":refs,"field_mapping":mapping,
            "safety_dimension_definitions":{
                "terminal_safety_state":"Expected tracking Safety contribution at the registered terminal/evaluation condition, derived from unchanged terminal public state and Contract15A.",
                "max_allowed_safety_severity":"Upper bound on severity anywhere in trace, not a severity that must occur; derived only from original allowed intermediates and terminal contribution.",
                "allowed_intermediate_safety_states":"Permitted nonterminal contributions; optional unless another frozen milestone requires them. Repeated terminal contribution after terminal is reached is allowed by the terminal/latch policy.",
                "forbidden_safety_states":"Original explicit prohibition retained verbatim.",
                "hierarchy":["FAULT","PROTECTED","DERATE_REQUESTED","DEGRADED","FF_DISABLED","NORMAL"]},
            "all_case_interpretations":interpretations,"inconsistency_inventory":inventory,
            "timing_original_hashes":timing_hashes,"candidate_output_used_to_choose_interpretation":False,
            "fixture_changes":False,"expectation_file_changes":False,"behavioral_intent_changes":False,
            "timing_changes":False,"approval_status":"CANDIDATE_FOR_USER_REVIEW"}
    save(ERRATA,errata)
    from . import test_execution_spec_v101 as test_module
    suite=unittest.defaultTestLoader.loadTestsFromModule(test_module)
    out=io.StringIO(); tests=unittest.TextTestRunner(stream=out,verbosity=2).run(suite)
    assert tests.wasSuccessful(),out.getvalue()
    static_results=[]; ordered=[]
    for case in prereg["cases"]:
        expected=load(ROOT/case["expected_path"])
        for variant in case["fixture_variants"]:
            path=ROOT/variant["input_path"]
            assert sha(path)==variant["input_sha256"]
            frozen_variant=next(v for v in frozen["fixtures"][case["case_id"]] if v["path"]==variant["input_path"])
            assert sha(path)==frozen_variant["sha256"]
            static=validate_expectation(expected,interpretations[case["case_id"]],load(path))
            assert static["status"]=="CONSISTENT",static
            static_results.append({"case_id":case["case_id"],"variant_path":variant["input_path"],
                                   "physics_dt_ns":variant["physics_dt_ns"],"expectation_sha256":case["expectation_sha256"],**static})
            ordered.append({"case_id":case["case_id"],"input_path":variant["input_path"],"input_sha256":variant["input_sha256"],
                            "expectation_path":case["expected_path"],"expectation_sha256":case["expectation_sha256"],"physics_dt_ns":variant["physics_dt_ns"]})
    after={p:sha(ROOT/p) for p in watched}
    assert before==after and sha(OLD_HARNESS)==frozen["runner_sha256"] and sha(prior_evidence_path)==prior_hash
    verify()
    assert not guard.attempts and not any(n.startswith("v0_2.examples.phase5_r5_2_1") for n in sys.modules)
    comparison_semantics={"field_mapping":mapping,"Safety_dimensions":errata["safety_dimension_definitions"],
        "timing":"EXACT exact registered timestamp; ORDER required order only; WINDOW only explicit frozen bounds; NON_NORMATIVE timing ignored while required state milestone retained",
        "schema_failure":"INVALID_EXECUTION; no guessed alias or generic tolerance",
        "other_checks":"Preserve original terminal/fault/public-state/invalidity/reissue/latch/watch checks via compare_snapshot",
        "prefix_and_repeat_plan":prereg["planned_execution_matrix"],"no_result_carry_forward":True}
    components={"original_suite_aggregate":ORIGINAL_AGGREGATE,"original_freeze_sha256":ORIGINAL_FREEZE_HASH,
                "original_preregistration_file_sha256":sha(PREREG),"original_fixtures_and_expectations":ordered,
                "execution_spec_version":VERSION,"errata_sha256":sha(ERRATA),
                "harness_source_sha256":sha(HARNESS),"harness_tests_sha256":sha(TESTS),
                "baseline_validator_sha256":sha(Path(__file__).with_name("verify_execution_baseline_v101.py")),
                "comparison_semantics":comparison_semantics,"candidate_R4_3B_engine_sha256":frozen["candidate_R4_3B_engine_sha256"],
                "profile_sha256":frozen["tracking_profile_sha256"],"Contract15A_sha256":frozen["Contract15A_sha256"]}
    baseline=digest(components)
    new_manifest={"schema":"itq-rerun-freeze-candidate-v1","status":"CANDIDATE_FOR_USER_APPROVED_RERUN_FREEZE",
                  "ITQ_EXECUTION_SPEC_VERSION":VERSION,"suite_fixture_version":"1.0", "execution_baseline_components":components,
                  "EXECUTION_BASELINE_HASH":baseline,"hash_method":"SHA256 UTF-8 canonical JSON(sort_keys=true,separators=(',',':'),ensure_ascii=false,allow_nan=false) of execution_baseline_components",
                  "original_fixture_hashes":frozen["fixtures"],"original_expectation_hashes":frozen["expectations"],
                  "protected_source_sha256":before,"planned_execution_matrix":ordered,
                  "planned_prefix_checks":prereg["planned_execution_matrix"]["prefixes"],
                  "planned_repeatability_checks":prereg["planned_execution_matrix"]["repeats"],
                  "future_phase":"5R5.2.1R4.4A2","restart_from":"ITQ-001","variant_count":51,"case_count":23,
                  "requires_user_approved_rerun_freeze":True,"candidate_executed_in_A1":False,
                  "previous_results":"NON_QUALIFYING_PRELIMINARY_EXECUTION_EVIDENCE; never carry forward",
                  "ITQ_SUITE_RESULT":"NOT_REEXECUTED_YET","R4_3B_CANDIDATE_QUALIFICATION_STATUS":"NOT_QUALIFIED_YET",
                  "FULL_P_HISTORY_VALIDATION_AVAILABLE":"NO","CAN_PRODUCTION_PORT_START":"NO"}
    save(NEW_MANIFEST,new_manifest)
    gate="ITQ_EXECUTION_HARNESS_AND_EXPECTATION_SPEC_REPAIRED"
    evidence={"schema":"phase5-r5-2-1r4-4a1-harness-repair-evidence-v1","original_preregistration_hash":ORIGINAL_AGGREGATE,
              "original_R4_4A_freeze_hash":ORIGINAL_FREEZE_HASH,"original_fixture_hashes":frozen["fixtures"],
              "original_expectation_hashes":frozen["expectations"],"field_mapping_verdict":mapping,
              "expectation_inconsistency_inventory":inventory,"ITQ_004_EXPECTATION_VERDICT":interpretations["ITQ-004"]["verdict"],
              "ITQ_010_EXPECTATION_VERDICT":interpretations["ITQ-010"]["verdict"],
              "errata_path":ERRATA.relative_to(ROOT).as_posix(),"errata_sha256":sha(ERRATA),
              "original_harness_sha256_before":frozen["runner_sha256"],"original_harness_sha256_after":sha(OLD_HARNESS),
              "repaired_versioned_harness_path":HARNESS.relative_to(ROOT).as_posix(),"repaired_harness_sha256":sha(HARNESS),
              "harness_only_test_results":{"tests_run":tests.testsRun,"failures":len(tests.failures),"errors":len(tests.errors),
                                          "status":"PASS","test_file_sha256":sha(TESTS),"log":out.getvalue()},
              "static_expected_variant_validation":static_results,"static_consistent_count":len(static_results),
              "original_fixture_hashes_unchanged":True,"original_expectation_hashes_unchanged":True,"timing_expectations_unchanged":True,
              "new_execution_baseline_hash":baseline,"new_manifest_sha256":sha(NEW_MANIFEST),
              "R4_3B_before_sha256":before["v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py"],
              "R4_3B_after_sha256":after["v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py"],
              "Production_Safety_before_sha256":before["v0_2/safety/supervisor.py"],"Production_Safety_after_sha256":after["v0_2/safety/supervisor.py"],
              "Contract15A_sha256":frozen["Contract15A_sha256"],"profile_sha256":frozen["tracking_profile_sha256"],
              "source_hashes_before":before,"source_hashes_after":after,
              "anti_bias":{"candidate_import_attempts":guard.attempts,"candidate_modules_imported":[],"candidate_executed":False,
                           "candidate_output_used_for_interpretation":False,"interrupted_evidence_sha256_preserved":prior_hash},
              "ITQ_SUITE_RESULT":"NOT_REEXECUTED_YET","R4_3B_CANDIDATE_QUALIFICATION_STATUS":"NOT_QUALIFIED_YET",
              "FULL_P_HISTORY_VALIDATION_AVAILABLE":"NO","CAN_PRODUCTION_PORT_START":"NO", "git_commit_push":False,
              "environment":{"python":sys.version,"platform":platform.platform()},"R4_4A1_GATE":gate}
    save(EVIDENCE,evidence)
    text=["# Phase 5R5.2.1R4.4A1 — ITQ 执行器修复与冻结预期一致性裁定","",
          "## 1. 目的与结论","",f"`R4_4A1_GATE = {gate}`。本阶段完成执行器修复、独立预期裁定和静态自测，候选尚未重跑。执行规范版本为 `{VERSION}`，行为夹具版本仍为 1.0。","",
          "## 2–3. 中断盲跑与非资格证据","","R4.4A 的 23 个初步 PASS、6 个初步 FAIL、1 个 INVALID_EXECUTION、21 个未运行均保留为 NON_QUALIFYING_PRELIMINARY_EXECUTION_EVIDENCE；执行器字段错误使完整盲测不可判定，结果不携带至下一轮。本阶段没有读取这些输出决定预期，只验证原证据文件 SHA-256。","",
          "## 4. 原冻结套件完整性","",f"原聚合哈希 `{ORIGINAL_AGGREGATE}`；原最终冻结清单哈希 `{ORIGINAL_FREEZE_HASH}`。51 个输入、23 个预期、原清单和原执行器均保持原字节与 SHA-256。原 R4.4 报告中 engine reference 指向较早 semantic dependency；本阶段显式使用最终冻结清单确定的 startup R4.3B 主引擎，没有改写原记录。","",
          "## 5–6. ITQ-012 字段缺陷与语义裁定","","旧比较器在有效测量恢复后读取 expected_direction。候选代码明确发布 epoch_expected_direction = epoch.expected_direction，表示当前 epoch 期待的物理运动方向。这个恢复阶段的比较可通过显式适配修复，裁定 FIELD_MAPPING_REQUIRES_EXPLICIT_ADAPTER。它不能在所有时刻替代 current directional obligation：失效期间旧 epoch 可能已经关闭，新方向分别保存在 startup_outage_direction 或 directional_obligation。因此修复后分开核对失效期间义务和恢复后的 epoch，均来自原 ITQ-012 的 SUPERSEDE_TO_CURRENT_NEGATIVE_NET_DEMAND 意图。缺字段、类型错误或两种载体冲突判 INVALID_EXECUTION；不猜字段、不退回旧 epoch。","",
          "## 7. ITQ-004 独立预期裁定","","原意图是 SLOW_RAMP_0_1 夹具合法慢响应、最终 STEADY_TRACKING、禁止确认跟踪故障；原 JSON 明确允许 intermediate DEGRADED。依据 terminal state 与 Contract15A，终态跟踪贡献应为 NORMAL，允许的全程上限为 DEGRADED（可以不出现）。裁定 CONSISTENT_AFTER_SCHEMA_CLARIFICATION。这个结论由冻结预期/分类/规则直接推导，未使用实际候选输出。","",
          "## 8. ITQ-010 独立预期裁定","","原意图是有效测量下正常反向、已登记 progress 顺序与最终 STEADY_TRACKING、禁止误确认 FAULT。与 ITQ-004 一样，明确允许 intermediate DEGRADED；因此终态 NORMAL、全程允许上限 DEGRADED。裁定 CONSISTENT_AFTER_SCHEMA_CLARIFICATION，反向、证据、方向、进展和时间要求均不变。","",
          "## 9. 全 23 案例一致性清单","","共 14 个正常案例存在 highest=NORMAL 与允许 DEGRADED 的矛盾；9 个故障案例原 Safety 维度一致。全部 14 个矛盾按相同冻结规则解析，未解决项 0。","",
          "| 案例 | 原 Safety 表示 | 终态贡献 | 全程允许上限 | 裁定 |","|---|---|---|---|---|"]
    for cid,entry in interpretations.items():
        text.append(f"| {cid} | {entry['original_highest_value']} + 允许 NORMAL/DEGRADED | {entry['terminal_safety_state']} | {entry['max_allowed_safety_severity']} | {'澄清表示矛盾' if entry['contradiction'] else '原预期一致'} |")
    text += ["","## 10. 执行规范勘误","","独立 errata 引用每个原 expected 文件路径与哈希。它将误名 highest 按 terminal state + Contract15A 解释为 terminal_safety_state，并显式列出 max_allowed_safety_severity、allowed_intermediate_safety_states、forbidden_safety_states。上限是任何采样都不能超过的严重度，不强制出现该状态；允许中间态也不强制发生。比较仅针对跟踪贡献，传感器通道及最终多通道 Safety 不在此资格范围。FAULT > PROTECTED > DERATE_REQUESTED > DEGRADED > FF_DISABLED > NORMAL。允许的状态集合由原 JSON 明示；原 FAULT 禁止项保持。没有改变故障分类、输入、阈值、计时器、精确时间、窗口、证据/方向义务或进展要求。","",
             "## 11. 执行器修复","","新增版本化模块 itq_execution_spec_v101.py，原 run_itq_blind.py 保留。恢复 epoch 方向与失效期间方向载体采用明确类型适配；终态、全程上限、中间态和禁止态分开比较。compare_snapshot 保留原末态、误报/漏报、失效测量、重发同样本保护、确认 latch 与 watch 年龄检查。字段错误归为 INVALID_EXECUTION，合法行为差异归为 FAIL。","",
             "## 12. 仅执行器自测","",f"{tests.testsRun}/{tests.testsRun} 项测试通过；全部使用人工静态记录，覆盖字段映射、缺字段、类型错误、禁止回退、键顺序、完整严重度序、终态/中间态、上限/禁止态、状态顺序及 EXACT/ORDER/WINDOW/NON_NORMATIVE。单元测试中的窗口仅是解析器输入，不进入 ITQ，也不成为新校准参数。进程安装拒绝候选模块导入的守卫，导入尝试为 0。","",
             "## 13. 51 变体静态预期校验","","51/51 个变体引用的原 expected + errata 均解析为 CONSISTENT。校验只检查 ID、原字段绑定、终态映射、严重度维度、时间格式、终止时长以及固定恢复 release；没有运行候选或为任何 ITQ 案例生成 PASS/FAIL。","",
             "## 14–15. 原件哈希与防偏置证据","","原清单、51 输入、23 预期、原执行器、原中断证据和受保护源码哈希均复核未变。勘误依据是已冻结 JSON 的 terminal/fault/allowed/forbidden 字段、Contract15A 与冻结前生成规则，所有引用和指纹保存在 errata。原 timing 字段（包括 exact 时间、guard、normativity 和观察终止时长）的指纹逐案记录，未加容差。","",
             "## 16. 新执行基线","",f"`EXECUTION_BASELINE_HASH = {baseline}`。它是新 execution_baseline_components 的 canonical JSON SHA-256，涵盖原 suite 引用、全部输入/预期哈希、errata、版本化 harness/test 哈希、字段适配、比较语义、候选/profile/Contract15A。原聚合哈希继续独立保留，没有冒称修正后仍是旧执行基线。","",
             "## 17. 后续重跑计划","","候选清单状态 CANDIDATE_FOR_USER_APPROVED_RERUN_FREEZE。用户另行批准冻结后，A2 核对原 suite、errata、执行基线及候选 hash，从 ITQ-001 重新运行全部 51 变体，使用原前缀/两次重复/网格计划，复跑独立历史基线，并不得沿用旧初步标签。A1 没有启动 A2。","",
             "## 18. 状态与门禁","",f"R4_4A1_GATE = {gate}；ITQ_SUITE_RESULT = NOT_REEXECUTED_YET；R4_3B_CANDIDATE_QUALIFICATION_STATUS = NOT_QUALIFIED_YET。CAN_PRODUCTION_PORT_START = NO，FULL_P_HISTORY_VALIDATION_AVAILABLE = NO。P15 保留独立的冻结重建历史 PASS。真实硬件 CALIBRATION_REQUIRED。Production Safety、R4.3B、controller、plant、measurement、actuator、tracking profile 与 Contract15A 未改。Phase 6 未开始；Git commit/push 未执行。等待用户审阅执行规范与重跑候选清单。"]
    REPORT.write_text("\n".join(text)+"\n",encoding="utf-8")
    print(json.dumps({"gate":gate,"harness_only_tests":tests.testsRun,"static_consistent":len(static_results),
                      "contradictions_resolved":14,"candidate_executed":False,"execution_baseline_hash":baseline,
                      "errata_sha256":sha(ERRATA),"manifest_sha256":sha(NEW_MANIFEST)},ensure_ascii=False))


if __name__=="__main__":
    main()
