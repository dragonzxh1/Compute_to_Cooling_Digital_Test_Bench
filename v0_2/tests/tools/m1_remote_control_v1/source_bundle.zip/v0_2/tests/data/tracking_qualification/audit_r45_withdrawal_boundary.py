"""Read saved evidence and algebra only. Never import or execute a candidate."""
import json
import math
from pathlib import Path
from .verify_itq_preregistration import ROOT, canonical, sha
from .run_r44a2_r2 import immutable


def main():
    output = ROOT / 'phase5_r5_2_1r4_5a_withdrawal_boundary_audit.json'
    if output.exists():
        raise RuntimeError('AUDIT_EXISTS_DO_NOT_OVERWRITE')
    read = lambda p: json.loads((ROOT / p).read_text(encoding='utf-8'))
    r4path = 'phase5_r5_2_1r4_4a2_r4_full_blind_qualification_evidence.json'
    r45path = 'phase5_r5_2_1r4_5_withdrawal_cancellation_evidence.json'
    r4, r45 = read(r4path), read(r45path)
    protected = dict(r45['protected_hashes_before'])
    for p in [r4path, r45path, 'PHASE5_R5_2_1R4_5_WITHDRAWAL_CANCELLATION_CORRECTION_REPORT.md',
        'phase5_r5_2_1r4_5_blocker_adjudication.json']:
        protected[p] = sha(ROOT / p)
    immutable(protected)
    profile = read('phase5_r5_2_2_fixture_tracking_profile.json')
    a, s, q = (profile[k] for k in ['ActuatorTrackingProfile', 'SensorObservationProfile', 'TrackingQualificationProfile'])
    delay = round(a['command_delay_s']['value'] * 1e9)
    cadence = round(s['measurement_period_s']['value'] * 1e9)
    release_delay = round(s['measurement_release_delay_s']['value'] * 1e9)
    tau, ramp = a['lag_time_constant_s']['value'], a['speed_rate_limit_per_s']['value']
    minimum = q['minimum_observable_speed_change']['value']
    suspect = q['suspected_rule_parameters']['value']['expected_min']
    confirm = q['confirmed_rule_parameters']['value']['expected_min']
    cases = {}
    for name in ['ITQ-013', 'ITQ-014']:
        before = next(v for v in r4['variants'] if v['case_id'] == name)
        after = next(v for v in r45['targeted_ITQ_results'] if v['case_id'] == name)
        fixture = read(before['variant_path'])
        expected_path = 'v0_2/tests/data/tracking_qualification/' + name + '_expected.json'
        expected = read(expected_path)
        timeline = fixture['command_timeline']
        start, withdrawal = timeline[1]['time_ns'], timeline[2]['time_ns']
        magnitude = abs(timeline[1]['speed_fraction'] - timeline[0]['speed_fraction'])
        expected_old = lambda tick: min(ramp * max(0, (tick-start-delay)/1e9),
            magnitude * (1 - math.exp(-max(0, (tick-start-delay)/1e9) / tau)))
        opening = ((start + delay + cadence - 1) // cadence) * cadence
        while expected_old(opening) < minimum:
            opening += cadence
        opening += release_delay
        trace = []
        for old, new, row in zip(before['snapshot']['records'], after['snapshot']['records'], fixture['observations']):
            projected = expected_old(row['time_ns'])
            trace.append({'released_input': row, 'R4_actual': old, 'R45_actual': new,
                'analytical_old_command_held_expected_motion': projected,
                'analytical_old_command_held_suspect_expected_open': projected >= suspect,
                'analytical_old_command_held_confirm_expected_open': projected >= confirm,
                'analytical_note': 'Conditional old-demand model only, not actual earned evidence, not a candidate replay, not a new acceptance oracle'})
        cases[name] = {'input_path': before['variant_path'], 'input_sha256': sha(ROOT / before['variant_path']),
            'expectation_path': expected_path, 'expectation_sha256': sha(ROOT / expected_path), 'expectation': expected,
            'command_start_ns': start, 'withdrawal_ns': withdrawal, 'frozen_model_old_response_open_ns': opening,
            'withdrawal_vs_opening': 'BEFORE' if withdrawal < opening else 'SAME_SAMPLE' if withdrawal == opening else 'AFTER',
            'old_command_held_expected_motion_at_withdrawal': expected_old(withdrawal),
            'R4_comparator_result': before['status'], 'R45_development_comparator_result': after['status'],
            'R45_comparator_errors': after['errors'], 'R4_watch_events': before['snapshot']['watch_events'],
            'R45_watch_events': after['snapshot']['watch_events'], 'tick_comparison': trace}
    immutable(protected)
    result = {'schema': 'r45a-read-only-withdrawal-boundary-audit-v1',
        'candidate_execution_count': 0, 'pytest_execution_count': 0,
        'analysis_method': 'Saved authoritative R4/R45 traces plus algebra from frozen profile; no replay or modification',
        'cases': cases, 'source_profile_values': {'delay_ns': delay, 'cadence_ns': cadence, 'minimum_motion': minimum,
            'suspect_expected_min': suspect, 'confirm_expected_min': confirm, 'ramp_per_s': ramp, 'tau_s': tau},
        'findings': {
            'same_sample_boundary': 'ITQ013 withdrawal precedes old response opening; ITQ014 withdrawal equals first old response opening. Candidate applies current released command before response evaluation.',
            'evidence_count_vs_suspicion': 'carried_suspicion_evidence increments only at the confirmation expected threshold with deficient ratio; zero count alone does not imply no suspected evidence. No pre-withdrawal suspicion actually exists in these two saved traces.',
            'expectation_precondition': 'ITQ014 rationale presumes suspicion evidence at withdrawal tick, but no prior/current earned suspicion is recorded when current command is evaluated first.',
            'comparator_scope': 'PRESERVE_OLDEST_UNRESOLVED checks multiple watch STARTs, independent of actual evidence precondition. It does not require suspicion to precede withdrawal. ITQ013 CANCELLED is not explicitly compared to a CANCEL event in compare_snapshot.',
            'causal_policy_gap': 'Accepted evidence-retention rule and same-sample old-obligation evaluation order need review. Frozen constants do not by themselves authorize retaining an opportunity ledger or earning evidence from withdrawn demand.',
            'not_proven': 'No conclusion that flow/DP, thresholds, plant, or production Safety is defective; no claim old-command counterfactual is observed evidence'},
        'recommended_next_action': 'Separate user-reviewed timing/causal semantics specification for withdrawal at first response opportunity; preserve all existing frozen outputs and expectations. Do not implement or begin R4.6 now.',
        'R4_original_result_reclassified': False, 'R45_failure_reclassified': False,
        'protected_hashes_before': protected, 'protected_hashes_after': {p: sha(ROOT / p) for p in protected},
        'runtime_or_frozen_file_changes': False, 'git_commit_push': False,
        'CAN_PRODUCTION_PORT_START': 'NO', 'FULL_P_HISTORY_VALIDATION_AVAILABLE': 'NO',
        'status': 'WITHDRAWAL_SAME_SAMPLE_ORDERING_REQUIRES_USER_REVIEW'}
    output.write_bytes(canonical(result) + b'\n')
    print(json.dumps({'status': result['status'], 'cases': {k: {p:v[p] for p in ['withdrawal_ns',
        'frozen_model_old_response_open_ns', 'withdrawal_vs_opening', 'old_command_held_expected_motion_at_withdrawal']} for k,v in cases.items()},
        'protected_files_unchanged': len(protected), 'candidate_execution_count': 0}))


if __name__ == '__main__':
    main()
