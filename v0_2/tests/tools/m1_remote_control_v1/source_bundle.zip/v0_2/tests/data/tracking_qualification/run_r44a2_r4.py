"""R4 evidence-only orchestration; immutable approved comparison/replay functions.

No candidate output defines an expectation. This runner is frozen before replay.
"""
import copy
import importlib.metadata as metadata
import json
import os
import platform
import re
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path
from . import run_r44a2_r2 as helpers
from .verify_itq_preregistration import ROOT, sha
from .run_itq_blind import run_candidate, prefixes
from .itq_execution_spec_v101 import compare_snapshot, TRACKING_CONTRIBUTION

STEM = 'phase5_r5_2_1r4_4a2_r4_full_blind_qualification'
EVIDENCE = ROOT / (STEM + '_evidence.json')
MANIFEST = ROOT / (STEM + '_run_manifest.json')
REPORT = ROOT / 'PHASE5_R5_2_1R4_4A2_R4_FULL_BLIND_QUALIFICATION_REPORT.md'
ENV_MANIFEST = 'phase5_r5_2_1r4_4a2_r3_qualification_environment_manifest.json'
ENV_HASH = 'ce0a18d7f83abe17d0be543d66ce1e1927ebc1b668faf7815f34e34b03b1a32a'
load, digest, save, now = helpers.load, helpers.digest, helpers.save, helpers.now


def environment():
    registered = load(ENV_MANIFEST)
    identity = copy.deepcopy(registered['environment_identity'])
    base = Path(sys.base_prefix) / 'python.exe'
    identity['python'] = dict(implementation=platform.python_implementation(),
        version=sys.version, executable=sys.executable, base_executable=str(base),
        base_executable_sha256=sha(base), prefix=sys.prefix,
        architecture=platform.machine(), platform=platform.platform())
    distributions = list(metadata.distributions())
    identity['packages'] = {d.metadata['Name']: d.version for d in distributions}
    identity['package_manager']['version'] = metadata.version('pip')
    identity['installed_distribution_record_sha256'] = {
        d.metadata['Name']: sha(Path(d._path) / 'RECORD') for d in distributions}
    install = load('phase5_r5_2_1r4_4a2_r3_dependency_install_report.json')
    wheels = [{'name': d['metadata']['name'], 'version': d['metadata']['version'],
               'sha256': d['download_info']['archive_info']['hashes']['sha256']}
              for d in install['install']]
    identity['installed_wheel_archives'] = wheels
    identity['dependency_source_sha256'] = {
        p: sha(ROOT / p) for p in identity['dependency_source_sha256']}
    identity['venv_config_sha256'] = sha(Path(sys.prefix) / 'pyvenv.cfg')
    identity['relevant_environment_variables'] = {
        k: os.environ.get(k) for k in identity['relevant_environment_variables']}
    identity['working_directory'] = Path.cwd().as_posix()
    actual = digest(identity)
    if actual != ENV_HASH or actual != registered['QUALIFICATION_ENVIRONMENT_HASH']:
        raise RuntimeError('R4_4A2_R4_ENVIRONMENT_INTEGRITY_FAILURE:' + actual)
    return {'hash': actual, 'identity': identity, 'status': 'PASS'}


def protect(m):
    # Include all prior evidence; exclude only newly generated R4 outputs.
    paths = set(helpers.hashes(m))
    paths.difference_update({EVIDENCE.name, MANIFEST.name, REPORT.name})
    paths.update({
        'phase5_r5_2_1r4_4a2_r2_itq_blind_qualification_evidence.json',
        'phase5_r5_2_1r4_4a2_r2_itq_blind_qualification_run_manifest.json',
        'PHASE5_R5_2_1R4_4A2_R2_ITQ_FULL_BLIND_QUALIFICATION_REPORT.md'})
    return {p: sha(ROOT / p) for p in sorted(paths)}


def guard(frozen):
    helpers.immutable(frozen)
    environment()


def historical(profile, classifier, frozen):
    """Same historical acceptance functions and frozen P15 requirements, fresh data.

    Execute Startup, C, S, P15 in that order; keep full historical traces even
    on failure, rather than retaining only hashes. No historical main writes.
    """
    result = {'executed_after_ITQ': True, 'execution_order': ['Startup', 'C', 'S', 'P15']}
    guard(frozen)
    tests = subprocess.run([sys.executable, '-m', 'pytest', '-q',
        'v0_2/tests/control/test_phase5_r5_2_1r4_3_startup.py'],
        cwd=ROOT, text=True, capture_output=True)
    count = lambda label: sum(int(x) for x in re.findall(r'(\d+) ' + label + r'\b', tests.stdout))
    passed, failed, errors = count('passed'), count('failed'), count('errors?')
    # Root addopts=-q plus explicit -q may suppress the PASS summary.
    if passed == 0 and failed == 0 and tests.returncode == 0:
        passed = sum(len(line.split()[0]) for line in tests.stdout.splitlines()
            if line.split() and set(line.split()[0]) == {'.'})
    if tests.returncode not in (0, 1) or errors or passed + failed != 50:
        raise RuntimeError('STARTUP_EXECUTION_INTEGRITY:' + tests.stdout + tests.stderr)
    result['startup'] = {'pass': passed, 'fail': failed, 'invalid': 0, 'total': 50,
        'returncode': tests.returncode, 'stdout': tests.stdout, 'stderr': tests.stderr,
        'python': sys.executable, 'PYTEST_DISABLE_PLUGIN_AUTOLOAD': os.environ.get('PYTEST_DISABLE_PLUGIN_AUTOLOAD')}
    print('Historical Startup: ' + str(passed) + '/50 PASS', flush=True)
    guard(frozen)
    from v0_2.examples import phase5_r5_2_1r1_validation as r1
    from v0_2.examples.phase5_r5_2_1r4_3_history_validation import s_acceptance, c_acceptance
    from v0_2.examples.phase5_r5_2_1r_validation import build_cases, R52_EVIDENCE, R522_EVIDENCE
    sources = [('C', {k: v for k, v in r1.cases(profile).items() if k != 'C9'}, c_acceptance, 11),
        ('S', build_cases(profile, json.loads(R52_EVIDENCE.read_text(encoding='utf-8')),
            json.loads(R522_EVIDENCE.read_text(encoding='utf-8'))), s_acceptance, 17)]
    for name, cases, acceptance, total in sources:
        guard(frozen)
        inputs = {k: [asdict(x) for x in rows] for k, rows in cases.items()}
        snapshots = {k: run_candidate(rows, profile, classifier) for k, rows in inputs.items()}
        criteria = acceptance(snapshots)
        if len(criteria) != total:
            raise RuntimeError('HISTORICAL_ACCEPTANCE_INVENTORY:' + name)
        result[name] = {'pass': sum(criteria.values()), 'fail': total - sum(criteria.values()),
            'invalid': 0, 'total': total, 'criteria': criteria, 'released_inputs': inputs,
            'snapshots': snapshots, 'fresh_snapshot_hashes': {k: digest(v) for k, v in snapshots.items()},
            'failure_forensics': {'failed_criteria': [k for k, v in criteria.items() if not v],
                'basis': 'Unchanged historical acceptance predicates. Complete input prefixes at every recorded sample retained; no invented exact transition time.'}}
        print('Historical ' + name + ': ' + str(sum(criteria.values())) + '/' + str(total) + ' PASS', flush=True)
        guard(frozen)
    freeze = load('phase5_r5_2_1_p15_reconstructed_history_freeze.json')
    data = load(freeze['input_path'])
    assert sha(ROOT / freeze['input_path']) == freeze['input_file_sha256']
    assert digest(data) == freeze['input_canonical_sha256']
    rows = data['observations']
    p15 = run_candidate(rows, profile, classifier)
    starts = [e for e in p15['epoch_events'] if e['event'] == 'START']
    anchors = p15['resolved_pair_events']
    progress = [r for r in p15['records'] if r['qualified_progress']]
    repeated = [digest(run_candidate(rows, profile, classifier)) for _ in range(10)]
    checks = {
        'exact_epoch_starts': [e['time_ns'] for e in starts] == [600000000, 3400000000],
        'exact_directions': [e['expected_direction'] for e in starts] == [1, 1],
        'exact_anchors': [e['new']['resolved_command_anchor'] for e in anchors] == [0.35, 0.51, 0.67],
        'initial_anchor_direct': bool(anchors) and anchors[0]['reason'] == 'DIRECTLY_OBSERVED_INITIAL_STEADY_BASELINE',
        'stage_progress': len(starts) == 2 and len(anchors) == 3 and all(any(
            starts[i]['time_ns'] < r['time_ns'] <= anchors[i+1]['time_ns'] for r in progress) for i in range(2)),
        'resolved_after_trigger': len(starts) == 2 and len(anchors) == 3 and all(
            anchors[i+1]['time_ns'] > starts[i]['time_ns'] for i in range(2)),
        'anchor_epoch_provenance': [e['new']['source_epoch_id'] for e in anchors[1:]] == [e['epoch_id'] for e in starts],
        'final_steady': p15['state'] == 'STEADY_TRACKING',
        'no_fault': not p15['confirmed_latched'] and all(r['state'] != 'TRACKING_FAULT_CONFIRMED' for r in p15['records']),
        'repeats10': len(set(repeated)) == 1,
        'all_prefixes': all(run_candidate(rows[:n], profile, classifier)['records'] == p15['records'][:n]
            for n in range(1, len(rows) + 1))}
    result['P15'] = {'status': 'PASS' if all(checks.values()) else 'FAIL', 'checks': checks,
        'class': freeze['freeze_status'], 'normativity': freeze['normativity_table'],
        'released_inputs': rows, 'snapshot': p15, 'repeat_sha256_10x': repeated,
        'prefix_count': len(rows)}
    guard(frozen)
    result['pass'] = passed == 50 and failed == 0 and all(result[n]['fail'] == 0 for n in ('C', 'S')) and all(checks.values())
    print('Historical P15: ' + result['P15']['status'], flush=True)
    return result


def write_report(e):
    lines = ['# R4.4A2-R4：冻结环境完整盲测资格报告', '',
        '## 当前结论', '',
        f"ITQ_SUITE_RESULT = {e['ITQ_SUITE_RESULT']}",
        f"R4_4A2_R4_GATE = {e['R4_4A2_R4_GATE']}",
        f"R4_3B_CANDIDATE_QUALIFICATION_STATUS = {e['R4_3B_CANDIDATE_QUALIFICATION_STATUS']}", '',
        '目的：用用户批准的 R3 冻结环境重新完整盲测 R4.3B；新资格测试与历史回归分开，不继承 R2 成绩。', '',
        '## 冻结环境与基线', '',
        f"Python：{sys.executable}；{sys.version}。NumPy {metadata.version('numpy')}；pytest {metadata.version('pytest')}。",
        'PYTEST_DISABLE_PLUGIN_AUTOLOAD=1，子 pytest 使用同一解释器；未安装/升级依赖或修改环境变量。',
        f"环境 hash before：{e.get('environment_before', {}).get('hash')}；after：{e.get('environment_after', {}).get('hash')}。",
        f"基线核验：{json.dumps(e.get('baseline_verification'), ensure_ascii=False)}。",
        f"runner SHA-256：{e.get('runner_sha256')}，在第一次候选导入/行为执行之前冻结。",
        f"冻结时间：{e.get('freeze_timestamp_utc')}；首次行为执行：{e.get('first_candidate_import_execution_utc')}。", '',
        '## ITQ：51 变体', '', '| Case | Variant | dt (s) | Expected | Actual | Result |',
        '| :--- | :--- | ---: | :--- | :--- | :--- |']
    for v in e['variants']:
        lines.append(f"| {v['case_id']} | {v['variant_path']} | {v['physics_dt_ns']/1e9:g} | {v.get('expected_terminal')} | {v.get('actual_terminal')} | {v['status']} |")
    lines += ['', '## 23 案例与 A–X 覆盖', '', '| Case | Result |', '| :--- | :--- |']
    lines += [f'| {k} | {v} |' for k, v in e['case_results'].items()]
    lines += ['', '| Hazard | Cases | Result |', '| :--- | :--- | :--- |']
    lines += [f"| {k} | {','.join(v['cases'])} | {v['result']} |" for k, v in e['hazard_results'].items()]
    lines += ['', '## 失败取证（含 ITQ-013）', '']
    for v in e['variants']:
        if v['status'] == 'FAIL':
            f = v['forensics']
            lines += [f"### {v['case_id']}：{v['variant_path']}", '',
                f"冻结规则错误：{v['errors']}；首个可判定违反时刻：{f['first_divergence_time_ns']/1e9:g} s。",
                '缺失 ORDER milestone/终态要求只在预登记终点可判定；不臆造更早的规范性取消时刻。',
                '终点实际记录：', '', '```json', json.dumps(f['actual_record'], ensure_ascii=False, indent=2), '```', '',
                f"Safety contribution：{f['Safety_contribution']}。",
                f"取消证据：{json.dumps(f.get('cancellation_forensics'), ensure_ascii=False)}。",
                '完整实际输入前缀、watch/epoch/anchor/checkpoint 事件、因果前缀快照在机器证据。没有自动修复。', '']
    prefix_count = sum(len(v.get('prefix_causality', {}).get('checked_prefix_lengths', [])) for v in e['variants'])
    lines += ['## Safety、方向、测量权限、时间与 mesh', '',
        '未改批准 compare_snapshot：终态 Safety、全程严重度上限、允许中间态、禁止态四维分别判定。这里只是 tracking 对 Safety 的贡献，不是修改/运行新的生产 Safety 策略。',
        '方向适配仅使用批准的 epoch_expected_direction、startup_outage_direction、directional_obligation；缺失/类型错误/冲突按原完整性规则处理。',
        '仅传递 ReleasedObservation 八字段；有效样本必须 sample≤release≤tick。全部候选继承链做静态 authority 审计；未引入 TRUE、ACTUAL、flow/DP、未来或未释放值。',
        'EXACT/ORDER/WINDOW/NON_NORMATIVE 完全沿用冻结试卷，无通用容差或新窗口。0.2/0.1/0.05 s 仅运行原矩阵指定变体；不强制跨网格相同样本下标。', '',
        '## Prefix 与重复', '',
        f'新执行 {prefix_count} 个 ITQ prefix；按原命令变化、invalid/recovery、进展/确认/末态选取，逐字段比较全程记录。每变体按原 repeats=2 比较 canonical snapshot hashes。原始检查结果全部留存，没有搬用 R2。', '',
        '## 历史回归（新执行，独立于 ITQ）', '']
    h = e['historical']
    for n in ('startup', 'C', 'S'):
        item = h.get(n, {})
        lines.append(f"{n}：PASS {item.get('pass', 'NOT_RUN')} / {item.get('total', '—')}，FAIL {item.get('fail', '—')}，INVALID {item.get('invalid', '—')}。")
    lines += [f"P15：{h.get('P15', {}).get('status', 'NOT_RUN')}；保留 FROZEN_RECONSTRUCTED_HISTORICAL_FIXTURE 分类及原 normativity，10 次重复、所有 31 前缀独立重新执行。", '',
        '## 前后审计与限制', '',
        f"受保护文件 {len(e.get('protected_hashes', {}))} 个，原字节 before/after 完整记录。Integrity error：{e.get('integrity_error')}。",
        'R4.3B、比较器、原 runner、试卷/预期/errata、profile、Contract15A、生产 Safety/controller/plant/measurement/actuator、历史测试未改。仅新增 R4 编排与结果文件；未触碰 DSX/Twin。',
        'FULL_P_HISTORY_VALIDATION_AVAILABLE = NO；P1–P14、P16–P20 = NOT_RECOVERABLE_FROM_CURRENT_EVIDENCE。ITQ 不等于恢复历史 P。',
        'REAL_HARDWARE_TRACKING_CALIBRATION = CALIBRATION_REQUIRED。CAN_PRODUCTION_PORT_START_NOW = NO。没有 Phase 6，没有 git commit/push。', '',
        '## NEXT ACTION', '', e['next_action'], 'STOP，等待用户审阅。']
    REPORT.write_text('\n'.join(lines) + '\n', encoding='utf-8')


def run():
    if any(p.exists() for p in (EVIDENCE, MANIFEST, REPORT)):
        raise RuntimeError('R4_ARTIFACT_EXISTS_DO_NOT_OVERWRITE')
    e = {'variants': [], 'historical': {'status': 'NOT_RUN'}, 'integrity_error': None}
    frozen = {}
    try:
        env = environment()
        m, baseline, authority = helpers.preflight()
        prereg = load('phase5_r5_2_1r4_4_itq_preregistration.json')
        errata = load('phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json')
        profile = load('phase5_r5_2_2_fixture_tracking_profile.json')
        classifier = load('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
        assert len(m['planned_execution_matrix']) == 51 and prereg['planned_execution_matrix']['repeats'] == 2
        assert [v['case_id'] for v in m['planned_execution_matrix']] == sorted(v['case_id'] for v in m['planned_execution_matrix'])
        frozen = protect(m)
        freeze = {'schema': 'r4-immutable-run-freeze-v1', 'freeze_timestamp_utc': now(),
            'user_authorization': '0a32d3c2-23e3-456b-96dc-b925a1fcbc1a attachment; full R4 blind run',
            'environment_before': env, 'baseline_verification': baseline,
            'execution_baseline_components': m['execution_baseline_components'],
            'runner_sha256': sha(Path(__file__)), 'protected_hashes': frozen,
            'ordered_matrix': m['planned_execution_matrix'], 'measurement_authority_audit': authority,
            'candidate_not_imported_before_freeze': not any(n.startswith('v0_2.examples') for n in sys.modules)}
        save(MANIFEST, freeze)
        frozen[MANIFEST.name] = sha(MANIFEST)
        e.update(freeze)
        e['protected_hashes'] = dict(frozen)
        e['first_candidate_import_execution_utc'] = None
        print('R4 frozen environment and approved baseline PASS; starting ITQ-001', flush=True)
        for entry in m['planned_execution_matrix']:
            guard(frozen)
            fixture, expected = load(entry['input_path']), load(entry['expectation_path'])
            rows = fixture['observations']
            if e['first_candidate_import_execution_utc'] is None:
                e['first_candidate_import_execution_utc'] = now()
            snapshot = run_candidate(rows, profile, classifier)
            comparison = compare_snapshot(snapshot, expected, errata['all_case_interpretations'][entry['case_id']], fixture)
            v = {'case_id': entry['case_id'], 'variant_path': entry['input_path'],
                'physics_dt_ns': entry['physics_dt_ns'], 'input_sha256': entry['input_sha256'],
                'expectation_sha256': entry['expectation_sha256'],
                'expected_terminal': expected['expected_terminal_state'], 'actual_terminal': snapshot['state'],
                'status': comparison['status'], 'errors': list(comparison['errors']),
                'snapshot': snapshot, 'fixture_released_inputs': rows,
                'Safety_dimensions': errata['all_case_interpretations'][entry['case_id']]}
            if comparison['status'] == 'INVALID_EXECUTION':
                e['variants'].append(v)
                raise RuntimeError('APPROVED_COMPARATOR_INVALID_EXECUTION:' + str(v['errors']))
            fields = {'time_ns', 'plc_command', 'command_timestamp_ns', 'measured_speed', 'sample_ns', 'release_ns', 'quality', 'measurement_record_id'}
            if not all(set(r) == fields and (r['quality'] != 'VALID' or r['sample_ns'] <= r['release_ns'] <= r['time_ns']) for r in rows):
                raise RuntimeError('RELEASED_INPUT_AUTHORITY_INTEGRITY_FAILURE')
            pref = prefixes(rows, snapshot, profile, classifier)
            repeat_hashes = [digest(snapshot), digest(run_candidate(rows, profile, classifier))]
            if not pref['pass']:
                v['errors'].append('PREFIX_CAUSALITY_FAILURE')
            if len(set(repeat_hashes)) != 1:
                v['errors'].append('NONDETERMINISM')
            v.update(prefix_causality=pref, repeatability_sha256_2x=repeat_hashes,
                trace_authority='PASS', canonical_snapshot_sha256=repeat_hashes[0],
                status='FAIL' if v['errors'] else 'PASS', forensics=None)
            if v['status'] == 'FAIL':
                f = helpers.forensic(v, snapshot, expected, rows)
                f['prefix_snapshot'] = run_candidate(rows[:len(f['input_prefix'])], profile, classifier)
                f['cancellation_forensics'] = {
                    'watch_events': snapshot.get('watch_events'),
                    'epoch_events': snapshot.get('epoch_events'),
                    'cancel_events': [x for x in snapshot.get('watch_events', []) if x.get('event') == 'CANCEL'],
                    'interpretation_limit': 'Actual events and contemporaneous state only; cause is not inferred as a runtime reason code. Narrow RCA requires separate authorization.'}
                v['forensics'] = f
            guard(frozen)
            e['variants'].append(v)
            save(EVIDENCE, {**e, 'status': 'RUNNING_NOT_FINAL'})
            print(json.dumps({'case': v['case_id'], 'dt': v['physics_dt_ns'], 'status': v['status'], 'errors': v['errors']}), flush=True)
        e['ITQ_completed_validly_utc'] = now()
        e['historical'] = historical(profile, classifier, frozen)
        guard(frozen)
    except Exception as ex:
        e['integrity_error'] = type(ex).__name__ + ':' + str(ex)
    try:
        e['environment_after'] = environment()
        e['source_hashes_after'] = {p: sha(ROOT / p) for p in frozen}
        helpers.immutable(frozen)
    except Exception as ex:
        e['integrity_error'] = (e['integrity_error'] or '') + ';POST_AUDIT:' + str(ex)
    prereg = load('phase5_r5_2_1r4_4_itq_preregistration.json')
    complete = len(e['variants']) == 51 and not e['integrity_error']
    e['case_results'] = {c['case_id']: ('NOT_QUALIFYING' if not complete else
        ('PASS' if all(v['status'] == 'PASS' for v in e['variants'] if v['case_id'] == c['case_id']) else 'FAIL')) for c in prereg['cases']}
    e['hazard_results'] = {h: {'cases': ids, 'result': 'NOT_QUALIFYING' if not complete else
        ('PASS' if all(e['case_results'][c] == 'PASS' for c in ids) else 'FAIL')} for h, ids in prereg['hazard_coverage'].items()}
    passed = complete and all(v['status'] == 'PASS' for v in e['variants'])
    qualified = passed and e['historical'].get('pass', False)
    e['ITQ_SUITE_RESULT'] = 'INVALID_EXECUTION' if not complete else ('PASS' if passed else 'FAIL')
    e['R4_4A2_R4_GATE'] = ('BLIND_QUALIFICATION_INTEGRITY_FAILURE' if not complete else
        'INDEPENDENT_TRACKING_QUALIFICATION_BLIND_FAILURE' if not passed else
        'INDEPENDENT_TRACKING_QUALIFICATION_BLIND_PASS' if qualified else 'HISTORICAL_REGRESSION_AFTER_BLIND_QUALIFICATION')
    e['R4_3B_CANDIDATE_QUALIFICATION_STATUS'] = ('NOT_QUALIFIED_IN_THIS_RUN' if not complete else
        'QUALIFIED_FOR_PRODUCTION_PORT_REVIEW' if qualified else 'NOT_QUALIFIED')
    e.update(FULL_P_HISTORY_VALIDATION_AVAILABLE='NO', REAL_HARDWARE_TRACKING_CALIBRATION='CALIBRATION_REQUIRED',
        CAN_PRODUCTION_PORT_START_NOW='NO', phase6_started=False, git_commit_push=False, end_utc=now(),
        next_action='PHASE 5R5.3R-B PRODUCTION TRACKING PORT PREREQUISITE & CHANGE-PLAN REVIEW' if qualified else
        '审阅正式失败证据；如批准，单独进行失败案例的窄范围 candidate 根因审计/修订，不改冻结试卷。' if complete else
        '审阅执行完整性错误；本轮不得评价候选资格。')
    save(EVIDENCE, e)
    write_report(e)
    print(json.dumps({'suite': e['ITQ_SUITE_RESULT'], 'gate': e['R4_4A2_R4_GATE'],
        'variants': len(e['variants']), 'pass': sum(v['status'] == 'PASS' for v in e['variants']),
        'fail': sum(v['status'] == 'FAIL' for v in e['variants']),
        'integrity_error': e['integrity_error'], 'historical_pass': e['historical'].get('pass')}), flush=True)


if __name__ == '__main__':
    if sys.argv[1:] == ['--preflight']:
        print(json.dumps({'environment': environment(), 'baseline': helpers.preflight()[1:]}, ensure_ascii=False))
    elif sys.argv[1:] == ['run']:
        run()
    else:
        raise SystemExit('Use --preflight or run')
