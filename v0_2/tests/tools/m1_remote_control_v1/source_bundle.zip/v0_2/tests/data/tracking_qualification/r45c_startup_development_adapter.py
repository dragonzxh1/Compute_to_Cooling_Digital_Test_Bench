"""Only inject the new offline candidate into the 50 unchanged Startup bodies."""
from pathlib import Path
from v0_2.examples.phase5_r5_2_1r4_5c_lifecycle_engine import WatchLifecycleTrackingQualifier


def pytest_collection_modifyitems(items):
    modules={item.module for item in items}
    if len(items)!=50 or any(Path(m.__file__).name!='test_phase5_r5_2_1r4_3_startup.py' for m in modules):
        raise RuntimeError('R45C_STARTUP_UNEXPECTED_COLLECTION')
    for module in modules:
        module.StartupTrackingQualifier=WatchLifecycleTrackingQualifier
