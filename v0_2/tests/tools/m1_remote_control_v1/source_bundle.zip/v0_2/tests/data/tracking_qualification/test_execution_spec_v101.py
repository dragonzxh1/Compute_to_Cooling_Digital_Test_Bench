"""Harness-only unit tests with invented static records, never ITQ executions."""

from copy import deepcopy
import sys
import unittest

from .itq_execution_spec_v101 import (
    HarnessSchemaError, SEVERITY_ORDER, compare_static, compare_snapshot,
    outage_obligation_direction, recovery_epoch_direction, safety_errors, validate_expectation,
)


def expectation():
    expected={"case_id":"HARNESS-STATIC","safety":{"highest":"NORMAL","allowed_intermediate":["NORMAL","DEGRADED"],
               "forbidden":["FAULT"],"confirmed_fault_latched":False},
              "expected_public_state_milestones":[
                  {"state":"TRACKING_PROGRESS","timing_normativity":"ORDER_NORMATIVE"},
                  {"state":"STEADY_TRACKING","timing_normativity":"ORDER_NORMATIVE"}],
              "expected_terminal_state":"STEADY_TRACKING","fault_expected":False,
              "forbidden_outcomes":[],"expected_direction_behavior":"CURRENT_NET_DEMAND",
              "schema":"itq-expected-v1","terminal_timing_normativity":"ORDER_NORMATIVE",
              "acceptance":{"terminal_required_by_duration_ns":300},
              "same_sample_reissue_guard":None,"expected_watch_behavior":"RESOLVED_OR_NONE"}
    erratum={"case_id":"HARNESS-STATIC","original_highest_value":"NORMAL",
             "original_allowed_intermediate":["NORMAL","DEGRADED"],"original_forbidden":["FAULT"],
             "terminal_safety_state":"NORMAL","max_allowed_safety_severity":"DEGRADED",
             "allowed_intermediate_safety_states":["NORMAL","DEGRADED"],"forbidden_safety_states":["FAULT"]}
    return expected,erratum


def static_records():
    return [{"state":"TRACKING_FAULT_SUSPECTED","time_ns":100},
            {"state":"TRACKING_PROGRESS","time_ns":200},
            {"state":"STEADY_TRACKING","time_ns":300}]


def direction_example():
    expected,erratum=expectation()
    expected["expected_direction_behavior"]="SUPERSEDE_TO_CURRENT_NEGATIVE_NET_DEMAND"
    records=[{"state":"INSUFFICIENT_MEASUREMENT","time_ns":100,"valid":False,
              "startup_outage_direction":{"direction":-1},"directional_obligation":None},
             {"state":"TRACKING_PROGRESS","time_ns":200,"valid":True,"epoch_expected_direction":-1},
             {"state":"STEADY_TRACKING","time_ns":300,"valid":True,"epoch_expected_direction":None}]
    return expected,erratum,records


def static_fixture():
    return {"case_id":"HARNESS-STATIC","duration_ns":300,
            "measurement_timeline":{"invalid_windows_ns":[]},
            "observations":[{"time_ns":t,"quality":"VALID","release_ns":t} for t in (100,200,300)]}


def static_snapshot():
    return {"records":static_records(),"watch_events":[],"confirmed_latched":False}


class HarnessOnlyTests(unittest.TestCase):
    def test_correct_epoch_direction_field(self):
        self.assertEqual(recovery_epoch_direction({"epoch_expected_direction":-1}),-1)

    def test_missing_epoch_field_invalid_execution(self):
        e,a,r=direction_example(); r[1].pop("epoch_expected_direction")
        self.assertEqual(compare_static(r,e,a,invalid_windows_ns=[[100,200]])["status"],"INVALID_EXECUTION")

    def test_wrong_type_epoch_field_invalid_execution(self):
        for value in ("-1",-1.0,True,0,[],{}):
            with self.subTest(value=value):
                e,a,r=direction_example(); r[1]["epoch_expected_direction"]=value
                self.assertEqual(compare_static(r,e,a,invalid_windows_ns=[[100,200]])["status"],"INVALID_EXECUTION")

    def test_no_unrelated_field_fallback(self):
        with self.assertRaises(HarnessSchemaError):
            recovery_epoch_direction({"expected_direction":-1,"direction":-1})

    def test_dictionary_order_invariant(self):
        record={"state":"HANDOFF_PENDING","epoch_expected_direction":-1,"valid":True}
        self.assertEqual(recovery_epoch_direction(record),recovery_epoch_direction(dict(reversed(list(record.items())))))

    def test_direction_comparison_all_records_validated(self):
        e,a,r=direction_example(); r[-1].pop("epoch_expected_direction")
        self.assertEqual(compare_static(r,e,a,invalid_windows_ns=[[100,200]])["status"],"INVALID_EXECUTION")

    def test_startup_outage_direction_carrier(self):
        self.assertEqual(outage_obligation_direction({"startup_outage_direction":{"direction":-1},"directional_obligation":None}),-1)

    def test_resolved_pair_outage_direction_carrier(self):
        self.assertEqual(outage_obligation_direction({"startup_outage_direction":None,"directional_obligation":{"direction":1}}),1)

    def test_closed_epoch_not_outage_obligation_fallback(self):
        self.assertIsNone(outage_obligation_direction({"startup_outage_direction":None,"directional_obligation":None,"epoch_expected_direction":-1}))

    def test_conflicting_direction_carriers_invalid(self):
        with self.assertRaises(HarnessSchemaError):
            outage_obligation_direction({"startup_outage_direction":{"direction":-1},"directional_obligation":{"direction":1}})

    def test_allowed_degraded_intermediate_normal_terminal(self):
        e,a=expectation()
        self.assertEqual(compare_static(static_records(),e,a)["status"],"PASS")

    def test_maximum_is_upper_bound_not_required_observation(self):
        e,a=expectation()
        r=static_records()[1:]
        self.assertEqual(compare_static(r,e,a)["status"],"PASS")

    def test_terminal_degraded_not_normal(self):
        e,a=expectation(); r=static_records(); r[-1]["state"]="TRACKING_FAULT_SUSPECTED"
        self.assertEqual(compare_static(r,e,a)["status"],"FAIL")

    def test_maximum_violation_fails(self):
        e,a=expectation(); r=static_records(); r[0]["state"]="TRACKING_FAULT_CONFIRMED"
        self.assertIn("MAX_ALLOWED_SAFETY_EXCEEDED",compare_static(r,e,a)["errors"])

    def test_forbidden_safety_state_fails(self):
        e,a=expectation(); r=static_records(); r[0]["state"]="TRACKING_FAULT_CONFIRMED"
        self.assertIn("FORBIDDEN_SAFETY_STATE",compare_static(r,e,a)["errors"])

    def test_complete_safety_hierarchy(self):
        states=["NORMAL","FF_DISABLED","DEGRADED","DERATE_REQUESTED","PROTECTED","FAULT"]
        self.assertEqual([SEVERITY_ORDER[s] for s in states],list(range(6)))

    def test_persistent_terminal_fault_not_unlisted_intermediate(self):
        e,a=expectation(); e["safety"]["highest"]="FAULT"; e["safety"]["forbidden"]=[]
        a.update(original_highest_value="FAULT",original_forbidden=[],terminal_safety_state="FAULT",max_allowed_safety_severity="FAULT",forbidden_safety_states=[])
        r=[{"state":"TRACKING_FAULT_CONFIRMED"},{"state":"TRACKING_FAULT_CONFIRMED"}]
        self.assertEqual(safety_errors(r,e,a),[])

    def test_required_milestone_order(self):
        e,a=expectation(); r=static_records(); r[1],r[2]=r[2],r[1]
        self.assertEqual(compare_static(r,e,a)["status"],"FAIL")

    def test_order_normative_ignores_incidental_time(self):
        e,a=expectation(); r=static_records(); r[1]["time_ns"]=200000; r[2]["time_ns"]=900000
        self.assertEqual(compare_static(r,e,a)["status"],"PASS")

    def test_non_normative_time_ignored_but_milestone_required(self):
        e,a=expectation(); e["expected_public_state_milestones"][0].update(timing_normativity="NON_NORMATIVE",time_ns=999)
        self.assertEqual(compare_static(static_records(),e,a)["status"],"PASS")
        self.assertEqual(compare_static(static_records()[::2],e,a)["status"],"FAIL")

    def test_exact_normative_time_enforced(self):
        e,a=expectation(); e["expected_public_state_milestones"][0].update(timing_normativity="EXACT_NORMATIVE",time_ns=200)
        self.assertEqual(compare_static(static_records(),e,a)["status"],"PASS")
        r=static_records(); r[1]["time_ns"]=201
        self.assertEqual(compare_static(r,e,a)["status"],"FAIL")

    def test_exact_without_registered_time_invalid(self):
        e,a=expectation(); e["expected_public_state_milestones"][0]["timing_normativity"]="EXACT_NORMATIVE"
        self.assertEqual(compare_static(static_records(),e,a)["status"],"INVALID_EXECUTION")

    def test_window_only_explicit_frozen_bounds(self):
        e,a=expectation(); m=e["expected_public_state_milestones"][0]
        m.update(timing_normativity="WINDOW_NORMATIVE",frozen_window_ns=[190,210])
        self.assertEqual(compare_static(static_records(),e,a)["status"],"PASS")
        r=static_records(); r[1]["time_ns"]=211
        self.assertEqual(compare_static(r,e,a)["status"],"FAIL")
        m.pop("frozen_window_ns")
        self.assertEqual(compare_static(static_records(),e,a)["status"],"INVALID_EXECUTION")

    def test_unknown_public_state_invalid_execution(self):
        e,a=expectation(); r=static_records(); r[0]["state"]="INVENTED_STATE"
        self.assertEqual(compare_static(r,e,a)["status"],"INVALID_EXECUTION")

    def test_normal_vs_fault_classification_preserved(self):
        e,a=expectation(); r=static_records(); r[0]["state"]="TRACKING_FAULT_CONFIRMED"
        self.assertIn("FALSE_POSITIVE_TRACKING_FAULT",compare_static(r,e,a)["errors"])

    def test_original_expectation_is_not_mutated(self):
        e,a=expectation(); original=deepcopy(e)
        compare_static(static_records(),e,a)
        self.assertEqual(e,original)

    def test_static_expectation_validation_not_behavior(self):
        e,a=expectation()
        result=validate_expectation(e,a,static_fixture())
        self.assertEqual(result["status"],"CONSISTENT")
        self.assertFalse(result["behavior_evaluated"])

    def test_static_forbidden_and_allowed_conflict(self):
        e,a=expectation(); e["safety"]["forbidden"]=["DEGRADED"]
        a.update(original_forbidden=["DEGRADED"],forbidden_safety_states=["DEGRADED"])
        self.assertEqual(validate_expectation(e,a,static_fixture())["status"],"INCONSISTENT")

    def test_static_errata_cannot_widen_maximum(self):
        e,a=expectation(); a["max_allowed_safety_severity"]="FAULT"
        self.assertEqual(validate_expectation(e,a,static_fixture())["status"],"INCONSISTENT")

    def test_static_errata_cannot_remove_prohibition(self):
        e,a=expectation(); a["forbidden_safety_states"]=[]
        self.assertEqual(validate_expectation(e,a,static_fixture())["status"],"INCONSISTENT")

    def test_static_errata_cannot_add_allowed_intermediate(self):
        e,a=expectation(); a["allowed_intermediate_safety_states"].append("PROTECTED")
        self.assertEqual(validate_expectation(e,a,static_fixture())["status"],"INCONSISTENT")

    def test_compare_snapshot_preserves_reissue_guard(self):
        e,a=expectation(); e["same_sample_reissue_guard"]={"time_ns":100,"forbid_confirmed_on_this_sample":True}
        snap=static_snapshot(); snap["records"][0]["state"]="TRACKING_FAULT_CONFIRMED"
        self.assertIn("SAME_SAMPLE_STALE_CONFIRMATION",compare_snapshot(snap,e,a,static_fixture())["errors"])

    def test_compare_snapshot_preserves_watch_check(self):
        e,a=expectation(); e["expected_watch_behavior"]="PRESERVE_OLDEST_UNRESOLVED"
        snap=static_snapshot(); snap["watch_events"]=[{"event":"START","watch_start_ns":100},{"event":"START","watch_start_ns":200}]
        self.assertIn("WATCH_AGE_ERASURE",compare_snapshot(snap,e,a,static_fixture())["errors"])

    def test_compare_snapshot_preserves_measurement_validity_check(self):
        e,a=expectation(); fixture=static_fixture(); fixture["observations"][0]["quality"]="MISSING"
        self.assertIn("INVALID_MEASUREMENT_EARNED_TRACKING_STATE",compare_snapshot(static_snapshot(),e,a,fixture)["errors"])

    def test_compare_snapshot_time_plumbing_invalid_execution(self):
        e,a=expectation(); snap=static_snapshot(); snap["records"][0]["time_ns"]=99
        self.assertEqual(compare_snapshot(snap,e,a,static_fixture())["status"],"INVALID_EXECUTION")

    def test_compare_snapshot_preserves_fault_latch(self):
        e,a=expectation()
        e.update(expected_terminal_state="TRACKING_FAULT_CONFIRMED",fault_expected=True,
                 expected_public_state_milestones=[{"state":"TRACKING_FAULT_CONFIRMED","timing_normativity":"ORDER_NORMATIVE"}])
        e["safety"].update(highest="FAULT",forbidden=[],confirmed_fault_latched=True)
        a.update(original_highest_value="FAULT",original_forbidden=[],terminal_safety_state="FAULT",max_allowed_safety_severity="FAULT",forbidden_safety_states=[])
        snap=static_snapshot(); snap["records"][-1]["state"]="TRACKING_FAULT_CONFIRMED"
        self.assertIn("FAULT_NOT_LATCHED",compare_snapshot(snap,e,a,static_fixture())["errors"])

    def test_no_candidate_module_imported(self):
        names=[n for n in sys.modules if n.startswith("v0_2.examples.phase5_r5_2_1")]
        self.assertEqual(names,[])


if __name__=="__main__":
    unittest.main()
