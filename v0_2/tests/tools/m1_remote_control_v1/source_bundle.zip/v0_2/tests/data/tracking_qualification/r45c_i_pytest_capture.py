"""Dependency-free pytest hooks; durable native reports plus builtin JUnit."""
import json
import os
from pathlib import Path

import pytest

from .r45c_i_evidence import atomic_json, canonical, sha
from .r45c_i_startup_guard import assertion_identity

_state = None
_directory = None
_root = Path(__file__).resolve().parents[4]


def pytest_addoption(parser):
    parser.addoption('--c2c-evidence-dir', action='store', default=None)


def _append(event):
    with (_directory/'pytest_reports.jsonl').open('ab') as f:
        f.write(canonical(event)+b'\n'); f.flush(); os.fsync(f.fileno())


def pytest_configure(config):
    global _state, _directory
    value = config.getoption('--c2c-evidence-dir')
    if not value:
        raise RuntimeError('C2C_EVIDENCE_DIRECTORY_REQUIRED')
    _directory = Path(value).resolve()
    _state = {'schema':'c2c-pytest-structured-v1', 'session_complete':False,
              'collected_nodeids':[], 'reports':[], 'collection_errors':[]}
    _append({'event':'SESSION_START'})


def pytest_collection_finish(session):
    _state['collected_nodeids'] = [item.nodeid for item in session.items]
    _append({'event':'COLLECTION', 'nodeids':_state['collected_nodeids']})


def pytest_collectreport(report):
    if report.failed:
        _state['collection_errors'].append(str(report.longrepr))
        _append({'event':'COLLECTION_ERROR', 'message':str(report.longrepr)})


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    report.c2c_exception_type = call.excinfo.typename if call.excinfo is not None else None


def pytest_runtest_logreport(report):
    item = {'nodeid':report.nodeid, 'when':report.when, 'outcome':report.outcome,
            'wasxfail':getattr(report,'wasxfail',None),
            'longrepr':str(report.longrepr) if report.longrepr else None,
            'failure_identity':None, 'exception_type':getattr(report,'c2c_exception_type',None)}
    if report.failed and report.when == 'call':
        crash = getattr(report.longrepr, 'reprcrash', None)
        if crash is not None:
            source = Path(crash.path)
            if not source.is_absolute():
                source = _root/source
            try:
                source = source.resolve()
                rel = source.relative_to(_root).as_posix()
                expression = assertion_identity(source, crash.lineno)
                signature = json.loads((_root/'phase5_r5_2_1r4_5c_i_startup_legacy_signature.json').read_bytes())
                narrow = (rel == signature['source_path'] and sha(source) == signature['source_raw_sha256']
                    and crash.lineno == signature['assertion_line_1based'] and expression == signature['assertion_ast']
                    and report.nodeid == signature['nodeid']
                    and item['exception_type'] == 'AssertionError')
                item['failure_identity'] = {'source_path':rel, 'source_raw_sha256':sha(source),
                    'assertion_line_1based':crash.lineno, 'assertion_ast':expression,
                    'semantic_identifier':signature['semantic_identifier'] if narrow else 'UNRECOGNIZED_ASSERTION',
                    'exception_type':item['exception_type'],
                    'message':crash.message}
            except (OSError, ValueError, AttributeError):
                pass
    _state['reports'].append(item)
    _append({'event':'REPORT', **item})


def pytest_sessionfinish(session, exitstatus):
    _state.update(session_complete=True, exit_status=int(exitstatus))
    _append({'event':'SESSION_END', 'exit_status':int(exitstatus)})
    atomic_json(_directory/'pytest_results.json', _state)
