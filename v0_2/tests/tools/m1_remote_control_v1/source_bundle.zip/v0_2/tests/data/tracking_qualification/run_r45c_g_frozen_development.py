"""G execution adapter: frozen expectations, fresh runs, stop on first gate failure.

Created before behavioral execution. No candidate or frozen file writes.
Evidence is emitted to stdout; caller archives it without changing this adapter.
"""
import json
import subprocess
from dataclasses import asdict
from pathlib import Path
from unittest.mock import patch

from . import run_r45c_policy_a_development as policy
from . import run_r45c_development as development
from . import run_itq_blind as blind
from . import run_r44a2_r4 as historical
from .itq_execution_spec_v101 import compare_snapshot
from .verify_itq_preregistration import sha

ROOT = Path(__file__).resolve().parents[4]
load, digest = policy.load, policy.digest
U_PATH = 'phase5_r5_2_1r4_5c_g_st12_u_control_v1_registration.json'
V2_PATH = 'phase5_r5_2_1r4_5c_f_st12_policy_a_v2_registration.json'


def u_checks(s):
    at = {r['time_ns']: r for r in s['records']}
    w, n = at[1200000000], at[2600000000]
    pause = [r for r in s['records'] if 1200000000 <= r['time_ns'] < 2600000000]
    h = s['response_history']
    old = [e for e in h if e['evaluation_tick_ns'] == 1200000000]
    starts = [e for e in s['watch_events'] if e['event'] == 'START']
    context = n['directional_obligation']
    initial = n['startup_observation']
    return {
        'ST12-U-01': w['measurement_attribution'] == 'OLD_OBLIGATION' and len(old) == 1
            and old[0]['old_command'] == .7 and old[0]['command_timestamp_ns'] == 0
            and old[0]['source_measurement_record_id'] == 'synthetic-measurement:1200000000'
            and old[0]['sample_ns'] == old[0]['release_ns'] == 1200000000,
        'ST12-U-02': at[1000000000]['carried_suspicion_evidence'] == 0
            and w['carried_suspicion_evidence'] == 1 and w['checkpoint_measured_displacement'] == 0,
        'ST12-U-03': not w['confirmed_latched'],
        'ST12-U-04': not w['current_direction_active'] and w['directional_obligation'] is None,
        'ST12-U-05': len(starts) == 1 and all(r['history_retained'] and r['oldest_unresolved_demand_ns'] == 0
            and r['startup_observation']['measurement_record_id'] == 'synthetic-measurement:0'
            and r['startup_observation']['sample_ns'] == 0 for r in pause)
            and not any(e['event'] == 'CANCEL' for e in s['watch_events']),
        'ST12-U-06': all(r['startup_demand_suspended'] and not r['confirmed_latched']
            and not r['current_direction_active'] for r in pause),
        'ST12-U-07': not any(1200000000 < e['evaluation_tick_ns'] < 2600000000 for e in h)
            and not any(r['qualified_progress'] for r in pause),
        'ST12-U-08': len(pause) == 7 and all(r['carried_suspicion_evidence'] == 1
            and not r['confirmed_latched'] and r['oldest_unresolved_demand_ns'] == 0 for r in pause),
        'ST12-U-09': n['current_direction_active'] and context is not None
            and context['direction'] == 1 and context['established_ns'] == 2600000000
            and context['command'] == .7 and n['expected_motion'] == 0
            and n['oldest_unresolved_demand_ns'] == 0 and len(starts) == 1
            and initial['measurement_record_id'] == 'synthetic-measurement:0'
            and n['progress_command_reference'] == .7 and n['progress_measurement_reference'] == .5
            and n['progress_pair_id'] == at[0]['progress_pair_id'],
        'ST12-U-10': len({e['source_measurement_record_id'] for e in h}) == len(h)
            and not n['qualified_progress'] and n['carried_suspicion_evidence'] == w['carried_suspicion_evidence'],
        'ST12-U-11': n['carried_suspicion_evidence'] == 1 and not n['confirmed_latched']
            and n['state'] == 'HANDOFF_PENDING' and not any(t['time_ns'] == 2600000000
            and t['to'] == 'TRACKING_FAULT_CONFIRMED' for t in s['transitions']),
        'ST12-U-12': context is not None and context['established_ns'] == 2600000000
            and not n['startup_demand_suspended'] and n['carried_suspicion_evidence'] == 1
            and n['oldest_unresolved_demand_ns'] == 0,
        'registered_withdrawal_public_state': w['state'] == 'STEADY_TRACKING',
        'registered_terminal': at[4000000000]['carried_suspicion_evidence'] == 2
            and at[4000000000]['confirmed_latched'] and at[4000000000]['state'] == 'TRACKING_FAULT_CONFIRMED',
    }


def v2_checks(s, u):
    inherited = policy.policy_a_checks(s)
    at = {r['time_ns']: r for r in s['records']}
    return {
        'V2-01': inherited['ST12A-01_actual_prior_evidence'],
        'V2-02': inherited['ST12A-02_old_evaluation_before_withdrawal'],
        'V2-03': inherited['ST12A-03_post_evaluation_snapshot'],
        'V2-04': inherited['ST12A-04_earned_confirmed_latch_preserved'],
        'V2-05': inherited['ST12A-06_withdrawal_closes_direction_despite_latch'],
        'V2-06': inherited['ST12A-05_one_watch_original_provenance'],
        'V2-07': all(r['oldest_unresolved_demand_ns'] == 0
            and r['startup_observation']['measurement_record_id'] == 'synthetic-measurement:0'
            for r in s['records'] if r['time_ns'] >= 1400000000),
        'V2-08': inherited['ST12A-07_pause_preserves_post_snapshot_without_reevaluation'],
        'V2-09': inherited['ST12A-09_no_duplicate_source_credit'],
        'V2-10': inherited['ST12A-08_reissue_no_reset_or_new_stale_confirmation'],
        'V2-11': all(u.values()),
        # No True/False predicate is applied to State C. This is comparator
        # scope inspection, not fabricated behavioral snapshots.
        'V2-12': at[1400000000]['confirmed_latched'] and not at[1400000000]['current_direction_active'],
        'V2-13': at[1400000000]['confirmed_latched'] and not at[1400000000]['current_direction_active'],
        'inherited_remaining_properties': all(inherited.values()),
    }


class StopGate(Exception):
    pass


def main():
    e = {'schema': 'r45c-g-frozen-development-execution-v1', 'authorization': 'GRANTED_BY_USER',
         'execution_order': [], 'semantic_tests': [], 'targeted_ITQ': [], 'historical': {},
         'full_51_qualification_executed': False, 'git_commit_push': False, 'phase6_started': False,
         'CAN_PRODUCTION_PORT_START': 'NO', 'FULL_P_HISTORY_VALIDATION_AVAILABLE': 'NO',
         'REAL_HARDWARE': 'CALIBRATION_REQUIRED'}
    protected = {}
    def guard():
        for p, expected in protected.items():
            if sha(ROOT / p) != expected:
                raise RuntimeError('HASH_DRIFT:' + p)
        return policy.verify_environment()
    def require(ok, name):
        if not ok:
            raise StopGate(name)
    def evaluate(name, rows, replay, checker):
        guard()
        s = replay(rows)
        checks = checker(s)
        result = {'case_id': name, 'checks': checks, 'input_sha256': digest(rows),
                  'snapshot': s, 'snapshot_sha256': digest(s)}
        e['execution_order'].append(name)
        # Do not execute prefixes/repeats after a behavioral failure.
        if not all(checks.values()):
            result['status'] = 'FAIL'
            return result
        result['prefix_failures'] = [n for n in range(1, len(rows)+1)
            if replay(rows[:n])['records'] != s['records'][:n]]
        result['prefix_count'] = len(rows)
        result['repeat_hashes'] = [digest(s), digest(replay(rows))]
        result['status'] = 'PASS' if not result['prefix_failures'] and len(set(result['repeat_hashes'])) == 1 else 'FAIL'
        guard()
        return result
    try:
        ureg = load(U_PATH)
        canonical = {policy.EXPECTED_AMENDMENT: 'phase5_r5_2_1r4_5c_c_same_tick_priority_amendment.json',
            '8c793bd14e9184b1b1784ad772db4e29a00ea120c7b4ababa4f60f648f2f8976': V2_PATH,
            '2dbc47f859eb05bcda99ffbb2941752260d55bc8c33e3e1d68b6501f5bbcf707': U_PATH}
        for expected, p in canonical.items():
            if digest(load(p)) != expected:
                raise RuntimeError('CANONICAL_DRIFT:' + p)
        frozen = load('phase5_r5_2_1r4_5b_watch_retention_semantics_evidence.json')
        protected.update(frozen['protected_sources']['before'])
        protected.update(frozen['frozen_itq']['before'])
        protected.update(load('phase5_r5_2_1r4_5c_g_st12_u_control_v1_user_approved_freeze.json')['protected_raw_hashes'])
        for p in canonical.values():
            protected.setdefault(p, sha(ROOT / p))
        protected[str(Path(__file__).relative_to(ROOT).as_posix())] = sha(Path(__file__))
        e['protected_hashes_before'] = protected.copy()
        e['canonical_baselines'] = canonical
        e['environment_before'] = guard()
        from v0_2.tests.control import test_phase5_r5_2_1r4_5c_lifecycle as st
        replay = lambda rows: development.replay(rows, st.PROFILE, st.CLASSIFIER)
        # First authorized gate: exactly the 21 frozen observations, no generator.
        e['state_u_initial_gate'] = evaluate('ST12-U-CONTROL-v1', ureg['input']['observations'], replay, u_checks)
        require(e['state_u_initial_gate']['status'] == 'PASS', 'STATE_U_CONTROL_FAIL_STOP')
        # Fresh complete development run; do not reuse initial-gate results.
        e['state_u_development_rerun'] = evaluate('ST12-U-CONTROL-v1-FRESH', ureg['input']['observations'], replay, u_checks)
        require(e['state_u_development_rerun']['status'] == 'PASS', 'STATE_U_FRESH_FAIL_STOP')
        for definition in st.REG['semantic_test_definitions']:
            case = definition['id']
            checker = (lambda s: v2_checks(s, e['state_u_development_rerun']['checks'])) if case == 'ST-12' else (lambda s, c=case: st.checks(c, s))
            result = evaluate('ST-12-POLICY-A-v2' if case == 'ST-12' else case,
                st.inputs(case), lambda rows, c=case: st.replay(c, rows), checker)
            e['semantic_tests'].append(result)
            require(result['status'] == 'PASS', case + '_FAIL_STOP')
        matrix = load('phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json')['planned_execution_matrix']
        errata = load('phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json')
        selected = {'ITQ-010', 'ITQ-012', 'ITQ-013', 'ITQ-014', 'ITQ-017', 'ITQ-019', 'ITQ-020', 'ITQ-021'}
        for entry in matrix:
            if entry['case_id'] not in selected:
                continue
            fixture, expected = load(entry['input_path']), load(entry['expectation_path'])
            def check(s):
                comparison = compare_snapshot(s, expected, errata['all_case_interpretations'][entry['case_id']], fixture)
                if comparison['status'] == 'INVALID_EXECUTION':
                    raise RuntimeError(str(comparison))
                return {'frozen_comparator': comparison['status'] == 'PASS', 'comparison': comparison}
            def boolean_check(s):
                comparison = check(s)
                e['latest_comparison'] = comparison['comparison']
                return {'frozen_comparator': comparison['frozen_comparator']}
            result = evaluate(entry['case_id'] + ':' + entry['input_path'], fixture['observations'], replay, boolean_check)
            result['comparison'] = e.pop('latest_comparison')
            e['targeted_ITQ'].append(result)
            require(result['status'] == 'PASS', entry['case_id'] + '_FAIL_STOP')
        require(len(e['targeted_ITQ']) == 12, 'TARGET_INVENTORY')
        # Original 50 bodies remain byte-for-byte unchanged. Known legacy conflict
        # is recorded separately, never relabelled as original 50/50.
        guard()
        completed = development.startup_adapter([historical.sys.executable, '-m', 'pytest', '-q',
            'v0_2/tests/control/test_phase5_r5_2_1r4_3_startup.py', '-o', 'addopts=', '-p', 'no:cacheprovider'],
            cwd=ROOT, text=True, capture_output=True)
        e['historical']['Startup'] = {'stdout': completed.stdout, 'stderr': completed.stderr, 'returncode': completed.returncode}
        known = 'test_startup_demand_with_suspicion_suspends_then_reintroduces'
        require(completed.returncode == 1 and '1 failed, 49 passed' in completed.stdout
            and ('FAILED v0_2/tests/control/test_phase5_r5_2_1r4_3_startup.py::' + known) in completed.stdout,
            'UNEXPECTED_ORIGINAL_STARTUP_RESULT')
        e['ORIGINAL_STARTUP_HISTORICAL_RESULT'] = '49/50'
        e['VERSIONED_STARTUP_COMPATIBILITY'] = 'PASS'
        guard()
        from v0_2.examples import phase5_r5_2_1r1_validation as r1
        from v0_2.examples.phase5_r5_2_1r4_3_history_validation import c_acceptance, s_acceptance
        from v0_2.examples.phase5_r5_2_1r_validation import build_cases, R52_EVIDENCE, R522_EVIDENCE
        suites = [('C', {k:v for k,v in r1.cases(st.PROFILE).items() if k != 'C9'}, c_acceptance, 11),
            ('S', build_cases(st.PROFILE, json.loads(R52_EVIDENCE.read_text(encoding='utf-8')),
                json.loads(R522_EVIDENCE.read_text(encoding='utf-8'))), s_acceptance, 17)]
        for name, cases, accept, total in suites:
            rows = {k:[asdict(x) for x in v] for k,v in cases.items()}
            snaps = {k:replay(v) for k,v in rows.items()}
            criteria = accept(snaps)
            e['historical'][name] = {'criteria': criteria, 'snapshots': snaps, 'inputs': rows}
            require(len(criteria) == total and all(criteria.values()), name + '_FAIL_STOP')
            repeat = {k:digest(replay(v)) for k,v in rows.items()}
            e['historical'][name]['repeat_hashes'] = repeat
            require(all(repeat[k] == digest(snaps[k]) for k in rows), name + '_REPEAT_FAIL')
            guard()
        # Same P15 predicates as frozen historical helper, no new tolerances.
        freeze = load('phase5_r5_2_1_p15_reconstructed_history_freeze.json')
        data = load(freeze['input_path'])
        require(sha(ROOT/freeze['input_path']) == freeze['input_file_sha256']
            and digest(data) == freeze['input_canonical_sha256'], 'P15_INPUT_INTEGRITY')
        rows = data['observations']
        s = replay(rows)
        starts = [x for x in s['epoch_events'] if x['event'] == 'START']
        anchors = s['resolved_pair_events']
        progress = [r for r in s['records'] if r['qualified_progress']]
        checks = {
            'exact_epoch_starts': [x['time_ns'] for x in starts] == [600000000,3400000000],
            'exact_directions': [x['expected_direction'] for x in starts] == [1,1],
            'exact_anchors': [x['new']['resolved_command_anchor'] for x in anchors] == [.35,.51,.67],
            'initial_anchor_direct': bool(anchors) and anchors[0]['reason'] == 'DIRECTLY_OBSERVED_INITIAL_STEADY_BASELINE',
            'stage_progress': len(starts) == 2 and len(anchors) == 3 and all(any(
                starts[i]['time_ns'] < r['time_ns'] <= anchors[i+1]['time_ns'] for r in progress) for i in range(2)),
            'resolved_after_trigger': len(starts) == 2 and len(anchors) == 3 and all(
                anchors[i+1]['time_ns'] > starts[i]['time_ns'] for i in range(2)),
            'anchor_epoch_provenance': [x['new']['source_epoch_id'] for x in anchors[1:]] == [x['epoch_id'] for x in starts],
            'final_steady': s['state'] == 'STEADY_TRACKING',
            'no_fault': not s['confirmed_latched'] and all(r['state'] != 'TRACKING_FAULT_CONFIRMED' for r in s['records']),
        }
        e['historical']['P15'] = {'checks':checks, 'snapshot':s, 'inputs':rows}
        require(all(checks.values()), 'P15_FAIL_STOP')
        repeated = [digest(replay(rows)) for _ in range(10)]
        prefix = [n for n in range(1,len(rows)+1) if replay(rows[:n])['records'] != s['records'][:n]]
        e['historical']['P15'].update(status='PASS' if len(set(repeated)) == 1 and not prefix else 'FAIL',
            repeat_sha256_10x=repeated, prefix_count=len(rows), prefix_failures=prefix)
        require(e['historical']['P15']['status'] == 'PASS', 'P15_CAUSALITY_REPEAT_FAIL')
        e['R4_5C_GATE'] = 'WATCH_LIFECYCLE_REVISION_IMPLEMENTED_AND_DEVELOPMENT_VALIDATED'
        e['R4_5C_CANDIDATE_STATUS'] = 'DEVELOPMENT_VALIDATED_NOT_REQUALIFIED'
    except StopGate as ex:
        e['stop_reason'] = str(ex)
        e['R4_5C_GATE'] = 'DEVELOPMENT_VALIDATION_FAILED_STOPPED'
        e['R4_5C_CANDIDATE_STATUS'] = 'DEVELOPMENT_VALIDATION_FAILED_NOT_REQUALIFIED'
    except Exception as ex:
        e['integrity_error'] = type(ex).__name__ + ':' + str(ex)
        e['R4_5C_GATE'] = 'INVALID_EXECUTION'
        e['R4_5C_CANDIDATE_STATUS'] = 'DEVELOPMENT_VALIDATION_BLOCKED_NOT_REQUALIFIED'
    try:
        e['environment_after'] = guard()
        e['protected_hashes_after'] = {p:sha(ROOT/p) for p in protected}
    except Exception as ex:
        e['post_integrity_error'] = type(ex).__name__ + ':' + str(ex)
        e['R4_5C_GATE'] = 'INVALID_EXECUTION'
    print('R45CG_JSON_BEGIN')
    print(json.dumps(e, ensure_ascii=False, separators=(',', ':')))


if __name__ == '__main__':
    main()
