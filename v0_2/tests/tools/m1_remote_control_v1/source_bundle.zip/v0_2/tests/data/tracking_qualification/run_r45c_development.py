"""Reproducible R4.5C development evidence; stdout only, no frozen artifact writes."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

from . import run_itq_blind as blind
from . import run_r44a2_r4 as historical_runner
from .itq_execution_spec_v101 import compare_snapshot
from .verify_itq_preregistration import sha

ROOT = Path(__file__).resolve().parents[4]
load = lambda p: json.loads((ROOT/p).read_text(encoding='utf-8'))
digest = historical_runner.digest
REAL_RUN = subprocess.run


def replay(rows, profile, classifier):
    from v0_2.examples.phase5_r5_2_1r4_5c_lifecycle_engine import WatchLifecycleTrackingQualifier
    from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation
    q=WatchLifecycleTrackingQualifier(profile,classifier)
    for row in rows:q.update(ReleasedObservation(**row))
    return q.snapshot()


def startup_adapter(args, **kwargs):
    assert args[:3]==[sys.executable,'-m','pytest']
    return REAL_RUN(args+['-p','v0_2.tests.data.tracking_qualification.r45c_startup_development_adapter'],**kwargs)


def main():
    frozen=load('phase5_r5_2_1r4_5b_watch_retention_semantics_evidence.json')
    reg=load(frozen['registration']['path'])
    approval=load('phase5_r5_2_1r4_5b_user_approved_semantic_freeze.json')
    assert digest(reg)==approval['registration_canonical_sha256']==frozen['registration']['canonical_sha256']
    assert digest(reg['truth_table'])==approval['truth_table_canonical_sha256']
    assert digest(reg['semantic_test_definitions'])==approval['semantic_tests_canonical_sha256']
    protected=dict(frozen['protected_sources']['before'])
    protected.update(frozen['frozen_itq']['before'])
    paths=['phase5_r5_2_1r4_5b_watch_retention_semantics_registration.json',
        'phase5_r5_2_1r4_5b_user_approved_semantic_freeze.json',
        'phase5_r5_2_1r4_5b_watch_retention_semantics_evidence.json',
        'PHASE5_R5_2_1R4_5B_WATCH_RETENTION_SEMANTICS_PREREGISTRATION.md',
        'v0_2/examples/phase5_r5_2_1r4_5c_lifecycle_engine.py',
        'v0_2/tests/control/test_phase5_r5_2_1r4_5c_lifecycle.py',
        'v0_2/tests/data/tracking_qualification/r45c_startup_development_adapter.py',
        'v0_2/tests/data/tracking_qualification/run_r45c_development.py']
    protected.update({p:sha(ROOT/p) for p in paths})
    historical_runner.guard(protected)
    e={'schema':'r45c-development-validation-v1','classification':'DEVELOPMENT_VALIDATION_NOT_REQUALIFICATION',
       'approval':approval,'protected_hashes_before':protected,'environment_before':historical_runner.environment(),
       'semantic_tests':[],'targeted_ITQ':[],'integrity_error':None,'historical':{'status':'NOT_RUN'}}
    profile=load('phase5_r5_2_2_fixture_tracking_profile.json')
    classifier=load('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    try:
        from v0_2.tests.control import test_phase5_r5_2_1r4_5c_lifecycle as st
        for definition in reg['semantic_test_definitions']:
            case=definition['id'];rows=st.inputs(case);snap=st.replay(case,rows);checks=st.checks(case,snap)
            prefixes=[n for n in range(1,len(rows)+1) if st.replay(case,rows[:n])['records']!=snap['records'][:n]]
            repeats=[digest(snap),digest(st.replay(case,rows))]
            e['semantic_tests'].append({'case_id':case,'checks':checks,'status':'PASS' if all(checks.values()) and not prefixes and len(set(repeats))==1 else 'FAIL',
                'input_sha256':digest(rows),'snapshot_sha256':digest(snap),'prefix_count':len(rows),
                'prefix_failures':prefixes,'repeat_hashes':repeats,
                'released_inputs_on_failure':rows if not all(checks.values()) else None,
                'snapshot_on_failure':snap if not all(checks.values()) else None})
        matrix=load('phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json')['planned_execution_matrix']
        errata=load('phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json')
        selected={'ITQ-013','ITQ-014','ITQ-010','ITQ-012','ITQ-017','ITQ-019','ITQ-020','ITQ-021'}
        for entry in matrix:
            if entry['case_id'] not in selected:continue
            fixture=load(entry['input_path']);expectation=load(entry['expectation_path']);rows=fixture['observations']
            snap=replay(rows,profile,classifier)
            compared=compare_snapshot(snap,expectation,errata['all_case_interpretations'][entry['case_id']],fixture)
            if compared['status']=='INVALID_EXECUTION':raise RuntimeError(str(compared))
            with patch.object(blind,'run_candidate',replay):pref=blind.prefixes(rows,snap,profile,classifier)
            repeats=[digest(snap),digest(replay(rows,profile,classifier))]
            e['targeted_ITQ'].append({**entry,**compared,'actual_terminal':snap['state'],
                'snapshot_sha256':digest(snap),'prefix_causality':pref,'repeat_hashes':repeats,
                'snapshot_on_failure':snap if compared['status']!='PASS' else None})
        # Finish the explicitly requested diagnostic inventory even after ST fail.
        # No source repair, promotion, or new expectation is inferred from failures.
        with patch.object(historical_runner,'run_candidate',replay),patch.object(historical_runner.subprocess,'run',startup_adapter):
            h=historical_runner.historical(profile,classifier,protected)
        e['historical']={'startup':h['startup'],'C':{k:h['C'][k] for k in ('pass','fail','total','criteria','fresh_snapshot_hashes')},
            'S':{k:h['S'][k] for k in ('pass','fail','total','criteria','fresh_snapshot_hashes')},
            'P15':{k:h['P15'][k] for k in ('status','checks','class','prefix_count','repeat_sha256_10x')},'pass':h['pass']}
    except Exception as ex:
        e['integrity_error']=type(ex).__name__+':'+str(ex)
    e['environment_after']=historical_runner.environment()
    e['protected_hashes_after']={p:sha(ROOT/p) for p in protected}
    historical_runner.guard(protected)
    passed=(not e['integrity_error'] and len(e['semantic_tests'])==16 and all(x['status']=='PASS' for x in e['semantic_tests'])
            and len(e['targeted_ITQ'])==12 and all(x['status']=='PASS' and x['prefix_causality']['pass']
            and len(set(x['repeat_hashes']))==1 for x in e['targeted_ITQ']) and e['historical'].get('pass',False))
    e.update(R4_5C_GATE='WATCH_LIFECYCLE_DEVELOPMENT_VALIDATED' if passed else 'WATCH_LIFECYCLE_DEVELOPMENT_VALIDATION_FAILED',
        CANDIDATE_STATUS='DEVELOPMENT_VALIDATED_NOT_REQUALIFIED' if passed else 'DEVELOPMENT_VALIDATION_FAILED_NOT_REQUALIFIED',
        R4_3B_STATUS='NOT_QUALIFIED',CAN_PRODUCTION_PORT_START='NO',FULL_P_HISTORY_VALIDATION_AVAILABLE='NO',
        REAL_HARDWARE_TRACKING_CALIBRATION='CALIBRATION_REQUIRED',full_51_qualification_executed=False,
        phase6_started=False,git_commit_push=False)
    print('R45C_JSON_BEGIN')
    print(json.dumps(e,separators=(',',':')))


if __name__=='__main__':main()
