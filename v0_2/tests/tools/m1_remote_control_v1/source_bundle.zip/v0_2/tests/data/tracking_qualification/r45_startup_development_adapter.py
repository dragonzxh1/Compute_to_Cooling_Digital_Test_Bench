"""Explicit development-only candidate injection; frozen test bodies unedited."""
from v0_2.examples.phase5_r5_2_1r4_5_withdrawal_engine import WithdrawalCancellationTrackingQualifier


def pytest_collection_modifyitems(items):
    modules = {item.module for item in items}
    if len(items) != 50 or any(m.__name__ != 'v0_2.tests.control.test_phase5_r5_2_1r4_3_startup' for m in modules):
        raise RuntimeError('R45_STARTUP_ADAPTER_UNEXPECTED_COLLECTION')
    for module in modules:
        module.StartupTrackingQualifier = WithdrawalCancellationTrackingQualifier
    print('R45 DEVELOPMENT ADAPTER: all 50 unchanged Startup bodies use WithdrawalCancellationTrackingQualifier')
