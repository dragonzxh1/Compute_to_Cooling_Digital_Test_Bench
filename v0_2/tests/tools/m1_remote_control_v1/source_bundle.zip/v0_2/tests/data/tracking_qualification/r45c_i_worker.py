"""Future authorized stage worker. stdout is redirected to a local raw file."""
import argparse
import json
from dataclasses import asdict
from pathlib import Path


def execute(kind, case=None, data=None):
    # Lazy imports: static parser/persistence self-checks never import a candidate.
    from . import run_r45c_g_frozen_development as old
    from . import run_r45c_development as development
    from v0_2.tests.control import test_phase5_r5_2_1r4_5c_lifecycle as st
    replay = lambda rows: development.replay(rows, st.PROFILE, st.CLASSIFIER)
    if kind == 'U':
        rows = old.load(old.U_PATH)['input']['observations']
        snap = replay(rows)
        return {'inputs':rows, 'snapshot':snap, 'checks':old.u_checks(snap), 'replay_kind':'generic'}
    if kind == 'ST':
        rows = st.inputs(case)
        snap = st.replay(case, rows)
        if case == 'ST-12':
            # Link v2 State U assertion to the actual fresh, persisted U stage,
            # never a manufactured True or a previous-run observation.
            u = json.loads(Path(data).read_bytes())
            checks = old.v2_checks(snap, u['checks'])
        else:
            checks = st.checks(case, snap)
        return {'case_id':case, 'inputs':rows, 'snapshot':snap, 'checks':checks, 'replay_kind':case}
    if kind == 'ITQ':
        from .itq_execution_spec_v101 import compare_snapshot
        entry = json.loads(Path(data).read_bytes())
        fixture, expected = old.load(entry['input_path']), old.load(entry['expectation_path'])
        errata = old.load('phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json')
        snap = replay(fixture['observations'])
        comparison = compare_snapshot(snap, expected, errata['all_case_interpretations'][entry['case_id']], fixture)
        return {'inputs':fixture['observations'], 'snapshot':snap, 'comparison':comparison,
                'checks':{'frozen_comparator':comparison['status']=='PASS'}, 'replay_kind':'generic',
                'status':'INVALID' if comparison['status']=='INVALID_EXECUTION' else 'OBSERVED'}
    if kind in ('C','S'):
        from v0_2.examples import phase5_r5_2_1r1_validation as r1
        from v0_2.examples.phase5_r5_2_1r4_3_history_validation import c_acceptance, s_acceptance
        from v0_2.examples.phase5_r5_2_1r_validation import build_cases, R52_EVIDENCE, R522_EVIDENCE
        cases = ({k:v for k,v in r1.cases(st.PROFILE).items() if k!='C9'} if kind=='C' else
            build_cases(st.PROFILE, json.loads(R52_EVIDENCE.read_bytes()), json.loads(R522_EVIDENCE.read_bytes())))
        inputs = {k:[asdict(x) for x in v] for k,v in cases.items()}
        snapshots = {k:replay(rows) for k,rows in inputs.items()}
        checks = (c_acceptance if kind=='C' else s_acceptance)(snapshots)
        checks['exact_inventory'] = len(checks)==(11 if kind=='C' else 17)
        return {'cases':{k:{'inputs':inputs[k], 'snapshot':snapshots[k], 'replay_kind':'generic'} for k in inputs},
                'checks':checks}
    if kind == 'P15':
        freeze = old.load('phase5_r5_2_1_p15_reconstructed_history_freeze.json')
        rows = old.load(freeze['input_path'])['observations']
        snap = replay(rows)
        starts = [x for x in snap['epoch_events'] if x['event']=='START']
        anchors = snap['resolved_pair_events']
        progress = [r for r in snap['records'] if r['qualified_progress']]
        checks = {
            'exact_epoch_starts':[x['time_ns'] for x in starts]==[600000000,3400000000],
            'exact_directions':[x['expected_direction'] for x in starts]==[1,1],
            'exact_anchors':[x['new']['resolved_command_anchor'] for x in anchors]==[.35,.51,.67],
            'initial_anchor_direct':bool(anchors) and anchors[0]['reason']=='DIRECTLY_OBSERVED_INITIAL_STEADY_BASELINE',
            'stage_progress':len(starts)==2 and len(anchors)==3 and all(any(
                starts[i]['time_ns']<r['time_ns']<=anchors[i+1]['time_ns'] for r in progress) for i in range(2)),
            'resolved_after_trigger':len(starts)==2 and len(anchors)==3 and all(
                anchors[i+1]['time_ns']>starts[i]['time_ns'] for i in range(2)),
            'anchor_epoch_provenance':[x['new']['source_epoch_id'] for x in anchors[1:]]==[x['epoch_id'] for x in starts],
            'final_steady':snap['state']=='STEADY_TRACKING',
            'no_fault':not snap['confirmed_latched'] and all(r['state']!='TRACKING_FAULT_CONFIRMED' for r in snap['records'])}
        return {'inputs':rows, 'snapshot':snap, 'checks':checks, 'replay_kind':'generic', 'repeat_count':10}
    if kind == 'PREFIX_REPEAT':
        source = json.loads(Path(data).read_bytes())
        cases = source.get('cases', {'one':source})
        results = {}
        for name, c in cases.items():
            run = replay if c['replay_kind']=='generic' else (lambda rows, k=c['replay_kind']:st.replay(k,rows))
            rows, snap = c['inputs'], c['snapshot']
            prefixes = [n for n in range(1,len(rows)+1) if run(rows[:n])['records']!=snap['records'][:n]]
            hashes = [old.digest(snap)] + [old.digest(run(rows)) for _ in range(c.get('repeat_count',2)-1)]
            results[name] = {'prefix_count':len(rows), 'prefix_failures':prefixes, 'repeat_hashes':hashes}
        return {'cases':results, 'checks':{k:not v['prefix_failures'] and len(set(v['repeat_hashes']))==1 for k,v in results.items()}}
    raise ValueError('Unknown stage kind')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', required=True)
    parser.add_argument('--case')
    parser.add_argument('--data')
    parser.add_argument('--authorization', required=True)
    args = parser.parse_args()
    from .r45c_i_runner import validate_authorization
    validate_authorization(Path(args.authorization))
    print(json.dumps(execute(args.kind,args.case,args.data), sort_keys=True, separators=(',',':'),
                     ensure_ascii=False,allow_nan=False))


if __name__ == '__main__':
    main()
