"""R4.5 narrow development validation; never final qualification or blind discovery."""
import ast
import difflib
import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch
from . import run_itq_blind as blind
from . import run_r44a2_r4 as r4
from .run_r44a2_r2 import immutable
from .verify_execution_baseline_v101 import check
from .itq_execution_spec_v101 import compare_snapshot
from .verify_itq_preregistration import sha

ROOT, load, save, now, digest = r4.ROOT, r4.load, r4.save, r4.now, r4.digest
EVIDENCE = ROOT / 'phase5_r5_2_1r4_5_withdrawal_cancellation_evidence.json'
REPORT = ROOT / 'PHASE5_R5_2_1R4_5_WITHDRAWAL_CANCELLATION_CORRECTION_REPORT.md'
ENGINE = 'v0_2/examples/phase5_r5_2_1r4_5_withdrawal_engine.py'
REG = 'phase5_r5_2_1r4_5_withdrawal_cancellation_registration.json'
FREEZE = 'phase5_r5_2_1r4_5_registration_freeze.json'
TEST = 'v0_2/tests/control/test_phase5_r5_2_1r4_5_withdrawal.py'
ADAPTER = 'v0_2/tests/data/tracking_qualification/r45_startup_development_adapter.py'
REAL_SUBPROCESS_RUN = subprocess.run


def replay(rows, profile, classifier):
    from v0_2.examples.phase5_r5_2_1r4_5_withdrawal_engine import WithdrawalCancellationTrackingQualifier
    from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation
    q = WithdrawalCancellationTrackingQualifier(profile, classifier)
    for row in rows:
        q.update(ReleasedObservation(**row))
    return q.snapshot()


def startup_adapter(args, **kwargs):
    # Explicit development injection into collected test module globals ONLY.
    # No old candidate module binding or frozen test source is changed.
    assert args[:3] == [sys.executable, '-m', 'pytest']
    return REAL_SUBPROCESS_RUN(args + ['-p',
        'v0_2.tests.data.tracking_qualification.r45_startup_development_adapter'], **kwargs)


def render(e):
    text = ['# R4.5：撤回需求前无故障证据的 watch 取消修正', '',
        '## 当前结论', '', f"R4_5_GATE = {e['R4_5_GATE']}",
        f"R4_5_CANDIDATE_QUALIFICATION_STATUS = {e['R4_5_CANDIDATE_QUALIFICATION_STATUS']}", '',
        '本阶段仅开发修复确认，不是 independent qualification PASS，不是全套 frozen ITQ 重新资格。', '',
        '## 权威失败与根因', '',
        'R4 有效执行正式 FAIL：ITQ-013 command=measurement=0.5 VALID、gross=0、evidence=0，却无 CANCEL、终态 HANDOFF_PENDING。原 R4.3B 源码与全部失败证据保持原字节；其 FAILED_INDEPENDENT_TRACKING_QUALIFICATION 身份永久保留。',
        '原 Startup.update 第 76 行仅在 resolved_pair is None 时运行取消分支；该案例在 0 s 已建立 baseline。因此 paired evaluator 仍留着 epoch/watch，零 expected motion 落入 pending。', '',
        '## 编辑前冻结', '',
        f"registration canonical SHA-256：{e['registration_canonical_sha256']}。",
        f"登记冻结时间：{e['registration_frozen_utc']}；候选文件编辑后、首次开发验证前审计：{e['candidate_edit_completed_before_validation_utc']}；验证开始：{e['development_validation_started_utc']}。",
        'registration_freeze 文件证明冻结时新 candidate 尚不存在；原 source/hash 和 R4 evidence hash 已先核验。', '',
        '## 旧/新取消规则与最小性', '',
        '旧规则：只有 baseline 尚未建立的 startup 分支可取消；已建立 baseline 的撤回遗漏。',
        '新规则：增加独立 subclass.update 前置处理，仅限 established baseline、有效非恢复样本、active watch/epoch、无证据/怀疑/确认、未获 qualified progress、旧 material demand 撤回成 non-material、测量仍在原 anchor 的既有 minimum_motion 内。',
        '不满足前置条件直接走原实现；特别是有证据/怀疑的撤回、部分撤回、sensor invalid/recovery、方向反转、已获进展等路径不改。没有增加阈值或计时器。',
        '合法取消使用已有 CLOSE/CANCEL 诊断事件，清除 obsolete epoch/watch age/checkpoint/direction，保留原 resolved pair 和事件历史，再由原 evaluator 正常计算公开状态；不是强制输出 STEADY。',
        f"新增 candidate 模块 {ENGINE}；仅一个 update override，{e['candidate_source_lines']} 行（含文档、imports）；原运行时文件修改 0 行。支持文件为 WCDEV 测试、显式 Startup 开发适配器、开发 runner、登记和报告证据。",
        '继承增量的完整源 diff 在机器 evidence.source_diff；原实现不复制、不覆盖。', '',
        '## WCDEV', '', '| Case | Result |', '| :--- | :--- |']
    text += [f"| {x['case_id']} | {x['status']} |" for x in e['WCDEV_results']]
    text += ['', '## 指定冻结 ITQ 开发回归', '',
        '| Case | dt (s) | Result | Errors |', '| :--- | ---: | :--- | :--- |']
    text += [f"| {x['case_id']} | {x['physics_dt_ns']/1e9:g} | {x['status']} | {x['errors']} |" for x in e['targeted_ITQ_results']]
    text += ['', 'ITQ-013 的完整 snapshot/watch CANCEL、保留 resolved anchors 与无假进展检查见 WCDEV-01/05。ITQ-014 按未修改 comparator 判定；WCDEV-02 独立验证撤回前实际故障证据确实非零、撤回后未减且 watch 未被取消。', '',
        '## 历史开发回归', '']
    h = e.get('historical', {})
    for n in ('startup', 'C', 'S'):
        text.append(f"{n}：{h.get(n, {}).get('pass', 'NOT_RUN')}/{h.get(n, {}).get('total', '—')} PASS。")
    text += [f"P15：{h.get('P15', {}).get('status', 'NOT_RUN')}，原冻结重建历史分类/normativity 不改；全前缀及 10 repeats。",
        'Startup 原 50 测试函数源码不改：explicit pytest plugin 在 collection 后把该测试模块的 class global 指向新 candidate。每个原测试体实际执行新候选，不把旧候选成绩当新候选成绩。C/S/P15 用原 acceptance 与新 candidate replay；开发 runner 的 in-memory replay adapter 不写任何旧源文件。', '',
        '## Prefix、重复、测量权限', '',
        f"WCDEV 全前缀 {e.get('WCDEV_prefix_count', 0)}；指定 ITQ 原计划前缀 {e.get('targeted_prefix_count', 0)}。每项 2 次 canonical snapshot hash；完整输入和检查原始结果在机器 evidence。",
        '原 approved comparator/方向映射/时间规则不改；所有继承模块加新 candidate 做 released-only AST 审计，没有 TRUE/ACTUAL/future/flow/DP 权限。', '',
        '## 身份、审计与限制', '',
        f"旧 R4.3B hash：{e['old_candidate_sha256']}。",
        f"新 R4.5 增量源码 hash：{e['new_candidate_sha256']}。",
        f"新候选传递依赖身份 hash：{e['new_candidate_dependency_identity_sha256']}。",
        f"环境前后 hash：{e['environment_before']['hash']} / {e.get('environment_after', {}).get('hash')}。",
        f"受保护原文件 before/after：{len(e['protected_hashes_before'])} 个；完整审计 error={e.get('integrity_error')}。",
        '原 23 cases/51 variants inputs/expectations、comparator、errata、Contract15A、profile、生产 Safety/controller/plant/measurement/actuator、旧历史测试、R4 原证据均未改；另留 explicit frozen_ITQ before/after map。',
        '本阶段只跑指定 8 个 ITQ 案例的原变体，不运行全 51 final qualification。修复针对已知证据，不称下一轮 blind discovery。',
        'FULL_P_HISTORY_VALIDATION_AVAILABLE=NO；真实硬件 CALIBRATION_REQUIRED；CAN_PRODUCTION_PORT_START=NO；Phase 6 未开始；git commit/push=NO；DSX/Twin 未动。', '',
        '## NEXT ACTION', '',
        '通过时仅建议用户审阅后进入 R4.6 FROZEN ITQ POST-REPAIR REQUALIFICATION：同一 R3 环境，从 ITQ-001 跑完整 51+prefix/repeat/dt+Startup/C/S/P15，运行期间候选不改。若本阶段失败则先审阅窄修复不足，不自动扩大。',
        'STOP，等待用户审阅。']
    REPORT.write_text('\n'.join(text) + '\n', encoding='utf-8')


def main():
    if EVIDENCE.exists() or REPORT.exists():
        raise RuntimeError('R45_OUTPUT_EXISTS_DO_NOT_OVERWRITE')
    reg, freeze = load(REG), load(FREEZE)
    protected = dict(freeze['protected_hashes_before'])
    for p in [REG, FREEZE, ENGINE, TEST, ADAPTER, Path(__file__).relative_to(ROOT).as_posix(),
        'phase5_r5_2_1r4_4a2_r4_full_blind_qualification_evidence.json',
        'PHASE5_R5_2_1R4_4A2_R4_FULL_BLIND_QUALIFICATION_REPORT.md',
        'phase5_r5_2_1r4_4a2_r4_itq013_forensic_addendum.json']:
        protected[p] = sha(ROOT / p)
    assert digest(reg) == freeze['registration_canonical_sha256']
    assert sha(ROOT / REG) == freeze['registration_file_sha256']
    immutable(protected)
    baseline = check()
    env = r4.environment()
    candidate_source = (ROOT / ENGINE).read_text(encoding='utf-8')
    tree = ast.parse(candidate_source)
    assert [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)] == ['update']
    authority = r4.helpers.audit_authority()
    forbidden = {'actual_speed', 'true_speed', 'raw_speed', 'future_measurement', 'measured_flow_kg_s', 'measured_dp_pa'}
    hits = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Attribute) and n.attr in forbidden]
    assert not hits and authority['status'] == 'PASS'
    dependencies = {p: protected[p] for p in authority['paths'] + [ENGINE]}
    e = {**freeze, 'protected_hashes_before': protected, 'baseline_verification': baseline,
        'candidate_identity': reg['candidate_identity'], 'failed_parent_status': reg['failed_parent_status'],
        'old_candidate_sha256': reg['failed_parent_sha256'], 'new_candidate_sha256': sha(ROOT / ENGINE),
        'new_candidate_dependency_hashes': dependencies, 'new_candidate_dependency_identity_sha256': digest(dependencies),
        'source_diff': ''.join(difflib.unified_diff([], candidate_source.splitlines(keepends=True), fromfile='/dev/null', tofile=ENGINE)),
        'candidate_source_lines': len(candidate_source.splitlines()),
        'candidate_edit_completed_before_validation_utc': now(), 'environment_before': env,
        'measurement_authority': {**authority, 'new_candidate_forbidden_hits': hits},
        'WCDEV_results': [], 'targeted_ITQ_results': [], 'integrity_error': None,
        'evidence_classification': 'DEVELOPMENT_REPAIR_CONFIRMATION', 'full_51_final_qualification_executed': False}
    m = load('phase5_r5_2_1r4_4a1_rerun_candidate_manifest.json')
    fixture_paths = sorted({x[k] for x in m['planned_execution_matrix'] for k in ('input_path', 'expectation_path')})
    e['frozen_ITQ_hashes_before'] = {p: sha(ROOT / p) for p in fixture_paths}
    profile = load('phase5_r5_2_2_fixture_tracking_profile.json')
    classifier = load('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    e['development_validation_started_utc'] = now()
    try:
        from v0_2.tests.control import test_phase5_r5_2_1r4_5_withdrawal as dev
        for name, rows in dev.cases().items():
            r4.guard(protected)
            snapshot = replay(rows, profile, classifier)
            checks = dev.checks(name, snapshot)
            pref = [n for n in range(1, len(rows)+1) if replay(rows[:n], profile, classifier)['records'] != snapshot['records'][:n]]
            repeats = [digest(snapshot), digest(replay(rows, profile, classifier))]
            result = {'case_id': name, 'released_inputs': rows, 'snapshot': snapshot, 'checks': checks,
                'prefix_count': len(rows), 'prefix_failures': pref, 'repeat_sha256_2x': repeats,
                'status': 'PASS' if all(checks.values()) and not pref and len(set(repeats)) == 1 else 'FAIL'}
            e['WCDEV_results'].append(result)
            print(name + ': ' + result['status'], flush=True)
        pytest_dev = REAL_SUBPROCESS_RUN([sys.executable, '-m', 'pytest', '-q', TEST], cwd=ROOT, text=True, capture_output=True)
        e['WCDEV_pytest'] = {'returncode': pytest_dev.returncode, 'stdout': pytest_dev.stdout, 'stderr': pytest_dev.stderr}
        errata = load('phase5_r5_2_1r4_4a1_itq_execution_spec_errata.json')
        for entry in m['planned_execution_matrix']:
            if entry['case_id'] not in reg['targeted_frozen_ITQ_cases']:
                continue
            r4.guard(protected)
            fixture, expected = load(entry['input_path']), load(entry['expectation_path'])
            rows = fixture['observations']
            snapshot = replay(rows, profile, classifier)
            comparison = compare_snapshot(snapshot, expected, errata['all_case_interpretations'][entry['case_id']], fixture)
            if comparison['status'] == 'INVALID_EXECUTION':
                raise RuntimeError('COMPARATOR_INTEGRITY:' + str(comparison))
            with patch.object(blind, 'run_candidate', replay):
                pref = blind.prefixes(rows, snapshot, profile, classifier)
            repeats = [digest(snapshot), digest(replay(rows, profile, classifier))]
            errors = list(comparison['errors'])
            if not pref['pass']: errors.append('PREFIX_CAUSALITY')
            if len(set(repeats)) != 1: errors.append('NONDETERMINISM')
            result = {**entry, 'status': 'FAIL' if errors else 'PASS', 'errors': errors,
                'snapshot': snapshot, 'released_inputs': rows, 'prefix_causality': pref,
                'repeat_sha256_2x': repeats, 'classification': 'DEVELOPMENT_REPAIR_CONFIRMATION'}
            e['targeted_ITQ_results'].append(result)
            print(entry['case_id'] + ' dt=' + str(entry['physics_dt_ns']) + ': ' + result['status'], flush=True)
        with patch.object(r4, 'run_candidate', replay), patch.object(r4.subprocess, 'run', startup_adapter):
            e['historical'] = r4.historical(profile, classifier, protected)
        r4.guard(protected)
    except Exception as ex:
        e['integrity_error'] = type(ex).__name__ + ':' + str(ex)
    e['environment_after'] = r4.environment()
    e['protected_hashes_after'] = {p: sha(ROOT / p) for p in protected}
    immutable(protected)
    e['frozen_ITQ_hashes_after'] = {p: sha(ROOT / p) for p in fixture_paths}
    e['WCDEV_prefix_count'] = sum(x['prefix_count'] for x in e['WCDEV_results'])
    e['targeted_prefix_count'] = sum(len(x['prefix_causality']['checked_prefix_lengths']) for x in e['targeted_ITQ_results'])
    okay = (not e['integrity_error'] and len(e['WCDEV_results']) == 5 and all(x['status'] == 'PASS' for x in e['WCDEV_results'])
        and e.get('WCDEV_pytest', {}).get('returncode') == 0 and len(e['targeted_ITQ_results']) == 12
        and all(x['status'] == 'PASS' for x in e['targeted_ITQ_results']) and e.get('historical', {}).get('pass'))
    e.update(R4_5_GATE='WITHDRAWAL_BEFORE_EVIDENCE_CANCELLATION_CORRECTED' if okay else 'R4_5_NARROW_FIX_INSUFFICIENT',
        R4_5_CANDIDATE_QUALIFICATION_STATUS='DEVELOPMENT_VALIDATED_NOT_REQUALIFIED' if okay else 'DEVELOPMENT_VALIDATION_FAILED_NOT_REQUALIFIED',
        CAN_PRODUCTION_PORT_START='NO', FULL_P_HISTORY_VALIDATION_AVAILABLE='NO',
        REAL_HARDWARE_TRACKING_CALIBRATION='CALIBRATION_REQUIRED', phase6_started=False, git_commit_push=False, end_utc=now())
    save(EVIDENCE, e)
    render(e)
    print(json.dumps({'gate': e['R4_5_GATE'], 'integrity_error': e['integrity_error'],
        'WCDEV': [x['status'] for x in e['WCDEV_results']], 'targeted_variants': len(e['targeted_ITQ_results']),
        'targeted_failures': [x['case_id'] for x in e['targeted_ITQ_results'] if x['status'] != 'PASS'],
        'history_pass': e.get('historical', {}).get('pass')}), flush=True)


if __name__ == '__main__':
    main()
