"""R4.4A freeze, then read-only blind qualification of the unchanged R4.3B engine.

This runner is written before freeze. It never rewrites R4.4 inputs or expected
results. Failure is recorded and the remaining cases continue when integrity
permits. Usage: python -m ...run_itq_blind freeze|run
"""

from __future__ import annotations

import ast
import hashlib
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

from .verify_itq_preregistration import ROOT, canonical, sha, verify

HERE = Path(__file__).resolve().parent
PREREG = ROOT / "phase5_r5_2_1r4_4_itq_preregistration.json"
FREEZE = ROOT / "phase5_r5_2_1r4_4a_itq_freeze_manifest.json"
EVIDENCE = ROOT / "phase5_r5_2_1r4_4a_itq_blind_execution_evidence.json"
REPORT = ROOT / "PHASE5_R5_2_1R4_4A_ITQ_FREEZE_AND_BLIND_EXECUTION_REPORT.md"
EXPECTED_HASH = "1aa88da29b09cfd18ea16b80fbe0c8ef886391f4246457f96782f198f18ef560"
PUBLIC_STATES = {"STEADY_TRACKING", "HANDOFF_PENDING", "TRACKING_PROGRESS", "TRACKING_FAULT_SUSPECTED",
                 "TRACKING_FAULT_CONFIRMED", "INSUFFICIENT_MEASUREMENT"}
SAFETY = {"STEADY_TRACKING":"NORMAL", "HANDOFF_PENDING":"NORMAL", "TRACKING_PROGRESS":"NORMAL",
          "TRACKING_FAULT_SUSPECTED":"DEGRADED", "TRACKING_FAULT_CONFIRMED":"FAULT",
          "INSUFFICIENT_MEASUREMENT":"NORMAL"}
SEVERITY = {"NORMAL":0,"DEGRADED":1,"FAULT":2}


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.write_bytes(canonical(value)+b"\n")


def git(*args):
    result = subprocess.run(["git", *args], cwd=ROOT, text=True, capture_output=True, check=True)
    return result.stdout.strip()


def manifest():
    check=verify()
    item=json.loads(PREREG.read_text(encoding="utf-8"))
    if check["aggregate_sha256"]!=EXPECTED_HASH:
        raise RuntimeError("R4_4A_BLOCKED_BY_PREREGISTRATION_HASH_MISMATCH")
    ids=[f"ITQ-{i:03d}" for i in range(1,24)]
    if [c["case_id"] for c in item["cases"]]!=ids or check["fixture_count"]!=51:
        raise RuntimeError("R4_4A_BLOCKED_BY_SUITE_INVENTORY_MISMATCH")
    engine_path="v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py"
    # The startup engine is the R4.3B candidate. The earlier semantic engine is
    # a frozen dependency, not a substitute candidate.
    assert sha(ROOT/engine_path)=="52b4ddd46401c16793a3602f49f02a5e9ca78906178390f9934c3453ed7b065e"
    return item


def freeze():
    item=manifest()
    if FREEZE.exists():
        raise RuntimeError("FREEZE_MANIFEST_ALREADY_EXISTS; never overwrite a frozen run")
    timing={c["case_id"]:hashlib.sha256(canonical({
        "milestones":json.loads((ROOT/c["expected_path"]).read_text(encoding="utf-8"))["expected_public_state_milestones"],
        "rules":json.loads((ROOT/c["expected_path"]).read_text(encoding="utf-8"))["timing_rules"],
        "terminal":json.loads((ROOT/c["expected_path"]).read_text(encoding="utf-8"))["terminal_timing_normativity"]
    })).hexdigest() for c in item["cases"]}
    watched={**{p:v["before"] for p,v in item["source_hashes_before_after"].items()},
             "v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py":sha(ROOT/"v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py"),
             "v0_2/examples/phase5_r5_2_1r4_2_directional_engine.py":sha(ROOT/"v0_2/examples/phase5_r5_2_1r4_2_directional_engine.py"),
             "v0_2/examples/phase5_r5_2_1r4_1_deferred_engine.py":sha(ROOT/"v0_2/examples/phase5_r5_2_1r4_1_deferred_engine.py")}
    # The frozen manifest records the complete pre-run status; unrelated
    # untracked DSX/Twin work is never touched.
    result={"schema":"phase5-r5-2-1r4-4a-itq-freeze-v1", "suite_version":item["ITQ_SUITE_VERSION"],
            "freeze_status":"FROZEN_FOR_BLIND_QUALIFICATION", "freeze_timestamp_utc":utc_now(),
            "case_count":23,"variant_count":51,"aggregate_preregistration_hash":EXPECTED_HASH,
            "preregistration_file_sha256":sha(PREREG),
            "fixtures":{c["case_id"]:[{"path":v["input_path"],"sha256":v["input_sha256"],"physics_dt_ns":v["physics_dt_ns"]} for v in c["fixture_variants"]] for c in item["cases"]},
            "expectations":{c["case_id"]:{"path":c["expected_path"],"sha256":c["expectation_sha256"]} for c in item["cases"]},
            "timing_normativity_sha256":timing,"tracking_profile_sha256":item["tracking_profile_sha256"],
            "Contract15A_sha256":item["Contract15A_sha256"],"candidate_R4_3B_engine_sha256":watched["v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py"],
            "protected_source_sha256":watched,"runner_sha256":sha(Path(__file__)),
            "planned_execution_matrix":item["planned_execution_matrix"],
            "planned_prefix_checks":item["planned_execution_matrix"]["prefixes"],
            "planned_determinism_checks":item["planned_execution_matrix"]["repeats"],
            "git_HEAD":git("rev-parse","HEAD"),"working_tree_status_before_execution":git("status","--porcelain=v1","-uall"),
            "historical_distinction":"NEW_ITQ_NOT_RECOVERED_P1_P20", "FULL_P_HISTORY_VALIDATION_AVAILABLE":"NO",
            "candidate_executed_before_freeze":False}
    save(FREEZE,result)
    print(json.dumps({"freeze_status":result["freeze_status"],"freeze_manifest_sha256":sha(FREEZE),
                      "aggregate_preregistration_hash":EXPECTED_HASH,"freeze_timestamp_utc":result["freeze_timestamp_utc"]}))


def check_frozen():
    item=manifest()
    frozen=json.loads(FREEZE.read_text(encoding="utf-8"))
    if frozen["freeze_status"]!="FROZEN_FOR_BLIND_QUALIFICATION" or frozen["aggregate_preregistration_hash"]!=EXPECTED_HASH:
        raise RuntimeError("BLIND_QUALIFICATION_INTEGRITY_FAILURE")
    if frozen["preregistration_file_sha256"]!=sha(PREREG) or frozen["runner_sha256"]!=sha(Path(__file__)):
        raise RuntimeError("BLIND_QUALIFICATION_INTEGRITY_FAILURE")
    for path,value in frozen["protected_source_sha256"].items():
        if sha(ROOT/path)!=value:
            raise RuntimeError(f"R4_4A_CANDIDATE_CHANGED_DURING_BLIND_RUN: {path}")
    for c in item["cases"]:
        f=frozen["fixtures"][c["case_id"]]
        if len(f)!=len(c["fixture_variants"]) or any(sha(ROOT/v["path"])!=v["sha256"] for v in f):
            raise RuntimeError("BLIND_QUALIFICATION_INTEGRITY_FAILURE: fixture")
        e=frozen["expectations"][c["case_id"]]
        if sha(ROOT/e["path"])!=e["sha256"]:
            raise RuntimeError("BLIND_QUALIFICATION_INTEGRITY_FAILURE: expectation")
    return item,frozen


def run_candidate(rows, profile, classifier):
    # First candidate import/call occurs only after final freeze was written.
    from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation
    from v0_2.examples.phase5_r5_2_1r4_3_startup_engine import StartupTrackingQualifier
    q=StartupTrackingQualifier(profile,classifier)
    for row in rows:
        q.update(ReleasedObservation(**row))
    return q.snapshot()


def safety_audit(snapshot, expected):
    states=[r["state"] for r in snapshot["records"]]
    if any(s not in PUBLIC_STATES for s in states):
        return ["UNKNOWN_PUBLIC_STATE"]
    contributions=[SAFETY[s] for s in states]
    errors=[]
    highest=max(contributions,key=SEVERITY.get)
    if highest!=expected["safety"]["highest"]:
        errors.append(f"HIGHEST_SAFETY:{highest}!={expected['safety']['highest']}")
    if any(s in expected["safety"]["forbidden"] for s in contributions):
        errors.append("FORBIDDEN_SAFETY_SEVERITY")
    if any(s not in expected["safety"]["allowed_intermediate"]+[expected["safety"]["highest"]] for s in contributions):
        errors.append("UNLISTED_SAFETY_SEVERITY")
    if expected["safety"]["confirmed_fault_latched"] and snapshot["confirmed_latched"] is not True:
        errors.append("FAULT_NOT_LATCHED")
    return errors


def compare(snapshot, expected, rows):
    records=snapshot["records"]
    errors=[]
    positions=[]
    cursor=0
    for milestone in expected["expected_public_state_milestones"]:
        if milestone["state"]=="FIRST_VALID_RECOVERY_MEASUREMENT":
            t=milestone["time_ns"]
            row=next((r for r in rows if r["time_ns"]==t),None)
            if row is None or row["quality"]!="VALID":
                errors.append(f"EXACT_RECOVERY_RELEASE_MISMATCH:{t}")
            continue
        found=next((i for i in range(cursor,len(records)) if records[i]["state"]==milestone["state"]),None)
        if found is None:
            errors.append(f"MILESTONE_MISSING_OR_OUT_OF_ORDER:{milestone['state']}")
            continue
        positions.append(found)
        if milestone["timing_normativity"]=="EXACT_NORMATIVE" and "time_ns" in milestone and records[found]["time_ns"]!=milestone["time_ns"]:
            errors.append(f"EXACT_MILESTONE_TIME:{milestone['state']}:{records[found]['time_ns']}!={milestone['time_ns']}")
        cursor=found+1
    terminal=records[-1]["state"]
    if terminal!=expected["expected_terminal_state"]:
        errors.append(f"TERMINAL:{terminal}!={expected['expected_terminal_state']}")
    if expected["fault_expected"] and not any(r["state"]=="TRACKING_FAULT_CONFIRMED" for r in records):
        errors.append("FALSE_NEGATIVE_TRACKING_FAULT")
    if not expected["fault_expected"] and any(r["state"]=="TRACKING_FAULT_CONFIRMED" for r in records):
        errors.append("FALSE_POSITIVE_TRACKING_FAULT")
    if any(r["quality"]!="VALID" and rec["state"]!="INSUFFICIENT_MEASUREMENT" for r,rec in zip(rows,records)):
        errors.append("INVALID_MEASUREMENT_EARNED_TRACKING_STATE")
    guard=expected.get("same_sample_reissue_guard")
    if guard:
        at=next((r for r in records if r["time_ns"]==guard["time_ns"]),None)
        if at is not None and at["state"]=="TRACKING_FAULT_CONFIRMED":
            errors.append("SAME_SAMPLE_STALE_CONFIRMATION")
    if "DIRECTION_LOCK" in expected["forbidden_outcomes"] or "PERMANENT_HANDOFF_PENDING" in expected["forbidden_outcomes"]:
        if terminal=="HANDOFF_PENDING":
            errors.append("DIRECTION_LOCK_OR_PENDING_TRAP")
    if expected["expected_direction_behavior"]=="SUPERSEDE_TO_CURRENT_NEGATIVE_NET_DEMAND":
        outage_end=next((m[1] for m in json.loads((ROOT/"v0_2/tests/data/tracking_qualification"/f"{expected['case_id']}_dt0p2_input.json").read_text())["measurement_timeline"]["invalid_windows_ns"]),None)
        after=[r for r in records if outage_end is not None and r["time_ns"]>=outage_end and r["valid"]]
        if not after or not any(r["expected_direction"]==-1 for r in after):
            errors.append("DIRECTION_NOT_SUPERSEDED_ON_RECOVERY")
    if expected["expected_watch_behavior"]=="PRESERVE_OLDEST_UNRESOLVED":
        starts=[e["watch_start_ns"] for e in snapshot["watch_events"] if e["event"]=="START"]
        carried=[e["watch_start_ns"] for e in snapshot["watch_events"] if e.get("event")=="CARRY_ACROSS_REVERSAL"]
        if len(starts)>1 or (starts and any(x!=starts[0] for x in carried)):
            errors.append("WATCH_AGE_ERASURE")
    errors.extend(safety_audit(snapshot,expected))
    for outcome in expected["forbidden_outcomes"]:
        if outcome in PUBLIC_STATES and any(r["state"]==outcome for r in records):
            errors.append(f"FORBIDDEN_PUBLIC_STATE:{outcome}")
    return list(dict.fromkeys(errors))


def prefixes(rows,snapshot,profile,classifier):
    keys={len(rows)}
    previous=None
    previous_valid=True
    for i,(row,record) in enumerate(zip(rows,snapshot["records"])):
        valid=row["quality"]=="VALID"
        if previous is None or row["plc_command"]!=previous or valid!=previous_valid or record["state"]=="TRACKING_PROGRESS" or record["state"]=="TRACKING_FAULT_CONFIRMED":
            keys.add(i+1)
        previous=row["plc_command"]
        previous_valid=valid
    failures=[]
    for n in sorted(keys):
        partial=run_candidate(rows[:n],profile,classifier)
        if partial["records"]!=snapshot["records"][:n]:
            failures.append({"prefix_length":n,"last_time_ns":rows[n-1]["time_ns"]})
    return {"checked_prefix_lengths":sorted(keys),"failures":failures,"pass":not failures}


def forensic(errors, snapshot, expected, rows):
    records=snapshot["records"]
    failure=errors[0] if errors else None
    idx=next((i for i,r in enumerate(records) if r["state"]=="TRACKING_FAULT_CONFIRMED"),len(records)-1)
    if failure and failure.startswith("EXACT_MILESTONE_TIME"):
        idx=next((i for i,r in enumerate(records) if r["state"]=="TRACKING_PROGRESS"),idx)
    if failure and failure.startswith("MILESTONE_MISSING"):
        idx=len(records)-1
    row=rows[idx]; record=records[idx]
    return {"first_divergence_label":failure,"first_divergence_time_ns":row["time_ns"],
            "input_prefix":rows[:idx+1],"expected_state_or_event":expected["expected_public_state_milestones"],
            "actual_state":record["state"],"command":row["plc_command"],"released_measurement":row["measured_speed"],
            "measurement_validity":row["quality"],"directional_obligation":record.get("expected_direction"),
            "watch_evidence":{"watch_id":record.get("watch_id"),"watch_start_ns":record.get("watch_start_ns"),
                              "carried_suspicion_evidence":record.get("carried_suspicion_evidence")},
            "anchor_checkpoint":{"resolved_pair":snapshot.get("resolved_pair"),"progress_pair":snapshot.get("progress_pair")},
            "safety_contribution":SAFETY.get(record["state"])}


def authority_audit():
    paths=[ROOT/"v0_2/examples/phase5_r5_2_1r_semantic_engine.py",
           ROOT/"v0_2/examples/phase5_r5_2_1r4_1_deferred_engine.py",
           ROOT/"v0_2/examples/phase5_r5_2_1r4_2_directional_engine.py",
           ROOT/"v0_2/examples/phase5_r5_2_1r4_3_startup_engine.py"]
    forbidden={"actual_speed","true_speed","raw_speed","measured_flow_kg_s","measured_dp_pa","future_measurement"}
    hits=[]
    for path in paths:
        tree=ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node,ast.Attribute) and node.attr in forbidden:
                hits.append(f"{path.relative_to(ROOT)}:{node.lineno}:{node.attr}")
    return {"forbidden_attribute_access":hits,"pass":not hits,
            "input_fields":["time_ns","plc_command","command_timestamp_ns","measured_speed","sample_ns","release_ns","quality","measurement_record_id"]}


def run():
    item,frozen=check_frozen()
    if EVIDENCE.exists():
        raise RuntimeError("BLIND_EXECUTION_EVIDENCE_ALREADY_EXISTS; do not overwrite")
    first_execution=utc_now()
    profile=json.loads((ROOT/"phase5_r5_2_2_fixture_tracking_profile.json").read_text(encoding="utf-8"))
    classifier=json.loads((ROOT/"phase5_r5_2_silent_tracking_fault_registration.json").read_text(encoding="utf-8"))["classifier"]
    authority=authority_audit()
    variant_results=[]
    integrity_error=None
    for case in item["cases"]:
        expected=json.loads((ROOT/case["expected_path"]).read_text(encoding="utf-8"))
        for variant in case["fixture_variants"]:
            try:
                check_frozen()
                data=json.loads((ROOT/variant["input_path"]).read_text(encoding="utf-8"))
                rows=data["observations"]
                snapshot=run_candidate(rows,profile,classifier)
                errors=compare(snapshot,expected,rows)
                prefix=prefixes(rows,snapshot,profile,classifier)
                if not prefix["pass"]: errors.append("PREFIX_CAUSALITY_FAILURE")
                repeated=run_candidate(rows,profile,classifier)
                hashes=[hashlib.sha256(canonical(x)).hexdigest() for x in (snapshot,repeated)]
                if hashes[0]!=hashes[1]: errors.append("NONDETERMINISTIC_RESULT")
                if not authority["pass"]: errors.append("FORBIDDEN_MEASUREMENT_SOURCE")
                errors=list(dict.fromkeys(errors))
                variant_results.append({"case_id":case["case_id"],"variant_path":variant["input_path"],
                                        "physics_dt_ns":variant["physics_dt_ns"],"hazards":case["hazards"],
                                        "expected_terminal":expected["expected_terminal_state"],"actual_terminal":snapshot["state"],
                                        "status":"FAIL" if errors else "PASS","errors":errors,
                                        "first_divergence":forensic(errors,snapshot,expected,rows) if errors else None,
                                        "prefix_causality":prefix,"repeatability_sha256_2x":hashes,
                                        "actual_state_sequence":[r["state"] for r in snapshot["records"]],
                                        "actual_transitions":snapshot["transitions"],
                                        "actual_watch_events":snapshot["watch_events"],
                                        "actual_epoch_events":snapshot["epoch_events"]})
            except (RuntimeError,ValueError,TypeError,KeyError,AssertionError) as error:
                integrity_error=str(error)
                variant_results.append({"case_id":case["case_id"],"variant_path":variant["input_path"],
                                        "physics_dt_ns":variant["physics_dt_ns"],"status":"INVALID_EXECUTION","error":integrity_error})
                break
        if integrity_error: break
    source_after={p:sha(ROOT/p) for p in frozen["protected_source_sha256"]}
    if any(source_after[p]!=h for p,h in frozen["protected_source_sha256"].items()):
        integrity_error="R4_4A_CANDIDATE_CHANGED_DURING_BLIND_RUN"
    case_results={c["case_id"]:("PASS" if all(v["status"]=="PASS" for v in variant_results if v["case_id"]==c["case_id"]) and
                                len([v for v in variant_results if v["case_id"]==c["case_id"]])==len(c["fixture_variants"]) else "FAIL") for c in item["cases"]}
    hazards={key:{"cases":ids,"result":"PASS" if all(case_results[i]=="PASS" for i in ids) else "FAIL"}
             for key,ids in item["hazard_coverage"].items()}
    all_pass=not integrity_error and len(variant_results)==51 and all(v["status"]=="PASS" for v in variant_results)
    result={"schema":"phase5-r5-2-1r4-4a-itq-blind-evidence-v1","preregistration_hash":EXPECTED_HASH,
            "freeze_manifest_sha256":sha(FREEZE),"suite_version":item["ITQ_SUITE_VERSION"],
            "freeze_completed_timestamp_utc":frozen["freeze_timestamp_utc"],"first_candidate_execution_timestamp_utc":first_execution,
            "freeze_preceded_execution":frozen["freeze_timestamp_utc"]<first_execution,
            "candidate_engine_sha256":frozen["candidate_R4_3B_engine_sha256"],
            "profile_sha256":item["tracking_profile_sha256"],"Contract15A_sha256":item["Contract15A_sha256"],
            "all_fixture_hashes":frozen["fixtures"],"all_expectation_hashes":frozen["expectations"],
            "ordered_execution_list":[v["variant_path"] for v in variant_results],
            "environment":{"python":sys.version,"platform":platform.platform(),"git_HEAD":frozen["git_HEAD"]},
            "per_variant_results":variant_results,"per_case_results":case_results,"hazard_results":hazards,
            "measurement_authority_audit":authority,
            "mesh_results":{c["case_id"]:[{"physics_dt_ns":v["physics_dt_ns"],"status":v["status"]} for v in variant_results if v["case_id"]==c["case_id"]] for c in item["cases"]},
            "source_hashes_before":frozen["protected_source_sha256"],"source_hashes_after":source_after,
            "integrity_error":integrity_error,"ITQ_SUITE_RESULT":"PASS" if all_pass else ("INVALID_EXECUTION" if integrity_error else "FAIL"),
            "R4_4A_GATE":"INDEPENDENT_TRACKING_QUALIFICATION_BLIND_PASS" if all_pass else ("BLIND_QUALIFICATION_INTEGRITY_FAILURE" if integrity_error else "INDEPENDENT_TRACKING_QUALIFICATION_BLIND_FAILURE"),
            "historical_regression_results":"PENDING_SEPARATE_RERUN",
            "FULL_P_HISTORY_VALIDATION_AVAILABLE":"NO","CAN_PRODUCTION_PORT_START_NOW":"NO"}
    save(EVIDENCE,result)
    print(json.dumps({"result":result["ITQ_SUITE_RESULT"],"gate":result["R4_4A_GATE"],
                      "variants":len(variant_results),"pass":sum(v["status"]=="PASS" for v in variant_results),
                      "fail":sum(v["status"]=="FAIL" for v in variant_results),"invalid":sum(v["status"]=="INVALID_EXECUTION" for v in variant_results)}))


if __name__=="__main__":
    if len(sys.argv)!=2 or sys.argv[1] not in ("freeze","run"):
        raise SystemExit("Usage: run_itq_blind freeze|run")
    {"freeze":freeze,"run":run}[sys.argv[1]]()
