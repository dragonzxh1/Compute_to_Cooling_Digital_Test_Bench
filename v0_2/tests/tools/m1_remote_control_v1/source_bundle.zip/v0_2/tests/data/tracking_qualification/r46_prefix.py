"""Frozen historical conditional selection; no candidate imports or replay."""
import hashlib
import json
from pathlib import Path

from .r45c_i_evidence import artifact, atomic_json, canonical, sha, validate_artifacts

SELECTOR_SOURCE = 'v0_2/tests/data/tracking_qualification/run_itq_blind.py'
SELECTOR_SHA = 'f872517551d1b8fc536e61240ca80871014b305f01b39d3ee05ebc8f91035c9c'
RECIPE = "UTF-8 json.dumps(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False); raw includes final LF"


def mandatory(rows):
    if not rows:
        raise ValueError('EMPTY_OBSERVATIONS')
    keys = {len(rows)}
    previous, previous_valid = None, True
    for i, row in enumerate(rows):
        valid = row['quality'] == 'VALID'
        if previous is None or row['plc_command'] != previous or valid != previous_valid:
            keys.add(i + 1)
        previous, previous_valid = row['plc_command'], valid
    return sorted(keys)


def select(rows, records):
    if len(rows) != len(records):
        raise ValueError('INCOMPLETE_FULL_RUN_RECORDS')
    if any(r['time_ns'] != o['time_ns'] for o, r in zip(rows, records)):
        raise ValueError('FULL_RUN_RECORD_ORDER_MISMATCH')
    progress = [i + 1 for i, r in enumerate(records) if r['state'] == 'TRACKING_PROGRESS']
    confirmed = [i + 1 for i, r in enumerate(records) if r['state'] == 'TRACKING_FAULT_CONFIRMED']
    required = mandatory(rows)
    return {'mandatory_prefix_lengths': required,
            'output_triggered_progress_lengths': progress,
            'output_triggered_confirmed_lengths': confirmed,
            'selected_prefix_lengths': sorted(set(required + progress + confirmed))}


def build(rows, records, entry, execution_id, generation_timestamp, raw_ref, structured_ref):
    selection = select(rows, records)
    if selection['mandatory_prefix_lengths'] != entry['input_only_mandatory_prefix_lengths']:
        raise ValueError('FROZEN_MANDATORY_SET_MISMATCH')
    if len(rows) != entry['observation_count'] or entry['eligible_prefix_universe'] != {'first':1,'last':len(rows)}:
        raise ValueError('FROZEN_ELIGIBLE_UNIVERSE_MISMATCH')
    return {'schema':'r46-selected-prefix-inventory-v1', 'execution_id':execution_id,
            'case_id':entry['case_id'], 'variant_id':entry['input_path'],
            'physics_dt_ns':entry['physics_dt_ns'], 'input_raw_sha256':entry['input_sha256'],
            'full_run_raw_output':raw_ref, 'full_run_structured_output':structured_ref,
            'selector_source_path':SELECTOR_SOURCE, 'selector_source_raw_sha256':SELECTOR_SHA,
            **selection, 'selected_count':len(selection['selected_prefix_lengths']),
            'eligible_prefix_universe':entry['eligible_prefix_universe'],
            'generation_timestamp':generation_timestamp, 'canonical_recipe':RECIPE,
            'exhaustive_all_prefix_mode':False}


def materialize(directory, entry, execution_id, root):
    """Only persisted full-run raw/structured outputs may supply selection."""
    directory, root = Path(directory), Path(root)
    if sha(root / SELECTOR_SOURCE) != SELECTOR_SHA:
        raise ValueError('SELECTOR_SOURCE_DRIFT')
    m = json.loads((directory/'stage_manifest.json').read_bytes())
    if m['status'] != 'COMPLETE' or m['gate']['status'] != 'PASS':
        raise ValueError('FULL_RUN_NOT_COMPLETE_PASS')
    validate_artifacts(m['artifacts'])
    raw_ref = artifact(directory/'stdout.raw')
    structured_ref = artifact(directory/'structured_result.json')
    raw = json.loads((directory/'stdout.raw').read_bytes())
    data = json.loads((directory/'structured_result.json').read_bytes())
    if canonical(raw) != canonical(data):
        raise ValueError('RAW_STRUCTURED_FULL_RUN_MISMATCH')
    fixture = json.loads((root/entry['input_path']).read_bytes())
    if sha(root/entry['input_path']) != entry['input_sha256'] or data['inputs'] != fixture['observations']:
        raise ValueError('FULL_RUN_FROZEN_INPUT_MISMATCH')
    inv = build(data['inputs'], data['snapshot']['records'], entry, execution_id,
                m['end_timestamp'], raw_ref, structured_ref)
    path = directory/'selected_prefix_inventory.json'
    atomic_json(path, inv)
    # Same persisted inputs + timestamp => identical bytes, not a new wall clock.
    rebuilt = build(data['inputs'], data['snapshot']['records'], entry, execution_id,
                    m['end_timestamp'], raw_ref, structured_ref)
    if path.read_bytes() != canonical(rebuilt)+b'\n':
        raise ValueError('NONDETERMINISTIC_PREFIX_INVENTORY')
    ref = artifact(path)
    lock = directory/'selected_prefix_inventory_hashes.json'
    atomic_json(lock, ref)
    validate_artifacts([raw_ref, structured_ref, ref])
    return [ref, artifact(lock)]


def verify_materialized(directory, entry, root):
    directory, root = Path(directory), Path(root)
    if sha(root/SELECTOR_SOURCE) != SELECTOR_SHA:
        raise ValueError('SELECTOR_SOURCE_DRIFT')
    ref = json.loads((directory/'selected_prefix_inventory_hashes.json').read_bytes())
    validate_artifacts([ref])
    inv = json.loads((directory/'selected_prefix_inventory.json').read_bytes())
    validate_artifacts([inv['full_run_raw_output'], inv['full_run_structured_output']])
    data = json.loads((directory/'structured_result.json').read_bytes())
    expected = build(data['inputs'], data['snapshot']['records'], entry, inv['execution_id'],
                     inv['generation_timestamp'], artifact(directory/'stdout.raw'),
                     artifact(directory/'structured_result.json'))
    if canonical(inv) != canonical(expected):
        raise ValueError('SELECTED_INVENTORY_CHANGED_OR_INVALID')
    return inv
