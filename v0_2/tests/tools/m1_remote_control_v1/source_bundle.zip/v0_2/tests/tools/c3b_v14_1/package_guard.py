"""Identity checks only. Does not import either candidate or reference."""
import importlib.metadata
import json
import platform
import sys
from pathlib import Path
from .common import ROOT,canonical,sha,guard,read
from v0_2.tests.tools.execution_journal_v2.journal import logged


@logged('ENVIRONMENT_CHECK')
def environment():
    lock=read('v0_2/tests/tools/c3b_v14_1/development_environment_lock_v1.json')
    actual={'python':platform.python_version(),'executable':sys.executable,'system':platform.system(),
            'version':platform.version(),'machine':platform.machine()}
    if actual!=lock['environment']:raise ValueError('ENVIRONMENT_IDENTITY_MISMATCH')
    deps={n:importlib.metadata.version(n) for n in lock['dependencies']}
    if deps!=lock['dependencies']:raise ValueError('ENVIRONMENT_DEPENDENCY_DRIFT')
    return {'environment':actual,'dependencies':deps,'canonical_sha256':sha(canonical({'environment':actual,'dependencies':deps}))}


@logged('SOURCE_CHECK')
def sources(lock):
    guard()
    for path,expected in lock['source_raw_hashes'].items():
        if sha((ROOT/path).read_bytes())!=expected:raise ValueError('SOURCE_IDENTITY_MISMATCH: '+path)
    return True


def development(lock_path):
    lock=json.loads(Path(lock_path).read_bytes())
    sources(lock);env=environment()
    if lock['mode']!='DEVELOPMENT_ONLY_NOT_QUALIFICATION':raise ValueError('DEVELOPMENT_MODE_REQUIRED')
    return lock,env


def formal_authorization(manifest_path,authorization_path,expected_manifest_sha):
    raise ValueError('V014_1_FORMAL_EXECUTION_FORBIDDEN')
    # Must be called before any candidate/reference/schema imports.
    raw=Path(manifest_path).read_bytes()
    if sha(raw)!=expected_manifest_sha:raise ValueError('FREEZE_MANIFEST_IDENTITY_MISMATCH')
    manifest=json.loads(raw);approval=json.loads(Path(authorization_path).read_bytes())
    if (manifest.get('status')!='FROZEN_USER_APPROVED'
            or manifest.get('full_scope_causally_eligible') is not True
            or approval.get('scope')!='C3-C_FULL_M1_FROZEN_PACKAGE'
            or approval.get('user_execution_authorization')!='GRANTED'
            or approval.get('manifest_raw_sha256')!=sha(raw)
            or approval.get('manifest_canonical_sha256')!=sha(canonical(manifest))):
        raise ValueError('FORMAL_EXECUTION_NOT_AUTHORIZED_FOR_FULL_SCOPE')
    sources(manifest);environment()
    return manifest
