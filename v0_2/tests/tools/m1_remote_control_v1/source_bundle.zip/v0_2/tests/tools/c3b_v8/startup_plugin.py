from pathlib import Path
from .adapters import StartupSplitAdapter


def pytest_collection_modifyitems(items):
    modules={item.module for item in items}
    if len(items)!=50 or any(Path(m.__file__).name!='test_phase5_r5_2_1r4_3_startup.py' for m in modules):
        raise RuntimeError('STARTUP_COLLECTION_INTEGRITY')
    for module in modules:module.StartupTrackingQualifier=StartupSplitAdapter
