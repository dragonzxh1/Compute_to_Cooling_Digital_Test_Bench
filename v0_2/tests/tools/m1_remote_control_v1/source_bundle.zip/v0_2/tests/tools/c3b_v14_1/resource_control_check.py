"""Synthetic owned-process timeout/tree termination check, no candidate import."""

if __name__ == '__main__':
    from v0_2.tests.tools.executor_safety_v2_1.executor import deny_local_workload
    from v0_2.tests.tools.execution_journal_v2.journal import call
    call('ENTRY_GUARD', deny_local_workload)

import ctypes
import json
import os
import sys
import time
import uuid
from .common import ROOT
from .runner import capture
from .evidence import write


def alive(pid):
    if os.name=='nt':
        kernel=ctypes.windll.kernel32
        kernel.OpenProcess.restype=ctypes.c_void_p
        handle=kernel.OpenProcess(0x1000,False,pid)
        if not handle:return False
        try:
            code=ctypes.c_ulong()
            kernel.GetExitCodeProcess(ctypes.c_void_p(handle),ctypes.byref(code))
            return code.value==259
        finally:kernel.CloseHandle(ctypes.c_void_p(handle))
    try:os.kill(pid,0);return True
    except ProcessLookupError:return False


def main():
    root=ROOT/'artifacts/m1-autonomous-development'/('resource-check-'+uuid.uuid4().hex)
    code="import subprocess,sys,time,json;p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(30)'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);print(json.dumps({'child_pid':p.pid}),flush=True);time.sleep(30)"
    result=capture([sys.executable,'-B','-c',code],root,timeout=1)
    child=json.loads((root/'stdout.raw').read_bytes())['child_pid']
    time.sleep(.2)
    child_alive=alive(child)
    evidence={'mode':'SYNTHETIC_INFRASTRUCTURE_ONLY','passed':result['status']=='INVALID' and not child_alive,
        'timed_out_stage_not_complete':result['status']=='INVALID','owned_child_alive_after_timeout':child_alive,
        'capture':result,'candidate_executed':False}
    receipt=write(root/'resource_check.json',evidence)
    print(json.dumps({'receipt':receipt,'passed':evidence['passed']}))


if __name__=='__main__':main()
