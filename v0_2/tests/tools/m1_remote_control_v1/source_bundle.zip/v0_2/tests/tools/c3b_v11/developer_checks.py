"""Durable isolated development unit checks, no formal qualification."""
import json
import sys
import uuid
from .common import ROOT
from .runner import capture,source_lock
from .package_guard import sources,environment
from .evidence import write


def main():
    lock=source_lock();sources(lock);before=environment()
    root=ROOT/'artifacts/m1-autonomous-development'/('unit-'+uuid.uuid4().hex)
    result=capture([sys.executable,'-B','-m','unittest','v0_2.tests.tools.c3b_v11.test_projection',
        'v0_2.tests.tools.c3b_v11.test_state_copy','v0_2.tests.tools.c3b_v11.test_infrastructure','-v'],root,parse=False)
    sources(lock);after=environment()
    receipt=write(root/'unit_result.json',{'mode':'DEVELOPMENT_ONLY','returncode':result['returncode'],
        'capture':result,'environment_before':before,'environment_after':after,'sources':lock,
        'passed':result['returncode']==0 and before==after})
    print(json.dumps(receipt))


if __name__=='__main__':main()

