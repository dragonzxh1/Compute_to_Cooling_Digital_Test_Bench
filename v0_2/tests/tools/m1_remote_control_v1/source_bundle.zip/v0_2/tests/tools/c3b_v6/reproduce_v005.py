"""Checker-only reproduction using archived development evidence, not qualification."""
import json
from pathlib import Path
from v0_2.tests.tools.c3b_v5.common import guard, sha


def main():
    guard()
    root = Path(__file__).resolve().parents[4]
    manifest = json.loads((root / 'phase5_r5_2_1r4_7_c3_b_source_hash_manifest.json').read_bytes())
    for p, expected in manifest['selected_source_hashes'].items():
        assert sha((root / p).read_bytes()) == expected
    prior = manifest['iterations'][-1]
    raw = (root / prior['path']).read_bytes()
    assert sha(raw) == prior['raw_sha256']
    evidence = json.loads(raw)
    from v0_2.tests.tools.c3b_v5.comparator import compare
    frame = evidence['bounded_U']['split_frames'][6]
    reference = evidence['bounded_U']['reference_frames'][6]
    result = compare(reference, frame)
    required = 'FAULT'  # frozen M7: suspected + independently registered pressure FAULT
    data = {'mode': 'DEVELOPMENT_CHECKER_REPRODUCTION', 'source_sha256': sha(raw),
            'declared_pressure_stimulus': True, 'frozen_M7_expected': required,
            'v005_accepted_tracking_only_output': result,
            'output_severity': frame['SAFETY']['severity'],
            'defect_reproduced': result['status'] == 'PASS' and frame['SAFETY']['severity'] != required,
            'formal_qualification': False}
    out = root / 'artifacts/sprint01/reproduce-v005.json'
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, indent=2), encoding='utf-8')
    print(json.dumps(data))
    assert data['defect_reproduced']


if __name__ == '__main__':
    main()
