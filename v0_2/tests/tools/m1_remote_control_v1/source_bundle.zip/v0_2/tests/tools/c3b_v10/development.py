"""Full frozen-input development diagnostic; never formal qualification."""
import json
from pathlib import Path
import traceback
import uuid
from .common import ROOT, read, guard, canonical, sha
from .materializer import extract
from .observer import reference_rows
from .selfcheck import pipeline
from .oracle import OracleTrace
from .comparator import compare_traces


def main():
    guard()
    folder=ROOT/'artifacts/m1-completion-development'/uuid.uuid4().hex
    folder.mkdir(parents=True,exist_ok=False)
    hashes={}
    for p in Path(__file__).parent.glob('*'):
        if p.is_file():
            (folder/p.name).write_bytes(p.read_bytes())
            hashes[p.name]=sha(p.read_bytes())
    descriptors=read('phase5_r5_2_1r4_7_c3_a_reference_oracle_spec.json')['input_inventory']
    profile=read('phase5_r5_2_2_fixture_tracking_profile.json')
    classifier=read('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    results=[]
    for index,d in enumerate(descriptors):
        result={'descriptor_index':index,'stage_id':d['stage_id'],'case_key':d['case_key']}
        try:
            rows=extract(d)['observations']
            reference=reference_rows(rows,profile,classifier,replay_kind=d['replay_kind'])
            actual=pipeline(rows,profile,classifier,'development:'+str(index),replay_kind=d['replay_kind'])
            compared=compare_traces(reference['frames'],actual,oracle=OracleTrace('source-'+str(index),rows))
            result.update(status=compared['status'],comparison=compared)
            if compared['status']!='PASS':
                (folder/(str(index)+'-failure.json')).write_bytes(canonical({'input':rows,'reference':reference,'split':actual,'result':result}))
        except Exception:
            result.update(status='EXCEPTION',traceback=traceback.format_exc())
        results.append(result)
    evidence={'mode':'DEVELOPMENT_ONLY_NOT_QUALIFICATION','source_hashes':hashes,'results':results,
              'pass_count':sum(r['status']=='PASS' for r in results),'total':len(results)}
    (folder/'evidence.json').write_bytes(canonical(evidence))
    print(json.dumps({'path':str(folder/'evidence.json'),'pass':evidence['pass_count'],'total':len(results),
                      'failures':[r for r in results if r['status']!='PASS'][:12]},ensure_ascii=True))


if __name__=='__main__':main()



