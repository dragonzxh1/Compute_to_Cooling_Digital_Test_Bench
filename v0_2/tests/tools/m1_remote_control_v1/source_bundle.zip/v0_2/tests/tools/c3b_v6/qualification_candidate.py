"""Independent guarded execution kernel; FORMAL campaign held pending complete adapters.

Only --preflight and the registered 21-row development run are enabled in this sprint.
No flag, inferred approval, or fixture PASS enables formal C3-C.
"""
import argparse
import hashlib
import json
import os
import platform
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
PACK = ROOT / 'v0_2/tests/tools/c3b_v6/freeze_candidate_v1.json'


def canonical(x):
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()


def sha(b): return hashlib.sha256(b).hexdigest()


def environment():
    from importlib.metadata import version, PackageNotFoundError
    try: schema_version=version('jsonschema')
    except PackageNotFoundError: schema_version='NOT_INSTALLED'
    return {'python':platform.python_version(),'implementation':platform.python_implementation(),
            'executable':str(Path(sys.executable).resolve()),'system':platform.system(),
            'release':platform.release(),'version':platform.version(),'machine':platform.machine(),
            'numpy':version('numpy'),'jsonschema':schema_version,'pytest':version('pytest')}


def preflight():
    pack = json.loads(PACK.read_bytes())
    if pack['status'] != 'DEVELOPMENT_FREEZE_CANDIDATE_NOT_APPROVED':
        raise ValueError('FREEZE_IDENTITY_INVALID')
    for p, expected in pack['sources'].items():
        if sha((ROOT/p).read_bytes()) != expected:
            raise ValueError('SOURCE_IDENTITY_MISMATCH: '+p)
    if environment() != pack['environment']:
        raise ValueError('ENVIRONMENT_IDENTITY_MISMATCH')
    if pack['formal_authorized'] is not False:
        raise ValueError('UNAPPROVED_AUTHORIZATION_STATE')
    return pack


def persist(path, value):
    path = Path(path).resolve()
    allowed = (ROOT/'artifacts/sprint01').resolve()
    if not path.is_relative_to(allowed): raise ValueError('EVIDENCE_PATH_DENIED')
    path.parent.mkdir(parents=True,exist_ok=True)
    raw = canonical(value)+b'\n'
    fd, temp = tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as s:
            s.write(raw); s.flush(); os.fsync(s.fileno())
        os.replace(temp,path)
    finally:
        if os.path.exists(temp): os.unlink(temp)
    if path.read_bytes()!=raw: raise OSError('EVIDENCE_READBACK_FAILED')
    return {'path':str(path.relative_to(ROOT)),'raw_sha256':sha(raw)}


class PFCoverageCollector:
    """Stores witnessed reference cuts without converting registration to qualified PASS."""
    def __init__(self, spec):
        self.paths = {r['id']:[] for r in spec['rows']}

    def record(self, pf, reference_receipt, cut):
        raw=(ROOT/reference_receipt['path']).read_bytes()
        if sha(raw)!=reference_receipt['raw_sha256']: raise ValueError('REFERENCE_HASH_DRIFT')
        data=json.loads(raw)
        if pf not in self.paths or not 0<=cut<len(data['frames']):
            raise ValueError('PF_REFERENCE_CUT_MISSING')
        self.paths[pf].append({'reference':reference_receipt,'cut':cut,
                              'status':'REFERENCE_CUT_CAPTURED_NOT_PRECONDITION_ADJUDICATED'})

    def snapshot(self):
        return {'paths':self.paths,'qualified_paths':[],
                'status':'DEVELOPMENT_CAPTURE_ONLY; no vacuous PF qualification'}


def first_divergence(result):
    return {'status':result['status'],'row':result.get('first_divergent_row'),
            'time_ns':result.get('time_ns'),'findings':result.get('findings',[])}


def development_u():
    # All guard/authorization scope checks above occur BEFORE any reference/split imports.
    from .common import guard, read
    guard()
    from .materializer import extract
    from .observer import reference_rows
    from .selfcheck import pipeline
    from .oracle import OracleTrace
    from .comparator import compare_traces, prefix_inventory_from_persisted_reference
    spec=read('phase5_r5_2_1r4_7_c3_a_reference_oracle_spec.json')
    descriptor=next(d for d in spec['input_inventory'] if d['stage_id']=='U-fresh')
    rows=extract(descriptor)['observations']
    profile=read('phase5_r5_2_2_fixture_tracking_profile.json')
    classifier=read('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    root=ROOT/'artifacts/sprint01/kernel-development-u'
    if root.exists(): raise ValueError('NO_SAME_EXECUTION_OVERWRITE')
    ref=reference_rows(rows,profile,classifier)
    receipt=persist(root/'reference.json',{'origin':'FROZEN_REFERENCE','frames':ref['frames'],
                    'observations':rows,'records':ref['snapshot']['records']})
    prefixes=prefix_inventory_from_persisted_reference(receipt['path'],receipt['raw_sha256'])
    prefix_receipt=persist(root/'prefix_inventory.json',prefixes)
    if sha((ROOT/prefix_receipt['path']).read_bytes())!=prefix_receipt['raw_sha256']:
        raise ValueError('PREFIX_SEAL_DRIFT')
    oracle=OracleTrace('U-none',rows)
    split=pipeline(rows,profile,classifier,'kernel-dev-u')
    split_receipt=persist(root/'split.json',split)
    comparison=compare_traces(ref['frames'],split,oracle=oracle)
    persist(root/'comparison.json',comparison)
    if comparison['status']!='PASS':
        persist(root/'first_divergence.json',first_divergence(comparison))
        raise ValueError('DEVELOPMENT_DIFFERENCE_STOP')
    repeat=pipeline(rows,profile,classifier,'kernel-dev-u')
    if canonical(repeat)!=canonical(split): raise ValueError('REPEAT_MISMATCH')
    persist(root/'repeat.json',repeat)
    result={'mode':'DEVELOPMENT_ONLY','rows':len(rows),'comparison':comparison,
            'reference':receipt,'prefix_inventory':prefix_receipt,'split':split_receipt,
            'PF_qualified':[],'formal_qualification':False,'repeat':'PASS'}
    persist(root/'run_manifest.json',result)
    preflight()
    return result


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--preflight',action='store_true')
    p.add_argument('--development-u',action='store_true')
    p.add_argument('--formal',action='store_true')
    args=p.parse_args()
    if args.formal:
        raise SystemExit('C3_C_FORMAL_EXECUTION_AUTHORIZED=NO; full adapters and separate freeze/execution approval required')
    pack=preflight()
    if args.development_u:
        print(json.dumps(development_u(),ensure_ascii=True))
    else:
        print(json.dumps({'status':'PREFLIGHT_PASS','formal_authorized':False,
                          'remaining_blockers':pack['remaining_blockers']},ensure_ascii=True))


if __name__=='__main__': main()
