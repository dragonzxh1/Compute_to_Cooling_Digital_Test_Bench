"""Read-only diagnostic proof of an unapproved asynchronous input boundary."""
from dataclasses import asdict
import json
import os
from pathlib import Path
import uuid
from .common import ROOT,read,canonical,sha,guard
from .observer import reference_rows
from .adapters import StartupSplitAdapter


def main():
    guard()
    from v0_2.tests.control.test_phase5_r5_2_1r4_1_deferred_demand import _cases
    rows=[asdict(x) for x in _cases()['R41-8']]
    profile=read('phase5_r5_2_2_fixture_tracking_profile.json')
    classifier=read('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    reference=reference_rows(rows[:2],profile,classifier)
    adapter=StartupSplitAdapter(profile,classifier)
    from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation
    adapter.update(ReleasedObservation(**rows[0]))
    try:
        adapter.update(ReleasedObservation(**rows[1]));failure=None
    except Exception as ex:
        failure={'type':type(ex).__name__,'message':str(ex)}
    sources=('phase5_r5_3r_a_tune01_released_input_trace.json',
        'v0_2/tests/control/test_phase5_r5_2_1r4_3_startup.py',
        'v0_2/tests/control/test_phase5_r5_2_1r4_1_deferred_demand.py',
        'phase5_r5_2_1r4_7_c3_a_pf16_comparison_matrix.json',
        'v0_2/tests/tools/c3b_v9/scheduler.py','v0_2/tests/tools/c3b_v9/adapters.py')
    evidence={'mode':'DEVELOPMENT_DIAGNOSTIC_NOT_QUALIFICATION','blocker':'M1-SEM-02',
        'classification':'ADDITIONAL_STARTUP_INPUT_CAUSALITY_SCOPE_REQUIRES_REVIEW',
        'first_rows':rows[:3],'original_source_row_count':len(rows),
        'reference_accepted_rows':len(reference['frames']),
        'reference_final_state':reference['snapshot']['state'],
        'prior_known_issue_ns':rows[0]['command_timestamp_ns'],
        'next_observation_ns':rows[1]['time_ns'],
        'first_visible_new_issue_ns':rows[1]['command_timestamp_ns'],
        'synchronous_precondition_met':rows[1]['command_timestamp_ns']==rows[1]['time_ns'],
        'split_boundary_result':failure,
        'new_rule_chosen':False,'source_hashes':{p:sha((ROOT/p).read_bytes()) for p in sources}}
    directory=ROOT/'artifacts/m1-continuation-development'/uuid.uuid4().hex
    directory.mkdir(parents=True,exist_ok=False)
    path=directory/'input-causality-counterexample.json'
    raw=canonical(evidence)
    with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    assert path.read_bytes()==raw
    print(json.dumps({'path':str(path.relative_to(ROOT)),'raw_sha256':sha(raw),**evidence}))


if __name__=='__main__':main()

