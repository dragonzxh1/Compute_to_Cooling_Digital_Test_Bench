"""Prospective PF06 source proposal. Never changes original PF matrix or gate."""
import json
from pathlib import Path
import uuid
from .common import ROOT,read,canonical,sha
from .runner import source_lock
from .package_guard import sources,environment
from .evidence import write


def main():
    lock=source_lock();sources(lock);before=environment()
    from .materializer import extract
    from .observer import reference_rows
    from .adapters import replay
    from .oracle import OracleTrace
    from .comparator import compare_traces
    from .pf16 import predicates,native
    spec=read('phase5_r5_2_1r4_7_c3_a_reference_oracle_spec.json')
    index=next(i for i,d in enumerate(spec['input_inventory']) if d['stage_id']=='C-history' and d['case_key']=='C8_normal')
    descriptor=spec['input_inventory'][index];rows=extract(descriptor)['observations']
    p=read('phase5_r5_2_2_fixture_tracking_profile.json');c=read('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    root=ROOT/'artifacts/m1-autonomous-development'/('pf06-proposal-'+uuid.uuid4().hex)
    reference=reference_rows(rows,p,c)
    ref_receipt=write(root/'fresh_reference.json',reference)
    actual=replay(rows,p,c)
    actual_receipt=write(root/'fresh_split.json',actual)
    comparison=compare_traces(reference['frames'],actual['frames'],oracle=OracleTrace('source-'+str(index),rows))
    found=[]
    for i,(frame,row) in enumerate(zip(reference['frames'],rows)):
        if predicates(frame,row)['PF-06']:
            pre=native(frame['derived_pre']['core']);post=native(frame['after'])
            anchor=pre['resolved_pair']['resolved_command_anchor'] if pre['resolved_pair'] else pre['startup_observation']['measured_speed']
            direction=1 if row['plc_command']>anchor else -1
            found.append({'row_index':i,'time_ns':row['time_ns'],'source_id':row['measurement_record_id'],
                'expected_direction':direction,'reference_direction':post['direction'],
                'no_new_confirmation':not post['confirmed_latched'],
                'watch_preserved_when_unresolved':pre['oldest_unresolved_demand_ns'] is None or post['oldest_unresolved_demand_ns']==pre['oldest_unresolved_demand_ns']})
    repeated=replay(rows,p,c)
    repeat_receipt=write(root/'repeat_split.json',repeated)
    passed=comparison['status']=='PASS' and bool(found) and all(w['expected_direction']==w['reference_direction'] and w['no_new_confirmation'] and w['watch_preserved_when_unresolved'] for w in found) and actual==repeated
    sources(lock);after=environment()
    evidence={'status':'DEVELOPMENT_VALIDATED_ADDITIONAL_SOURCE_PENDING_REVIEW' if passed and before==after else 'DEVELOPMENT_PROPOSAL_FAIL',
        'PF':'PF-06','proposed_source':descriptor,'source_descriptor_index':index,'witnesses':found,'comparison':comparison,
        'reference_receipt':ref_receipt,'split_receipt':actual_receipt,'repeat_receipt':repeat_receipt,
        'original_matrix_modified':False,'original_PF06_gate':'INCOMPLETE_NO_WITNESS_IN_REGISTERED_SOURCES',
        'promoted_original_gate':False,'formal_execution':False,'environment_before':before,'environment_after':after,
        'required_review':'Prospective versioned additional PF06 source binding only. Preserve original precondition, timing, profile and all 18 CMP rules; no original gate rewrite.'}
    receipt=write(root/'proposal_evidence.json',evidence)
    print(json.dumps({'receipt':receipt,'status':evidence['status'],'witnesses':found}))


if __name__=='__main__':main()
