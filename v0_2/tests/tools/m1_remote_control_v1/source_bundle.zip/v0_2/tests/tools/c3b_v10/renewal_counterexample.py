"""Development causality counterexample, not a replacement qualification fixture."""
from copy import deepcopy
import json
from .common import ROOT, read, canonical, sha, guard
from .materializer import extract
from .observer import reference_rows
from .selfcheck import pipeline


def main():
    guard()
    desc=next(d for d in read('phase5_r5_2_1r4_7_c3_a_reference_oracle_spec.json')['input_inventory'] if d['stage_id']=='ST-15')
    original=extract(desc)['observations'][:3]
    held=deepcopy(original)
    held[-1]['command_timestamp_ns']=held[-2]['command_timestamp_ns']
    profile=read('phase5_r5_2_2_fixture_tracking_profile.json')
    classifier=read('phase5_r5_2_silent_tracking_fault_registration.json')['classifier']
    outcomes=[]
    for name,rows in [('FROZEN_RENEWED',original),('DEVELOPMENT_HELD_METAMORPHIC',held)]:
        reference=reference_rows(rows,profile,classifier)
        split=pipeline(rows,profile,classifier,'same-measurement-prefix')
        ledger=reference['snapshot']['response_history'][0]
        outcomes.append({'kind':name,'input':rows,'input_sha256':sha(canonical(rows)),
                         'reference_ledger':ledger,'PRE':split[-1]['PRE'],
                         'split_pre_ledger':split[-1]['pre_core']['response_history'],
                         'post_ledger':split[-1]['after']['response_history'],
                         'reference':reference,'split':split})
    same_PRE=outcomes[0]['PRE']==outcomes[1]['PRE']
    different_reference=outcomes[0]['reference_ledger']['command_timestamp_ns']!=outcomes[1]['reference_ledger']['command_timestamp_ns']
    result={'status':'SAME_VALUE_RENEWAL_ATTRIBUTION_REQUIRES_FROZEN_COMPATIBILITY_ADJUDICATION',
            'protected_fixture_unchanged':True,'formal_qualification':False,
            'comparison_scope':'exact original response_history timestamp vs immutable old-PLC PRE attribution',
            'same_measurement_and_prior_context_same_PRE':same_PRE,
            'reference_ledger_changes_with_not_yet_issued_command_timestamp':different_reference,
            'outcomes':outcomes}
    assert same_PRE and different_reference
    out=ROOT/'artifacts/m1-completion-development/same-value-renewal-counterexample.json'
    out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(canonical(result))
    print(json.dumps({'path':str(out),'same_PRE':same_PRE,'reference_timestamps':[o['reference_ledger']['command_timestamp_ns'] for o in outcomes],
                      'PRE_old_timestamp':outcomes[0]['PRE']['old_command']['issue_ns']},ensure_ascii=True))


if __name__=='__main__':main()


