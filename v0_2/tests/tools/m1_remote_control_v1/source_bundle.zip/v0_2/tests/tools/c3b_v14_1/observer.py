"""Read-only entry/exit observer. Does not replace/wrap reference update."""
from .common import read
from .codec import encode, decode
from v0_2.tests.tools.execution_journal_v2.journal import logged,span,call

FIELDS = tuple(read('phase5_r5_2_1r4_7_c3_a_reference_oracle_spec.json')
               ['state_observer_design']['reference_attributes'])


def observe(qualifier):
    values = vars(qualifier)
    return {name: encode(values[name]) if name in values else {'type': 'absent'}
            for name in FIELDS}


@logged('REFERENCE_REPLAY', 'replay_kind', 'observed')
def reference_rows(rows, profile, classifier, *, observed=True, replay_kind='generic'):
    """Only called by explicitly authorized bounded development self-checks."""
    from v0_2.examples.phase5_r5_2_1r4_5c_lifecycle_engine import WatchLifecycleTrackingQualifier
    from v0_2.examples.phase5_r5_2_1r_semantic_engine import ReleasedObservation
    q = WatchLifecycleTrackingQualifier(profile, classifier)
    frames = []
    causal_history = []
    for tick,row in enumerate(rows):
        with span('REFERENCE_TICK', tick=tick, time_ns=row['time_ns'], observed=observed):
            before = call('REFERENCE_OBSERVE_BEFORE', observe, q) if observed else None
            provenance = 'POST_COMMAND_EFFECT' if replay_kind == 'ST-08' and row['time_ns'] == 600000000 else 'CERTIFIED_INTERVAL_END'
            from .pre_oracle import derive
            derived=call('REFERENCE_DERIVE', derive, q,row,provenance,causal_history) if observed else None
            if observed:
                causal_history=call('REFERENCE_HISTORY_DECODE', decode, derived['core']['response_history'])
            with span('REFERENCE_UPDATE'):
                q.update(ReleasedObservation(**row), provenance=provenance)
            if observed:
                frames.append({'before': before, 'after': call('REFERENCE_OBSERVE_AFTER', observe, q), 'input_provenance': provenance,'derived_pre':derived})
    with span('REFERENCE_FINAL_SNAPSHOT'):
        return {'frames': frames, 'final': observe(q), 'snapshot': q.snapshot()}



