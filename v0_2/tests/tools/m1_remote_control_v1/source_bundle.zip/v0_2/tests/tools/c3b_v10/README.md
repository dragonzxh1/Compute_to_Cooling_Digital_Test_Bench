# M1 v010 operator guide

Use the pinned interpreter (PowerShell):

```powershell
& 'D:/Github/c2c-m1-development-20261011/Scripts/python.exe' -B -m v0_2.tests.tools.c3b_v10.developer_checks
& 'D:/Github/c2c-m1-development-20261011/Scripts/python.exe' -B -m v0_2.tests.tools.c3b_v10.selfcheck
& 'D:/Github/c2c-m1-development-20261011/Scripts/python.exe' -B -m v0_2.tests.tools.c3b_v10.runner --development
```

Full development runs create NEW exclusive directories under
artifacts/m1-autonomous-development/. Do not overwrite old runs. The runner
records local raw stdout/stderr and fsyncs them before parsing. It then hashes
and persists structured results/pre-gate manifests before adjudication. Each
worker has an independent process and verifies source bytes/environment before
importing a candidate. References and frozen reference expectations complete
first. The next SELECT phase seals every prefix inventory before any split
replay. C/S group expectations, U/v2, ITQ51, P15, repeats and reference-selected
prefixes are separate gates; an earlier PASS is never reused in a fresh run.
Exact package source snapshots, fresh infrastructure/CMP checks, PF16 witness
cuts, Startup eligibility and schema/readback results belong to that same run.

ITQ uses the frozen conditional selector; U/ST/C/S/P15 use ALL observation
prefixes as required by the original C3-A support policy. Worker wall-clock
budget is 480 seconds (not a control/profile timer). Timeout ends the owned
Windows process tree before final raw hashes. Original timeout runs remain INVALID.

For a smoke run only, append --only-index 0. --skip-prefixes is diagnostic only:
its result is INCOMPLETE, never a full package acceptance.

## Two scopes (do not merge their grades)

- SYNCHRONOUS_VERIFIED_PLC_ISSUE: test-only authenticated PLC output after
  committed PRE/Safety. All 56 reference fields and 18 CMP rules apply.
- LEGACY_ASYNCHRONOUS_OBSERVATION_REPLAY: exact raw trace and reported issue
  timestamp replay through the unchanged qualified legacy algorithm. No receipt
  or historical Safety commit is fabricated. Without independent earlier issue
  evidence it is UNVERIFIED_HISTORICAL_ISSUE; Lane B/C are INCOMPLETE, not PASS.
- Malformed/unreleased/nonfinite Startup packets are quarantined from PRE.
  Legacy rejection behavior may be checked, but this is not proof of valid P1
  measurement/command provenance. Nonfinite values are never coerced to valid data.

Original Startup 49/50 and its exact line-144 legacy flag assertion remain
separate from fresh versioned U/v2 compatibility and from causal eligibility.
Never rewrite original Startup to 50/50 or waive an unrelated failure.

PF06 original registered-source coverage stays INCOMPLETE. The C8_normal
row-4/800-ms witness is a separate prospective source binding; its positive
cut and the two original-source negative controls are recorded without changing
the frozen predicate. Approval remains PENDING_USER_REVIEW.
The engineering gate M1_DEVELOPMENT_COMPLETE_FULL_SCOPE_PENDING is not original
full-scope readiness or formal qualification. Five Startup inputs still lack
strict P1 eligibility. Review the single decision brief and manifest delivered
with this package before any independently authorized formal freeze/execution.

## Freeze and formal execution

freeze_candidate_manifest.json binds exact prospective package identities. It
is a review candidate, not an approved semantic freeze or execution authorization.
M1-SEM-01 projection and asynchronous-domain separation require independent
freeze review; C3-A originals are unchanged.

The formal entry is deliberately denied by default. A future independently
approved FULL-scope manifest must be FROZEN_USER_APPROVED, mark every mandatory
case causally eligible, and be bound by raw/canonical hashes to a separate human
execution authorization with scope C3-C_FULL_M1_FROZEN_PACKAGE. These conditions
are checked BEFORE candidate imports. Current artifacts do NOT grant this.
Do not edit an authorization flag to get around a failed guard.

No real control, production port, Phase 6 or Git publication is included.
T09 physical recovery is IMPLEMENTATION_HOLD; full P history remains unavailable;
hardware remains CALIBRATION_REQUIRED.
