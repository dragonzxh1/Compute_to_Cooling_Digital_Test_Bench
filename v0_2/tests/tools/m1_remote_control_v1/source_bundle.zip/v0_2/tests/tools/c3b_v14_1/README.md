# v014.1 exact Job identity repair — development only

Only semantic implementation delta from v014: native helper gives its owned
Job a unique Local name and persists it before resume. The actual pinned Python
opens that specific Job with QUERY rights, asks IsProcessInJob for membership,
reads back CPU/memory/process/kill-on-close limits, then closes its query handle.
Launcher/interpreter PID equality is no longer required; both are recorded.
Unknown/missing/wrong Job or mismatched limits reject before workload.
No limit, tracking math, fixture, expectation, safety mapping or numerical policy
is retuned. V014 failed execution and all older sources remain unchanged.

Identity preflight must execute pinned Python through this native helper and
the real authorization guard: positive membership; another existing Job despite
being in some Job; missing Job; mismatched limit. No heat before all pass.

Microsoft reference: https://learn.microsoft.com/en-us/windows/win32/api/jobapi/nf-jobapi-isprocessinjob

## Preserved v014 execution policy

This version is authorized by the current user's explicit agreement to a new
controlled retest version. v011/v012/v013 and their default-deny entries remain
unchanged. The v014_1 guard requires a hash-bound, expiring authorization and exact
source identities. Workers additionally require their own native Job start
receipt (matching PID, 1% CPU, kill-on-close, memory/wall limits) before workload.
There is no unchecked CLI override. Formal qualification is always rejected.

Native executor v2: CPU 1%, process <=256 MiB, Job <=512 MiB, <=4 owned
processes, each stage <=120 s. Whole coordinator sequence <=1 h at stage
boundaries; individual timeouts remain independently enforced. Coordinator
only orchestrates/readbacks, outside the child CPU Job; do not use it for
compute workloads. Runtime guard files and native heartbeats are diagnostic,
not PLC/measurement/Safety evidence.

Journal v2 rotates into append-only 64 MiB segments, max 64 segments (4 GiB),
with at least 8 GiB free disk required before each workload stage. No segment
deletion/compression or weakened tracking criteria. inspect_log in journal v2
reads ordered segments and reports unfinished spans/corrupt tails.

Order: fresh control checks; 30 s original stdlib bool workload under resource
cap; fresh REFERENCE/SELECT/SPLIT/PREFIX for indices 65/66/92; fresh full M1
development campaign. First abnormal/invalid/behavioral FAIL stops, without
same-run repair/retry. A stopped campaign is INCOMPLETE, not a blanket FAIL/PASS.
No prior grades are spliced in. No production/hardware/Phase 6/Git publication.

The cap/logging changes wall-clock conditions. Even a complete clean execution
would show only no reproduction in this resource-controlled environment, not
that the original unrestricted workload, hardware or driver is fixed.

## Archived v013 notes (not v014_1 execution instructions)

Local hot cycles, long prefixes and full campaigns remain DEFAULT DENY.
There is no bypass switch. Do not launch archived stress scripts. This delivery
adds diagnostic checkpoints, NOT an M1 PASS or host-stability qualification.

## Where logs go

The new runner/worker and `m1_runtime_recovery_v3.probe` create a unique directory
under `artifacts/execution-progress-v014_1/run-*/progress.jsonl`. The process-only
`C2C_PROGRESS_LOG_ROOT` variable shares the directory with children; it is not a
Windows/global setting. A new run must use a new directory. Never resume a partial
tail or reuse a previous run as new qualification evidence.

Each operation has a fsynced BEGIN before work, then END or ERROR. Context
includes PID/session, UTC/monotonic timestamps, stage kind/index, prefix length,
tick and simulation time, repeat index and phase as applicable. Logs never grant
new tracking sample credit, change commands, or feed the comparator.

Hooks: campaign/stage/child boundary, input materialization, source/env checks,
reference derive/update/observation, prefix replay/comparison, repeat,
measurement/PRE/Safety/PLC issue/PLC accept/POST, artifact hash/fsync/readback.
The hot-cycle template records admission and cycle/operation checkpoints, but
admission stops before any hot operation. Older archived entry points have NOT
been retrofitted and must not be run.

## Read after a restart (read-only)

Replace the example directory with the actual run directory:

```powershell
& 'D:\Github\c2c-m1-development-20261011\Scripts\python.exe' -B -m v0_2.tests.tools.execution_journal_v2.inspect_log 'D:\Github\Compute_to_Cooling_Digital_Test_Bench\artifacts\execution-progress-v014_1\run-<actual-id>'
```

`last_unfinished_step` is the latest entered but unclosed span. Its context gives
the prefix/tick/phase. `last_completed_by_session` and `errors` show completed
steps and ordinary exceptions. Missing END does not prove that this function
caused a kernel/driver/hardware hang. END means returned, not behavioral PASS.
Partial/corrupt lines are explicitly reported.

## Resource and timing limitations

One shared append-only journal uses bounded cross-process locking (1 s wait),
64 MiB/run and 8 KiB/record. Disk/lock/budget failure stops further execution;
there is no silent sampling or overwrite. These are diagnostic resource limits,
not tracking thresholds. Future large campaigns may hit the budget before
completion and need a separately reviewed logging policy/version.

Fsync at each checkpoint adds I/O and changes wall-clock performance. These logs
cannot certify the original runtime's timing or real-time safety. There is no
background busy heartbeat or telemetry stress. Python BEGIN/END cannot locate
an internal native instruction or guarantee disk-cache survival after power loss.

## Preserved safety baseline

This is NOT a completed M1 campaign or a qualified runtime repair. v011 and all
historical/frozen artifacts remain unchanged. Tracking math, thresholds,
sample times, 56 fields and 18 CMP meanings have not been revised.

Local stress, prefix replay and full campaign execution are DEFAULT DENY because
the development host suffered confirmed hard hangs. No unsafe CLI override exists.
Do not run old archived stress scripts either. A host review and separately
versioned workload authorization are required before any future real campaign.

The replacement execution layer is ../executor_safety_v2_1/. Its Windows helper:

- holds a machine-wide mutex shared across the new entry points;
- creates the child suspended, sets and reads back Job Object CPU/memory/process
  limits, assigns it BEFORE resume; unsupported setup fails closed;
- kills owned descendants on supervisor exit and bounds cleanup waits;
- saves raw output before parsing. Missing/failed cleanup cannot become COMPLETE.
  One failed/invalid result stops the sequence.

Safety verification uses fake processes and short sleeping/exit-only children.
Policy: at most 10 s, CPU rate 100/10000 (1% of parent-job allocation if nested,
otherwise of system), at most 256 MiB committed memory per process and 512 MiB
per owned job, at most four processes. Output is sampled against 2 MiB, not an
exact kernel file-size quota.

These controls cannot prevent hardware/kernel hard hangs. No Windows, BIOS,
power, driver or global Python configuration is changed. T09 physical durability
remains IMPLEMENTATION_HOLD; hardware CALIBRATION_REQUIRED; full P history
unavailable. Original Startup 49/50 and five P1 exclusions remain.

No formal C3-C, production port, Phase 6 or Git commit/push is authorized.
