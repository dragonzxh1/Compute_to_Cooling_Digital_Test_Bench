"""Strict outer artifact schemas and readback validation, without candidate execution."""
from functools import lru_cache
import json
from pathlib import Path
from jsonschema import Draft202012Validator
from .common import ROOT,canonical,sha
from .schemas import obj,array,INT,TEXT,BOOL,HASH,definitions,validate
from .evidence import verify


@lru_cache(maxsize=1)
def schemas():
    receipt=obj({'path':TEXT,'raw_sha256':HASH,'canonical_sha256':HASH,'bytes':{'type':'integer','minimum':0}},required=['path','raw_sha256','bytes'])
    descriptor=obj({'case_key':TEXT,'input_canonical_sha256':HASH,'input_pointer':TEXT,'replay_kind':TEXT,
        'result_canonical_sha256':HASH,'result_path':TEXT,'result_raw_sha256':HASH,'row_count':{'type':'integer','minimum':1},'stage_id':TEXT})
    comparison=obj({'mode':TEXT,'status':TEXT,'findings':array(obj({'rule':TEXT,'pointer':TEXT})),
        'compared_rows':INT,'rules':array(TEXT),'first_divergent_row':INT,'time_ns':{'type':['integer','null']}},required=['mode','status','findings','rules'])
    point=obj({'row_index':INT,'time_ns':INT,'source_id':TEXT})
    stage=obj({'PF_witnesses':{'type':'object','additionalProperties':array(point)},'checks':{'type':'object','additionalProperties':BOOL},
        'comparison':comparison,'descriptor':descriptor,'domain':{'const':'SYNCHRONOUS_VERIFIED_PLC_ISSUE'},'mode':TEXT,
        'reference_receipt':receipt,'repeat_hashes':array(HASH),'repeat_pass':BOOL,'repeat_receipts':array(receipt),
        'required_snapshot_count':{'type':'integer','minimum':2},'split_receipt':receipt,'status':{'enum':['PASS','FAIL']}})
    lengths={'type':'array','uniqueItems':True,'items':{'type':'integer','minimum':1}}
    inventory=obj({'source':{'const':'FRESH_PERSISTED_REFERENCE'},'reference_receipt':receipt,'input_sha256':HASH,
        'mandatory_prefix_lengths':lengths,'output_triggered_progress_lengths':lengths,
        'output_triggered_confirmed_lengths':lengths,'selected_prefix_lengths':lengths,
        'selection_policy':{'enum':['ITQ_FROZEN_CONDITIONAL','SUPPORT_FROZEN_ALL_PREFIXES']}},
        required=['source','reference_receipt','input_sha256','mandatory_prefix_lengths','output_triggered_progress_lengths','output_triggered_confirmed_lengths','selected_prefix_lengths'])
    prefix=obj({'status':{'enum':['PASS','FAIL']},'inventory_receipt':receipt,'selected_count':INT,
        'failures':array(obj({'length':INT,'cause':TEXT}))})
    pre_gate=obj({'returncode':INT,'timeout':BOOL,'parse_error':{'type':['string','null']},'artifacts':array(receipt),'elapsed_s':{'type':'number','minimum':0}})
    driver=obj({'status':{'enum':['COMPLETE','INVALID']},'pre_gate_receipt':receipt,'artifacts':array(receipt)})
    snapshot=obj({'confirmed_latched':BOOL,'state':TEXT,'deferred_demand':{'type':['object','null']},
        'progress_pair':{'type':['object','null']},'resolved_pair':{'type':['object','null']},
        **{k:array({'type':'object'}) for k in ('deferred_events','direction_events','epoch_events','lifecycle_events','progress_pair_events',
          'records','resolved_pair_events','response_history','transitions','watch_events')}})
    full_reference=obj({'frames':array({'$ref':'#/$defs/reference'}),'final':{'$ref':'#/$defs/core'},'snapshot':snapshot})
    full_split=obj({'snapshot':snapshot,'frames':array({'$ref':'#/$defs/frame'})})
    return {**definitions(),'receipt':receipt,'descriptor':descriptor,'stage_result':stage,'prefix_inventory':inventory,
        'prefix_result':prefix,'pre_gate':pre_gate,'driver':driver,'snapshot':snapshot,'full_reference':full_reference,'full_split':full_split}


def schema(kind):return {'$schema':'https://json-schema.org/draft/2020-12/schema','$defs':schemas(),'$ref':'#/$defs/'+kind}


def check(kind,data):
    import copy
    s=copy.deepcopy(schema(kind));s['$defs']['frame']={'type':'object'};s['$defs']['reference']={'type':'object'};s['$defs']['core']={'type':'object'}
    Draft202012Validator(s).validate(data)
    if kind=='full_reference':
        validate('core',data['final'])
        for frame in data['frames']:validate('reference',frame)
    elif kind=='full_split':
        for frame in data['frames']:validate('frame',frame)


def validate_run(directory):
    directory=Path(directory)
    counts={};errors=[]
    types={'stage_result.json':'stage_result','prefix_inventory.json':'prefix_inventory','prefix_result.json':'prefix_result',
        'pre_gate_manifest.json':'pre_gate','driver_stage_manifest.json':'driver'}
    for path in directory.rglob('*.json'):
        kind=types.get(path.name)
        if kind:
            data=json.loads(path.read_bytes());check(kind,data);counts[kind]=counts.get(kind,0)+1
            if kind=='driver':
                verify(data['pre_gate_receipt'])
                for r in data['artifacts']:verify(r)
            if kind=='stage_result':
                for r in [data['reference_receipt'],data['split_receipt'],*data['repeat_receipts']]:check('receipt',r);verify(r)
            if kind=='prefix_result':verify(data['inventory_receipt'])
            if kind=='prefix_inventory':
                ref=verify(data['reference_receipt'])
                n=len(ref['frames']);sets=[data[k] for k in ('mandatory_prefix_lengths','output_triggered_progress_lengths','output_triggered_confirmed_lengths')]
                if data['selected_prefix_lengths']!=sorted(set().union(*map(set,sets))) or any(i>n for i in data['selected_prefix_lengths']):raise ValueError('PREFIX_SCHEMA_SET_INTEGRITY')
                if data.get('selection_policy')=='SUPPORT_FROZEN_ALL_PREFIXES' and data['selected_prefix_lengths']!=list(range(1,n+1)):raise ValueError('SUPPORT_EXHAUSTIVE_PREFIX_REQUIRED')
    for key in schemas():Draft202012Validator.check_schema(schema(key))
    return {'passed':True,'validated_artifact_counts':counts,'source_sha256':sha(Path(__file__).read_bytes())}
