"""Isolated evidence-first runner. Formal entry requires separate user approval."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid
from .package_guard import environment,sources,formal_authorization
from .common import ROOT,canonical,sha,read,guard
from .evidence import write,receipt,verify


def capture(command,directory,*,parse=True,timeout=480):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    controls={'PYTHONDONTWRITEBYTECODE':'1','PYTEST_DISABLE_PLUGIN_AUTOLOAD':'1','PYTHONFAULTHANDLER':'1'}
    env={**os.environ,**controls}
    start=time.monotonic();timed_out=False
    with (directory/'stdout.raw').open('xb') as out,(directory/'stderr.raw').open('xb') as err:
        process=subprocess.Popen(command,cwd=ROOT,stdout=out,stderr=err,env=env)
        try:code=process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            # Kill the OWN spawned process tree, including Windows venv launcher
            # children, before hashing raw output. No late child may append after
            # the pre-gate receipt. This is a resource limit, not a tracking timer.
            if os.name=='nt':
                killed=subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True)
                if killed.returncode!=0 and process.poll() is None:process.kill()
            else:process.kill()
            code=process.wait();timed_out=True
        out.flush();os.fsync(out.fileno());err.flush();os.fsync(err.fileno())
    refs=[receipt(directory/'stdout.raw'),receipt(directory/'stderr.raw')]
    for item in refs:verify(item)
    parsed=None;error=None
    if parse:
        try:parsed=json.loads((directory/'stdout.raw').read_bytes())
        except (ValueError,UnicodeError) as ex:error=type(ex).__name__+':'+str(ex)
    if parsed is not None:refs.append(write(directory/'structured_result.json',parsed))
    pre={'returncode':code,'timeout':timed_out,'parse_error':error,'artifacts':refs,'elapsed_s':time.monotonic()-start,
        'execution_controls':{'command':command,'environment_overrides':controls,'worker_pid':process.pid,'timeout_s':timeout}}
    prereceipt=write(directory/'pre_gate_manifest.json',pre)
    verify(prereceipt)
    gate='INVALID' if timed_out or error or (parse and code!=0) else 'COMPLETE'
    write(directory/'driver_stage_manifest.json',{'status':gate,'pre_gate_receipt':prereceipt,'artifacts':refs})
    return {'status':gate,'result':parsed,'returncode':code,'artifacts':refs,'elapsed_s':pre['elapsed_s']}


def source_lock():
    package=Path(__file__).parent
    hashes={p.relative_to(ROOT).as_posix():sha(p.read_bytes()) for p in package.iterdir() if p.is_file() and p.name!='freeze_candidate_manifest.json'}
    frozen=read('phase5_r5_2_1r4_7_c3_a_integrity_evidence.json')
    hashes.update({p:d['raw_sha256'] for p,d in {**frozen['source_hash_bindings'],**frozen['artifact_hashes']}.items()})
    # Bind every example/test/helper actually imported by expectation adapters,
    # not only the original minimal normative sources.
    for folder in ('v0_2/examples','v0_2/tests/control','v0_2/tests/data/tracking_qualification'):
        for p in (ROOT/folder).rglob('*.py'):hashes[p.relative_to(ROOT).as_posix()]=sha(p.read_bytes())
    return {'mode':'DEVELOPMENT_ONLY_NOT_QUALIFICATION','source_raw_hashes':hashes,'environment':environment()}


def campaign(*,only_index=None,prefixes=True,formal=None,support_only=False):
    if formal is not None:lock=formal_authorization(*formal)
    else:lock=source_lock()
    sources(lock);env_before=environment()
    root=ROOT/'artifacts/m1-autonomous-development'/('run-'+uuid.uuid4().hex)
    root.mkdir(parents=True,exist_ok=False)
    lockreceipt=write(root/'source_lock.json',lock)
    # Immutable exact source bytes accompany this run, not only their hashes.
    source_receipts=[]
    for path in lock['source_raw_hashes']:
        if path.startswith('v0_2/tests/tools/c3b_v10/'):
            source_receipts.append(write(root/'source_snapshot'/Path(path).name,(ROOT/path).read_bytes()))
    write(root/'source_snapshot_receipts.json',source_receipts)
    from .schemas import selfcheck,validate
    selfcheck()
    unit=capture([sys.executable,'-B','-m','unittest','v0_2.tests.tools.c3b_v10.test_projection',
        'v0_2.tests.tools.c3b_v10.test_state_copy','v0_2.tests.tools.c3b_v10.test_infrastructure',
        'v0_2.tests.tools.c3b_v10.test_campaign_protocol','-v'],root/'checks'/'unit',parse=False)
    sources(lock)
    if unit['status']!='COMPLETE' or unit['returncode']!=0:raise ValueError('DEVELOPMENT_UNIT_CHECKS_FAIL')
    bounded=capture([sys.executable,'-B','-m','v0_2.tests.tools.c3b_v10.selfcheck',
        '--output-root',str(root/'checks'/'CMP'/'artifacts')],root/'checks'/'CMP',parse=True)
    sources(lock)
    if bounded['status']!='COMPLETE' or not all(c['passed'] for c in bounded['result']['checks']):raise ValueError('CMP_ORACLE_NEGATIVE_CHECKS_FAIL')
    from .adapters import suite_checks
    spec=read('phase5_r5_2_1r4_7_c3_a_reference_oracle_spec.json')
    descriptors=spec['input_inventory'];indices=list(range(len(descriptors))) if only_index is None else [only_index]
    if support_only:indices=[i for i in indices if not descriptors[i]['stage_id'].startswith('ITQ-')]
    references={};selections={};stages={};prefix_results={};errors=[];reference_groups={};split_groups={}

    def step(kind,index,extra=()):
        sources(lock);verify(lockreceipt)
        directory=root/('%03d'%index)
        command=[sys.executable,'-B','-m','v0_2.tests.tools.c3b_v10.worker','--kind',kind,'--index',str(index),
            '--directory',str(directory),'--lock',str(root/'source_lock.json'),*extra]
        if formal:command+=['--formal-manifest',formal[0],'--authorization',formal[1],'--manifest-sha256',formal[2]]
        result=capture(command,directory/kind.lower())
        sources(lock);environment()
        if result['status']!='COMPLETE':
            errors.append({'kind':kind,'index':index,'cause':'INVALID_STAGE_EXECUTION','evidence':result})
            # Integrity/safety stops never silently become local behavioral failures.
            stderr=(directory/kind.lower()/'stderr.raw').read_text(errors='replace')
            if any(word in stderr for word in ('SOURCE_IDENTITY_MISMATCH','ENVIRONMENT_','ARTIFACT_INTEGRITY','EVIDENCE_READBACK','RECEIPT_IDENTITY','STAGE_RESULT_IDENTITY','OBSERVER_INTERFERENCE','PREFIX_INVENTORY_IDENTITY','PREFIX_INPUT_BINDING')):
                raise ValueError('HARD_INTEGRITY_STOP: '+stderr[-2000:])
            if formal:raise ValueError('FORMAL_STAGE_FAIL_STOP')
            return None
        if result['result'].get('status')=='FAIL' and formal:raise ValueError('FORMAL_BEHAVIORAL_FAIL_STOP')
        return result['result']

    def groups(source,output):
        for label,kind in (('C-history','C'),('S-history','S')):
            applicable=[i for i in indices if descriptors[i]['stage_id']==label]
            if not applicable:continue
            expected=13 if kind=='C' else 19
            if len(applicable)!=expected or any(i not in source for i in applicable):
                output[kind]={'status':'INCOMPLETE'};continue
            snapshots={descriptors[i]['case_key']:source[i]['snapshot'] for i in applicable}
            checks=suite_checks(kind,snapshots)
            output[kind]={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks}

    # All fresh reference outputs/expectations durably complete before split execution.
    for index in indices:
        result=step('REFERENCE',index)
        if result:references[index]=verify(result['receipt'])
        print('REFERENCE',index,'PASS' if result else 'INCOMPLETE',flush=True)
    groups(references,reference_groups)
    if any(r['status']=='FAIL' for r in reference_groups.values()):raise ValueError('FROZEN_REFERENCE_GROUP_NOT_PASS')
    # Freeze every inventory from fresh durable reference output before split replay.
    for index in indices:
        if index not in references:continue
        ref_sha=receipt(root/('%03d'%index)/'reference.json')['raw_sha256']
        selection=step('SELECT',index,['--expected-reference-sha',ref_sha])
        if selection:selections[index]=selection
        print('SELECT',index,selection['status'] if selection else 'INCOMPLETE',flush=True)
    for index in indices:
        if index not in references or index not in selections:continue
        raw_sha=receipt(root/('%03d'%index)/'reference.json')['raw_sha256']
        result=step('SPLIT',index,['--expected-reference-sha',raw_sha,'--expected-stage-sha',selections[index]['inventory_receipt']['raw_sha256']])
        if result:
            stages[index]=result
        print('SPLIT',index,result['status'] if result else 'INCOMPLETE',flush=True)
    split_snapshots={i:verify(json.loads((root/('%03d'%i)/'stage_result.json').read_bytes())['split_receipt']) for i in stages}
    groups(split_snapshots,split_groups)
    if prefixes:
        for index in indices:
            if index not in stages or stages[index]['status']!='PASS':continue
            result=step('PREFIX',index,['--expected-stage-sha',stages[index]['stage_receipt']['raw_sha256']])
            if result:prefix_results[index]=result
            print('PREFIX',index,result['status'] if result else 'INCOMPLETE',flush=True)
    coverage=[]
    for definition in read('phase5_r5_2_1r4_7_c3_a_pf16_comparison_matrix.json')['rows']:
        key=definition['id'];w=[];failed=[]
        for i,result in stages.items():
            if key in result['PF_witnesses']:
                if result['status']!='PASS':failed.append(i)
                else:w.extend({'descriptor_index':i,**point} for point in result['PF_witnesses'][key])
        coverage.append({'id':key,'status':'FAIL' if failed else 'PASS' if w else 'INCOMPLETE',
            'witnesses':w,'failed_stages':failed,'predicate_source':'pf16.py',
            'normative_precondition':definition['original_C1_registered_row']['original_registered_path']['precondition']})
    startup=None
    if only_index is None:
        directory=root/'startup';directory.mkdir()
        command=[sys.executable,'-B','-m','pytest','-q','v0_2/tests/control/test_phase5_r5_2_1r4_3_startup.py',
            '-o','addopts=','-p','no:cacheprovider','-p','v0_2.tests.tools.c3b_v10.startup_plugin',
            '-p','v0_2.tests.data.tracking_qualification.r45c_i_pytest_capture',
            '--c2c-evidence-dir',str(directory),'--m1-domain-log',str(directory/'domain_reports.jsonl'),
            '--junitxml',str(directory/'junit.xml')]
        result=capture(command,directory/'process',parse=False)
        from v0_2.tests.data.tracking_qualification.r45c_i_startup_guard import judge_startup
        judged=judge_startup(json.loads((directory/'pytest_results.json').read_bytes()),result['returncode'],read('phase5_r5_2_1r4_5c_i_startup_legacy_signature.json'))
        domains=[json.loads(line) for line in (directory/'domain_reports.jsonl').read_bytes().splitlines()]
        legacy=[r for r in domains if r['domain_events']]
        compatible=judged['status']=='PASS' and all(stages.get(i,{}).get('status')=='PASS' for i in (0,12))
        startup={'historical_guard':judged,'versioned_compatibility':'PASS' if compatible else 'FAIL',
            'legacy_or_quarantined_cases':legacy,'causal_status':'INCOMPLETE' if legacy else 'PASS',
            'receipts':[receipt(p) for p in directory.iterdir() if p.is_file()]}
        write(directory/'startup_result.json',startup)
    sources(lock);env_after=environment()
    if env_before!=env_after:raise ValueError('ENVIRONMENT_DRIFT_AFTER_EXECUTION')
    from .witness_matrix import collect
    witness_matrix=collect(root,descriptors,stages)
    witness_receipt=write(root/'PF16_witness_matrix.json',witness_matrix)
    eligibility=None
    if startup:
        from .eligibility import evaluate
        eligibility=evaluate(startup)
        write(root/'startup_eligibility.json',eligibility)
    from .artifact_schemas import validate_run
    schema_readback=validate_run(root)
    schema_receipt=write(root/'schema_readback_validation.json',schema_readback)
    sources(lock);environment()
    full=only_index is None and not support_only
    # Missing qualifying scope is not a software PASS and not a behavioral FAIL.
    # Keep engineering execution completeness separate from original readiness.
    passed=(full and len(stages)==101 and all(r['status']=='PASS' for r in stages.values())
        and all(r['status']=='PASS' for r in split_groups.values())
        and prefixes and len(prefix_results)==101 and all(r['status']=='PASS' for r in prefix_results.values())
        and startup and startup['versioned_compatibility']=='PASS' and not errors
        and witness_matrix['original_validated_count']==15
        and witness_matrix['PF06_proposal']['PF06_SUPPLEMENTAL_SOURCE']=='DEVELOPMENT_VALIDATED')
    original_ready=False  # semantic addenda and PF06 source binding are not user-frozen.
    output={'mode':'FORMAL_C3_C' if formal else 'DEVELOPMENT_ONLY_NOT_QUALIFICATION',
        'status':'M1_DEVELOPMENT_COMPLETE_FULL_SCOPE_PENDING' if passed else 'M1_DEVELOPMENT_INCOMPLETE',
        'original_frozen_full_scope_ready':original_ready,'limited_scope_review_candidate':bool(passed),
        'single_run_cohesive':bool(passed),'source_snapshot_receipts':source_receipts,
        'unit_checks':unit,'CMP_oracle_selfchecks':bounded,'schema_readback_receipt':schema_receipt,
        'PF16_matrix_receipt':witness_receipt,'startup_eligibility':eligibility,
        'descriptor_count':len(stages),'pass_count':sum(r['status']=='PASS' for r in stages.values()),
        'engineering_checks_passed':bool(passed),'source_lock_receipt':lockreceipt,'reference_groups':reference_groups,'split_groups':split_groups,
        'stages':stages,'prefix_selections':selections,'prefix_results':prefix_results,'PF16':coverage,'startup':startup,'errors':errors,
        'environment_before':env_before,'environment_after':env_after,'schemas_validated':True,
        'C3_C_formal_execution':bool(formal),'production':False,'phase6':False,'git_commit_push':False,
        'full_P_history_available':False,'hardware':'CALIBRATION_REQUIRED'}
    resultreceipt=write(root/'development_result.json',output)
    print(json.dumps({'result':resultreceipt,'status':output['status'],'passed':output['pass_count'],'PF_statuses':[(r['id'],r['status'],len(r['witnesses'])) for r in coverage]},ensure_ascii=False),flush=True)
    return output


def main():
    p=argparse.ArgumentParser();p.add_argument('--development',action='store_true');p.add_argument('--only-index',type=int)
    p.add_argument('--skip-prefixes',action='store_true');p.add_argument('--support-only',action='store_true');p.add_argument('--formal-manifest');p.add_argument('--authorization');p.add_argument('--manifest-sha256')
    args=p.parse_args()
    if args.development:
        if args.formal_manifest or args.authorization:raise ValueError('MIXED_AUTHORITY_MODES_FORBIDDEN')
        campaign(only_index=args.only_index,prefixes=not args.skip_prefixes,support_only=args.support_only)
    else:
        if args.only_index is not None or args.skip_prefixes or args.support_only:raise ValueError('FORMAL_SCOPE_REDUCTION_FORBIDDEN')
        if not all((args.formal_manifest,args.authorization,args.manifest_sha256)):
            p.error('Formal execution requires independently approved freeze and hash-bound user authorization; not authorized now.')
        formal=(args.formal_manifest,args.authorization,args.manifest_sha256)
        formal_authorization(*formal)
        campaign(formal=formal)


if __name__=='__main__':main()
