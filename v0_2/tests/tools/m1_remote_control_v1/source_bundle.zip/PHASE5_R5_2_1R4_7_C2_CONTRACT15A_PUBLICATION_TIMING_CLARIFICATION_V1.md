# Contract15A Publication Timing Clarification — v1.0

Status: **NOT_FROZEN_STATIC_ACCEPTANCE_STOP**  
Phase: R4.7-C2  
Policy ID: C2C-15A-PUBLICATION-TIMING-v1.0  
Model: P1_PHASE_QUALIFIED_TWO_CUT  
T-09 status: APPROVED_WITH_IMPLEMENTATION_HOLD

本文件是用户本轮明确授权的独立版本化规范，仅为未来qualification/integration确定T-01～T-10有限时间协议。不覆盖或修改原Contract15A，不追溯声称原合同或R4.6已经包含此协议；算法、severity/restriction、reset authority、六tracking state及原finalpublication timing均不改。若后续需改这些冻结行为，必须STOP并单独重开语义。

验收停止记录：SC-04文本检查器字面匹配失败。本文件为已批准内容的待冻结版本，不是通过验收的C2规范身份；最终manifest为NOT_FROZEN。T-01～T-10措辞不因该失败修改，未修检查器/未重跑取PASS。

草案来源：PHASE5_R5_2_1R4_7_C1_CONTRACT15A_TIMING_CLARIFICATION_DRAFT.md；批准RAW SHA-256=fd18a0a721b571db5d6be68222052d21a38fc1dde2fe70d099175f7a5ecbd58d。用户授权附件和source身份由C2registration绑定。

这是有限policy freeze，不是完整runtime freeze或split等价性通过。UP-01/02/03/05既有独立批准政策保持；UP-04 fullsplit仍UNRESOLVED。C3harness creation/behavioral replay、productionport和Phase6全部未授权。

## T-01. 作用域与不变项

保持六public tracking states、Policy A、Contract06/07/14/15/15A mapping、PLC唯一ActuatorCommand生产者与Safety限制-only权限。没有新threshold/timer/硬件参数/actuator restriction/reset authority。UP-01/02/03/05既有批准政策不重开。本有限时间政策不解决未完成的startup/reissue/recovery/reference refinement。

## T-02. 唯一事务与因果切面

每个逻辑scheduler transaction声明唯一transaction_id与scheduler cycle_id，顺序为：

```text
qualified release + 已获准旧PLC context
 → PRE：旧义务评价 + genuine evidence commit
 → immutable PRE_SAFETY_CONTRIBUTION_RECORD
 → Safety all-channel decision / envelope commit
 → PLC sole final command issue
 → POST：command lifecycle enrollment + CONTEXT_ONLY references
 → POST_FINAL_PUBLICATION_RECORD
```

cycle_id是scheduler身份，不是尚未产生的新PLC cycle ID。PRE只可引用已经存在的command/obligation；不得用requested target、echo或未来PLC输出证明归属。物理同tick不等于因果无序，timestamp相同时仍记录phase偏序；不引入epsilon或移动冻结sample时刻。

## T-03. PRE记录身份与不可变性

PRE_SAFETY_CONTRIBUTION_RECORD包含transaction_id、scheduler cycle_id、phase=PRE、source composite identity/source time/release资格、旧command/obligation/watch身份、tracking_state_at_safety_evaluation、15A severity/reasons/restrictions、evidence_commit_id、PRE_record_id与Safety_decision_reference。

Safety decision未建立前，该reference只能是预留的decision identity（不包含未来decision内容），或在单独不可变binding record中关联；不能事后修改PRE内容。Safety决策回链PRE record及evidence commit。没有可核验旧obligation身份时用明确nullable/既有startup epoch身份，不伪造义务。

PRE是内部Safety输入与audit记录，不是第二public tracking event，不增加第七state。不得将qualifier.last_public_state强制改为PRE以制造旧测试事件。

## T-04. POST记录与context-only

POST_FINAL_PUBLICATION_RECORD包含同一transaction_id/cycle_id、phase=POST、实际新PLCcommand/cycle/envelope身份、真实lifecycle transition及其reference provenance、final public tracking state、linked PRE record、confirmed latch与final publication ID。

POST可读取本拍已记录measurement的CONTEXT_ONLY信息以重现合法paired/startup/directional reference建立，不得产生新的progress credit/fault evidence/confirmation/response-opportunity consumption或第二sample credit。没有provenance资格不能因为context-only就洗成可信reference。每逻辑tick只按reference原规则产生一次final公开record，原public transition/milestone数量与time保持。

## T-05. 允许差异但不否定真实PRE

经独立refinement验证的同tickwithdrawal，可以出现PRE SUSPECTED、POST STEADY：前者表示旧义务在旧command下的真实qualified evidence，后者表示新获准command撤回后无当前方向义务的合法final lifecycle state。POST STEADY不代表已经建立resolved anchor，也不表示旧证据失效。

两者通过同事务的measurement/旧obligation/evidence/newPLCcommand/lifecycle links解释。绝不把它解释成PRE“误判”，不改写历史SafetyDecision、reasons、envelope或已经issued的command。PRE CONFIRMED不因withdrawal/reissue变成STEADY；原latch与既有协调reset政策保留。

这是本阶段新获批准的前瞻时间切面约定，不声称既有Contract15A已经写明，也不追溯加入R4.6。

## T-06. Contribution适用范围与expiration

每个非latched PRE tracking contribution仅能被它所绑定的Safety_decision_id/scheduler cycle消费；不是可反复借用的“当前tracking输入”。该SafetyDecision及其已issued envelope/PLCcommand属于历史与实际控制事实，不能因POST改state撤销或回滚；envelope自身有效性/恢复/dwell/watchdog仍服从既有Contract15，不因本条自动清SafetyState。

下一次Safety evaluation必须用届时已enrolled状态和可见qualified measurements重新生成新的PRE contribution。前一cycle的nonlatched SUSPECTED reason不得直接copy成新cycle的active tracking理由，也不能拿旧PRE record刷新sample age。若新的合法evaluation仍SUSPECTED，它是新的因果记录；若新evaluation是STEADY/HANDOFF/PROGRESS，tracking contribution为NORMAL identity。

因此POST不会retroactively删除上一决策的DEGRADED，下一决策也不会永远借旧PRE DEGRADED。这不是新时间窗口/保持timer。若下一评价不能安全形成，禁止声称continuity/NORMAL已恢复；按既有输入invalidity、latch及批准INVALID_CONTINUATION处理，不能继续复用旧非latched输入制造qualified决定。调度停止时的硬件action/timeout不由本提案猜测。

明确冻结解释：PRE contribution仅作为输入停止适用，并不自动清除committed SafetyState、已确认FAULT latch、其他active reasons、既有envelope restriction或Contract15仍保留的保护。POST STEADY没有此清除权限。

## T-07. Confirmed和all-reason retention

confirmed evidence与top-levelFAULT latch跨cut/cycle存在，source invalidity不清它。只能依既有批准Safety reset/recovery authority及UP-03 coordinated transaction解除target active latch，audit历史不删，本提案没有新增reset权。

每次Safety决策独立按15/15A reduce所有active reasons，保留sensor/thermal/hydraulic/pressure/FF/其他channel和既有latches。POST publication不能直接写SafetyState、清其他reason或更换envelope。Severity和restriction mapping在PRE原样适用：SUSPECTED DEGRADED/no tracking restriction；CONFIRMED FAULT/existingfallback；其他三正常state无tracking severity；INSUFFICIENT无新actuatorfault。

## T-08. PRE不可信用的数据

Released source质量、window、timebase/uncertainty、restart epoch及权威PLC归属必须合格。UNKNOWN、mixed window、duplicate、stale、out-of-order和不可验证continuity不赚新tracking evidence；不使用TRUE/ACTUAL fallback或flow/DP替代speed confirmation。既有独立sensor政策生效；不把unknown attribution自动改成新FAULT。

## T-09. 不可回滚边界与POST失败

PRE evidence commit、SafetyDecision commit、PLC command issue分别是因果提交点，不能因为POST失败将已经发生的真实measurement evaluation/Safety/command擦除。transaction记录停在实际达到的phase；如果command是否issued未知，明确unknown，不能推定未发或重发。

POST失败后，不发布伪造successful finalSTEADY、不重复PRE、不第二次消费样本、不为了修日志自动产生另一PLC command。保留last committed public state及其原transaction/time，另有内部INCOMPLETE/INVALID_CONTINUATION audit metadata（不新增公开state/Safety reason）。已confirmed/Safetylatch仍保持。

恢复必须通过受控state/input/journal核验，只可补全该transaction未完成的context/lifecycle工作，不能重新赚旧sample evidence、不能回写已提交PRE/Safety。具体durable journal/幂等reconciliation和硬件issued状态核验留给单独设计验证，本有限时间政策不证明它们已实现或合格，T-09保留IMPLEMENTATION_HOLD。

明确冻结四个不同因果提交点：PRE_EVIDENCE_COMMIT、SAFETY_DECISION_COMMIT、PLC_COMMAND_ISSUE、POST_FINAL_PUBLICATION_COMMIT；不能假定它们对外部硬件是一个原子事务。

若实际PLC command issue无法验证，COMMAND_ISSUE_STATUS=UNKNOWN。UNKNOWN是内部audit/integrity属性，不是第七tracking state；禁止猜ISSUED或NOT_ISSUED，禁止自动补发/回滚/继续command lifecycle enrollment，直到权威command journal和因果身份受控核对完成。

last committed public state仅保留其原publication_id、transaction_id与时间，作为历史已提交记录。新transaction须用独立内部status明确未完成；不能把旧state加本拍time/ID重新发布成fresh completed result。内部INCOMPLETE不添加新Safety reason，亦不允许清confirmed或其他独立FAULT。

## T-10. 不借资格结果与独立验证边界

R4.6 oracle只用于原finaltracking/internalstate/evidence/pairs/publicevents的对照；没有原production PRE Safety记录可作golden oracle。PRE/Safety新增记录须按本独立冻结时间政策另行验收，不用最终state字符串代替因果验证。

C2仅冻结本有限时间切面条款；C3必须先另获创建资格包授权，再冻结split测试实现、comparators、输入/预期/phase比较cut、hash与失败STOP规则，之后另批执行。不改原fixtures/expected/candidate，不借旧PASS。完整runtime finalfreeze与productionport仍禁止，直到16路径和restart/provenance等要求全部关闭。

## 规范记录schema绑定

PRE_SAFETY_CONTRIBUTION_RECORD与POST_FINAL_PUBLICATION_RECORD的版本化字段、类型、null语义、immutablebinding和不记功约束，按同包phase5_r5_2_1r4_7_c2_timing_policy_registration.json的record_schemas冻结；不在此把未来实际硬件缺失字段填成伪造数值。

PRE只供一个绑定Safetydecision；POST按原sample/cyclecut最多生成原reference的一次finalpublication。不同PRE/POST是两个因果记录切面，不是新增publicstate。后续实现必须证明record与source/command/evidence一一关联，而非仅匹配字段名字。

