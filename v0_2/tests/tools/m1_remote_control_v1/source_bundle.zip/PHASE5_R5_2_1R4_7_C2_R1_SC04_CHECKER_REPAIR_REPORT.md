# R4.7-C2-R1 — SC-04 Static Checker Repair Report

Result: repaired checker self-validation 8/8 PASS; repair restricted to SC-04 predicate. No policy/candidate/production change.

## Actual original source provenance

Original C2 checker was an inline Python `-c` invocation, not a repository standalone file. Located in the current chat's real session log:
`C:/Users/Aiden Zhang/.codex/sessions/2026/09/26/rollout-2026-09-26T14-08-48-01a0a525-b4e1-7671-82ca-7769895794e1_01a0dc54-9ffe-7742-889e-358bb0a34253.jsonl:3779`, call_id=`call_d6db57f6a70644b5bb4323dc0ef37803`.
Historical log line RAW=7f999a6063247e165d122ddbfffdbc2433fac2b3c8be1e47e615122d6f5b4cbd; tool input UTF-8 RAW=3332702296e88e5931b7ec4a5b40531b48469468af1ad2597e1437a9eb448637.
Actual original inline Python source RAW=db016bfdd28dc8eb54f24da711c610dd528d8c7852eee906b5b254fbd0fc5293.

New capture `v0_2/tests/tools/c2r1_static_checker_original_capture.py` RAW=736aa800a060daf9ffa999052b24154b1deb4dafa2e90d76da8b7b26b98e6543. It preserves original code with final EOF newline; its file hash is not falsely presented as a pre-existing historical checker file. The original inline checker was not rerun now.

Repaired `v0_2/tests/tools/c2r1_static_checker.py` RAW=b459f9bfb5dd7bcff9fee67fd83de1d838b95bce5d9e5272024da6d02168ce97. Only line11 (SC-04 passed predicate) differs between materialized versions; all11 other check-call ASTs match exactly, not just outcomes. No original policy/evidence file rewritten.

## Precise repair

Original requires literal `confirmed FAULT latch`. Repaired accepts precisely that representation OR `已确认FAULT latch`, inside the explicit non-clearing protection sentence. No fuzzy matching, translation-based policy rewrite, dropped clause or always-PASS.

Original three mandatory literals remain; additional exact sentence guards preserve next authoritative evaluation, nonreuse of old nonlatched input, committed SafetyState/latch/all-reason/envelope/Contract15 protections, and no POST direct clear. These guards are all within SC-04. No SC01–03/05–12 acceptance expression changed.

## Checker-only synthetic checks

| Case | Expected | Observed |
| --- | --- | --- |
| POS-CHINESE | PASS | PASS — expected outcome matched |
| POS-ENGLISH | PASS | PASS — expected outcome matched |
| NEG-NO-LATCH | FAIL | FAIL — expected outcome matched |
| NEG-POST-CLEAR | FAIL | FAIL — expected outcome matched |
| NEG-NO-ALL-REASONS | FAIL | FAIL — expected outcome matched |
| NEG-REUSE-SUSPECTED | FAIL | FAIL — expected outcome matched |
| NEG-NO-ENVELOPE | FAIL | FAIL — expected outcome matched |
| NEG-AUTO-CLEAR-ON-EXPIRY | FAIL | FAIL — expected outcome matched |

Two positive strings and six negative mutated strings only; no candidate fixture execution. Mutation text hashes recorded in checker freeze/evidence. Synthetic tests precede repaired checker freeze and full acceptance.

## Freeze and scope

Checker source frozen in `phase5_r5_2_1r4_7_c2_r1_checker_freeze.json` BEFORE fresh execution, freezeRAW=ecc57584c4a1a4a6f96734f34fca4083e8221dd6526868989ac13955738d670d.
No checker changes after formal acceptance starts; execution_count1, repair/retry=false.
Original C2 11PASS/1FAIL preserved; invalid70-character authorization hash superseded solely by user's corrected64-character RAW/canonical authorization. Original evidence did not change.

This tool fix does not prove any of16PF behaviors or T09 durable recovery. C3 and production port not authorized.

