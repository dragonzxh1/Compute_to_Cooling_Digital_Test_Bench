# R4.7-B — Production Runtime Restart / Scheduling / Provenance Semantics Preregistration

## 当前裁决

`RUNTIME_SEMANTICS_REQUIRE_USER_POLICY_DECISION`。

本包是待审预登记，不是冻结规范，不是移植授权。R4.6的软件域资格保持有效。B1不能从已有合同唯一推导持久化策略；B2可静态映射部分路径，但完整split等价性仍为 `PORT_RUNTIME_SEMANTIC_EQUIVALENCE_UNRESOLVED`。B3已提出桥接schema与拒绝不确定归属规则，未证明真实硬件提供这些能力。因此B1–B3尚未关闭。

大白话：规定“重启不能洗掉故障”“一条样本不能算两次”很清楚；但怎么保存状态、重启失败怎么办，以及拆成前后两段后是否仍和原算法一样，还需要裁决和证明，不能靠流程图宣布通过。

## 1. 来源、授权与身份

只允许静态source读取、JSON解析和SHA-256计算；不import或执行candidate/runner/test。全部source/hash bindings见registration，包含R4.7-A registration、R4.6 manifest、完整candidate父链、Policy A/v2/U、Contract06/07/14/15/15A、Safety/PLC/measurement/actuator/loop/profile。

当前candidate RAW为453f2f1d02c9aaa845d5222b3ef01da8c1a9db6580268c54674d374d76fa9300。R4.6 manifest RAW为68dc4ef177146e64132e522e519bec2721cbf84f2610a5e2dd3457ddf1085d49，canonical为794fc58cdecf1fb2a1a47f17e2ba181e3153f46a7be34be0e07ce15bb3f5b85d。Policy A/v2/U仍分别为d86eaa…167082 / 8c793b…f8976 / 2dbc47…cf707。source绑定真实本机bytes，不改原批准包。

本文简称lifecycle/startup/paired/directional/deferred分别对应 `v0_2/examples/phase5_r5_2_1r4_5c_lifecycle_engine.py`、`...r4_3_startup_engine.py`、`...r4_paired_engine.py`、`...r4_2_directional_engine.py`、`...r4_1_deferred_engine.py`。精确raw身份在机器包。

## 2. B1：各类restart/reset不能混同

| 事件 | 所需连续性 | 未决边界 |
| --- | --- | --- |
| tracking process restart | 需完整state+transaction切面+原source消费身份；旧样本仅作历史上下文不赚新credit | A/C未裁决；Safety latch独立保留 |
| controller process restart | 不等同qualifier reset；获准PLC command journal与last accepted output需重新关联 | 若command continuity丢失，禁止伪续接 |
| PLC reset/reinitialize | 显式PLC source epoch，finalcommand身份新namespace；硬件held output不能猜 | 旧义务继续/重新enroll界限及输出恢复需用户协议 |
| Safety.reset_fault | 独立显式操作；不隐含清qualifier counters/history/latch | qualifier confirmed如何由批准恢复协议解除未定，不能无限自动复位 |
| telemetry source restart | 显式source restart event与new epoch；所有旧source样本无新credit | 时间重新qualification，未知epoch禁止把sample复用视为fresh |
| complete system restart | Safety独立latch ledger、qualifier、PLC journal、source epochs一致恢复证明 | 持久化选择与恢复失败动作USER_POLICY_DECISION_REQUIRED |
| partial component restart | 声明受影响component epochs与输入边界；其他component历史不默默清除 | 交叉引用无法核对时INVALID_CONTINUATION，不新增tracking fault |

现有Safety.reset_fault只清Safety自身latch/timer（supervisor.py:106），PLC构造器新建PID/sequence（inner_loop.py:54），candidate snapshot仅导出部分诊断（lifecycle:190；paired:282），不存在完整restore协议。不能把PID initialize叫watch reset，也不能把Safety reset当qualifier全清。

## 3. State persistence classification

所有REQUIRED_FOR_CONTINUITY是“若声称连续恢复则必须保留”的条件，不等于本阶段选择写checkpoint。纯输入重构需要完整权威journal和同一transaction切面，当前echo不够。

| 实际字段/依赖 | 分类 | 理由与来源 |
| --- | --- | --- |
| watch_number | REQUIRED_FOR_CONTINUITY | lineage与最早未解证据时间不能由当前command倒推；paired:100; lifecycle:79 |
| oldest_unresolved_demand_ns | REQUIRED_FOR_CONTINUITY | lineage与最早未解证据时间不能由当前command倒推；paired:100; lifecycle:79 |
| epoch | REQUIRED_FOR_CONTINUITY | 保留active/completion、direction establishment、response boundary和matched references；direction可依法supersede，不等于重置watch；paired:100; directional:24 |
| direction | REQUIRED_FOR_CONTINUITY | 保留active/completion、direction establishment、response boundary和matched references；direction可依法supersede，不等于重置watch；paired:100; directional:24 |
| directional_obligation | REQUIRED_FOR_CONTINUITY | 保留active/completion、direction establishment、response boundary和matched references；direction可依法supersede，不等于重置watch；paired:100; directional:24 |
| latest_demand | REQUIRED_FOR_CONTINUITY | 保留active/completion、direction establishment、response boundary和matched references；direction可依法supersede，不等于重置watch；paired:100; directional:24 |
| resolved_pair | REQUIRED_FOR_CONTINUITY | 保留成对值、pair IDs、source epoch/measurement/command IDs、建立原因与时间；不能用重启后速度拼造；paired:14-34;58;73 |
| progress_pair | REQUIRED_FOR_CONTINUITY | 保留成对值、pair IDs、source epoch/measurement/command IDs、建立原因与时间；不能用重启后速度拼造；paired:14-34;58;73 |
| qualified_progress_seen | REQUIRED_FOR_CONTINUITY | retention与State U reissue所需真实progress历史；lifecycle:37;79 |
| episode_progress | REQUIRED_FOR_CONTINUITY | retention与State U reissue所需真实progress历史；lifecycle:37;79 |
| carried_suspicion_evidence | REQUIRED_FOR_CONTINUITY | 真实evidence、suspected provenance与confirmed latch；paired:239; lifecycle:79 |
| suspected_since_ns | REQUIRED_FOR_CONTINUITY | 真实evidence、suspected provenance与confirmed latch；paired:239; lifecycle:79 |
| confirmed_latched | REQUIRED_FOR_CONTINUITY | 真实evidence、suspected provenance与confirmed latch；paired:239; lifecycle:79 |
| confirmed_since_ns | REQUIRED_FOR_CONTINUITY | 真实evidence、suspected provenance与confirmed latch；paired:239; lifecycle:79 |
| last_measurement_id | REQUIRED_FOR_CONTINUITY | 原source身份与episode/obligation/sample复合键，禁止跨义务重复credit；lifecycle:57;123; paired:240 |
| response_history | REQUIRED_FOR_CONTINUITY | 原source身份与episode/obligation/sample复合键，禁止跨义务重复credit；lifecycle:57;123; paired:240 |
| consumed_samples | REQUIRED_FOR_CONTINUITY | 原source身份与episode/obligation/sample复合键，禁止跨义务重复credit；lifecycle:57;123; paired:240 |
| deferred_demand | REQUIRED_FOR_CONTINUITY | 完整deferred嵌套ID/reference/net/direction/firsttime/prior evidence/recovery状态；deferred:12;51;104 |
| measurement_unavailable_since_ns | REQUIRED_FOR_CONTINUITY | 完整deferred嵌套ID/reference/net/direction/firsttime/prior evidence/recovery状态；deferred:12;51;104 |
| last_valid_state | REQUIRED_FOR_CONTINUITY | 完整deferred嵌套ID/reference/net/direction/firsttime/prior evidence/recovery状态；deferred:12;51;104 |
| startup_observation | REQUIRED_FOR_CONTINUITY | State U旧语义、outage方向与真实progress仅公开一次；startup:13;21;49;137 |
| startup_outage_direction | REQUIRED_FOR_CONTINUITY | State U旧语义、outage方向与真实progress仅公开一次；startup:13;21;49;137 |
| startup_demand_suspended | REQUIRED_FOR_CONTINUITY | State U旧语义、outage方向与真实progress仅公开一次；startup:13;21;49;137 |
| published_progress_epoch_id | REQUIRED_FOR_CONTINUITY | State U旧语义、outage方向与真实progress仅公开一次；startup:13;21;49;137 |
| previous_observation | REQUIRED_FOR_CONTINUITY | 旧command timestamp替换上下文、严格因果时钟与公开transition基线；lifecycle:108;131;168 |
| last_time_ns | REQUIRED_FOR_CONTINUITY | 旧command timestamp替换上下文、严格因果时钟与公开transition基线；lifecycle:108;131;168 |
| public_tracking_state | REQUIRED_FOR_CONTINUITY | 旧command timestamp替换上下文、严格因果时钟与公开transition基线；lifecycle:108;131;168 |
| last_command | RECONSTRUCTIBLE_FROM_AUTHORITATIVE_INPUT | 仅从完整、完整性核验的PLC command journal重构，与checkpoint previous_observation/obligation时间切面一致；缺journal时REQUIRED_FOR_CONTINUITY，echo不可替代；静态symbol使用审计 |
| credited_motion | DIAGNOSTIC_ONLY | 当前qualified父链中用于累计和record输出，未找到分支读；连续诊断需保留或从完整progress日志重算，不能称行为证据可丢；静态symbol使用审计 |
| _evaluation_allowed | SAFE_TO_REINITIALIZE | 仅已完成transaction边界可初始化True；中途crash不得据此视为已提交；静态symbol使用审计 |
| records/transitions/lifecycle_events/direction_events diagnostic payload | DIAGNOSTIC_ONLY | 不能把response_history或生成ID依赖的event计数一起当纯日志丢弃；永久审计存档独立要求；静态symbol使用审计 |
| restore failure action / downtime time mapping / qualifier-Safety reset binding | UNSPECIFIED_REQUIRING_USER_POLICY | 无冻结合同唯一决定，不增第七state或擅自设新severity；静态symbol使用审计 |
| epoch_number | REQUIRED_FOR_CONTINUITY | 分配tracking-epoch身份的真实counter；semantic:89; paired:102 |
| resolved_pair_events / progress_pair_events / deferred_events identity allocation dependency | REQUIRED_FOR_CONTINUITY | 当前代码分别使用list长度或CREATE事件数量分配ID。日志payload可能诊断，但这些分配依赖不能直接丢弃；改成等价counter须未来批准和验证；paired:63;90; deferred:68 |

nested字段必须原子一致：TrackingEpoch的身份/起点/方向/anchor/latestcommand/response-open/completion/证据时刻；DirectionalTrackingObligation的direction/established_ns/command/resolved/progress pair IDs；两类pair的成对值/时间/原因/source IDs；DeferredObservableDemand全部字段（deferred:12）；StartupObservation command/measured/sample/ID；response_history原样的episode/obligation/source/window时间/旧command/matched-reference/eligibility provenance。消费ledger不能以只有last sample ID替代。

ID allocation是额外静态发现：paired:63/90用event-list长度生成pair IDs，deferred:68用CREATE数量生成ID。即使事件payload诊断-only，也不能随意清列表；未来改counter不是本阶段授权。credited_motion当前只作累加与record，没有发现当前qualified父链用它判分，但连续诊断丢失应显式标记。

## 4. Restart invariants（拟冻结）

- R-01 process restart不得把已confirmed故障当作从未存在
- R-02 pre-restart样本不得赚post-restart新evidence；可保留作已消费历史reference
- R-03 source/sample ID重用不能与旧consumed identity碰撞
- R-04 restart/source epoch显式；复合键包含source/entity/metric/epoch/sample
- R-05丢single-credit/lineage/latch/provenance所需数据的partial restore不是continuation
- R-06 Safety reset与qualifier restart/reset保持独立，除非后续冻结binding
- R-07 Safety.reset_fault不隐含清全部qualifier history
- R-08 qualifier restart不清独立Safety FAULT latch
- R-09不能用command echo/requested command/unqualified measurement伪造continuity
- R-10旧source measurement不得归属post-restart新directional obligation

重启边界跨越时，旧数据可保留作已经合法建立的paired-reference和history，不能作为post-restart新观测重新记功。新runtime epoch与source/PLC epoch是三种身份，不要每次host重启伪造设备source重启；source是否真的重启必须由可信事件/能力证明，未知则不能认证连续性。

严格跨epoch身份包括source/entity/metric/source restart epoch/sample ID；obligation/watch身份带runtime namespace映射。尚未commit的transaction与已经commit的evidence不可混合恢复。缺关键state标记INVALID_CONTINUATION只是内部完整性状态，不是第七公开tracking state，更不是新FAULT reason。

## 5. Checkpoint / cold / hybrid 选项

| 方案 | 保持与缺口 | Safety/身份/持久化边界 |
| --- | --- | --- |
| A — integrity-checked full checkpoint/restore | 完整已提交切面可保留watch/evidence/pairedrefs/singlecredit/StateU/latch；须再证明外部输入clock与PLC连续性；PERMISSIBLE_CANDIDATE_NOT_UNIQUELY_SELECTED | 所有REQUIRED字段、profile/classifier/hash、ID分配计数、consumption ledger、commit boundary与独立Safety latch证据；不解除独立Safety latch；reset binding未定；保留logical IDs；新runtime epoch显式；source epoch是否变化取真实事件 |
| B — new restart epoch without logical continuity | 新identity可避免ID碰撞，但冷清零丢watch/suspicion/history/confirmed，不能透明保持R4.6 invariant；NOT_VALID_AS_TRANSPARENT_CONTINUATION_FOR_UNRESOLVED_OR_CONFIRMED_STATE | 至少独立confirmed/Safety审计latch ledger和旧history存在事实，否则R-01不满足；Safety latch独立保留；冷restart不能充当reset；新epoch不自动让旧packet fresh，必须排除pre-restart source |
| C — required qualified state restore plus input continuity requalification | 有完整必要state且禁止旧样本新增credit可保持内部历史；外部continuity失败策略未定；DEFENSIBLE_DESIGN_DIRECTION_BUT_USER_POLICY_DECISION_REQUIRED | 全部必要state与ID allocation；纯诊断可单独audit store；不能裁掉retention依赖responsehistory；独立latch保留，恢复测量不自动reset；显式runtime/source/PLC epochs；同epoch跨restart continuity也需证明 |

A并不能单凭checksum证明真实PLC/clock连续性。B“新epoch+清零”对未解watch或confirmed不保持原语义，即使Safety latch保留也不能冒充qualifier历史保留。C是有理由进一步细化的设计方向，但原规范并未唯一选择C，因此本阶段不把推荐当批准。三方案均不能从echo/新速度重建旧证据；不增加公开state。

未选定persistence policy：NONE / USER_POLICY_DECISION_REQUIRED。停机时间如何映射原response clock、first fresh sample如何建立可证明机会，亦未冻结；不能将停机本身算作有效失败样本，也不能发无限新grace。

## 6. B2：拟议scheduler split

```text
已存在的获准 PLC command journal + released measurement
  → PRE：归属确认 / 旧义务评价 / genuine evidence commit
  → tracking contribution（phase标记）
  → Safety：所有active channel reasons与既有restrictions
  → PLC：唯一新的final ActuatorCommand
  → POST：登记获准新command / withdrawal-reversal-reissue生命周期
          不重新评价measurement，不再赚evidence
  → final causal publication（phase标记）
```

旧义务因真实progress/confirmation自然完成可在PRE处理；因本拍尚未产生的新command而withdraw/reverse不能预先处理。Policy A固定旧measurement > commit > command lifecycle；tracking contribution ready > Safety > PLC固定。不得第二次调用原update(t)完成POST：原candidate明确要求严格递增t（lifecycle:108），伪造t+epsilon同样是行为改变，不允许。

PRE记录与final public snapshot不一定是同一个state：如PRE赚suspected而POST合法withdraw暂停/steady。不能把PRE/POST各当一次公开progress milestone，不能清confirmed。Phase/transaction IDs是诊断元数据，不新增公开state。两切面的对外publication、reason lifetime与回滚/故障边界尚需UP-04裁决；此流程只给必要偏序，不声称完整等价。

## 7. Policy A 静态等价映射

| 行为 | 静态映射或反例风险 | 来源 | 判定 |
| --- | --- | --- | --- |
| active valid + same-cycle withdrawal | 条件可对应：评价旧义务→commit→POST withdrawal；snapshot取评价后 | lifecycle:131-156 | CONDITIONAL_STATIC_MAPPING |
| same-tick confirmation | 旧样本独立满足原criteria则先confirmed；POST不能清latch | paired:239-249; lifecycle:146 | CONDITIONAL_STATIC_MAPPING |
| withdrawal before/after evidence | POST依据_retained全部依据，不只count==0；取消/保留不同 | lifecycle:79-106 | CONDITIONAL_STATIC_MAPPING |
| State U suspension/reissue | startup.update在super前结合新command和测量创建context；机械拆分会改变anchor/机会和flag时点 | startup:73-143 | PORT_RUNTIME_SEMANTIC_EQUIVALENCE_UNRESOLVED |
| valid reversal / same-sample progress-resolution | 先解析旧pair，再POST方向重建，不能再credit旧source；pair重建可读当前measurement，需context-only协议 | lifecycle:137-166; paired:73-98 | PORT_RUNTIME_SEMANTIC_EQUIVALENCE_UNRESOLVED |
| invalid/recovery/deferred direction | invalid与recovery父链在主评价前依赖item.command；必须分离command-only updates与evidence updates且保留恢复不需新command | deferred:135-153; directional:30-98 | PORT_RUNTIME_SEMANTIC_EQUIVALENCE_UNRESOLVED |
| no stale confirmation / one watch / consumption | identity/history/context时钟须跨phase一致；POST禁止第二次update(t) | lifecycle:57;108-140; startup:137 | NECESSARY_INVARIANTS_NOT_FULL_EQUIVALENCE_PROOF |

关键限制：lifecycle的active+valid commandchanged路径先replace旧context再super.update，可映射旧义务评价。其他路径不都是这种结构：startup:73–143在父评价前用command与measurement建立/重建startup context；deferred:135–153的invalid/recovery处理在paired评价前；paired:151–197还含command event/reference创建。简单PRE只看旧command、POST永不看measurement，会遗漏这些reference/context建立；简单POST再跑原update又违反single-credit/严格时间。context-only使用已记录测量是否必要且不产生新credit，必须逐路径证明，不能凭“未确认”统一处理。

因此十类要求（withdraw前/后、same-tick confirmation、State U、reversal、outage/recovery、无stale confirmation、one lineage、consumption、single-credit）列入后续refinement proof，而不是本阶段全部PASS。没有发现必须修改Policy A或Contract14/15A的证据；“待证明”不等于合同冲突。

## 8. Same-tick规则（拟冻结）

| 事件 | 规则/限制 |
| --- | --- |
| same scheduler tick valid measurement + command | PRE仅看已存在PLC journal及旧义务；合格measurement旧context评价；Safety→PLC后POST登记，不用futurecommand证明PRE eligibility |
| withdrawal | 在旧measurement评价提交后按_retained决定取消或保留，方向inactive不等于清history；若合法confirmed则保留latch |
| reversal | 旧证据/watch保留；current material net方向依原规则可supersede；旧样本不为新direction赚钱 |
| reissue | 使用State U retained context，不按旧age同sample stale confirmation；context-only reference使用边界尚需等价裁决 |
| invalid→valid recovery | 首次fresh valid+qualified attribution恢复检查，不需新command；invalid零正/负证据；不能先丢deferred |
| duplicate delivery | 同physical/source identity不新鲜、不增加recovery/response/fault credit；receive_time改变无效 |
| delayed delivery | 未release前不可见；release时按source window/原command归属，不能按当时host最新command误算 |
| out-of-order delivery | 旧record审计归档，不能替换较新held source record；不作为迟到加分回放 |
| ambiguous provenance | 无tracking新credit，保留合法history/latch；不把quality VALID硬说成MISSING；UNKNOWN candidate路径保留entering state，INSUFFICIENT公开映射是否适用须独立冻结 |

同host tick不证明物理归属。PRE不得读取本拍未来PLC命令；PRE决定哪些样本可用于已存在义务，POST只登记已经产生的PLC output。只有source时间/已证明采样顺序或effect边界支持时，才能将窗口端点等于command边界解释为旧context；否则unknown，不加任意时间epsilon。

失效恢复必须主动检查已有deferred/current obligation，不要求另一个command触发。Outage中命令改变仅改变合法方向/需求上下文，不能赚measurement evidence。Duplicate/乱序不进行“补算旧分”。

## 9. B3：Provenance bridge schema

| 分组 | 字段 | 来源与缺失处理 |
| --- | --- | --- |
| measurement identity | source_id, entity_id, metric_name, source_restart_epoch_id, sample_id | source capability/Contract06；复合身份不得由host receive count构造 |
| measurement times | raw_source_timestamp, window_start, window_end, receive_time, release_time, timebase_id, clock_offset, timing_uncertainty, time_qualification | 真实source或有证据adapter提供；未知nullable+PROVENANCE_BRIDGE_REQUIRED；window=end-start |
| measurement quality | measured_speed, unit, quality, release_qualified | MEASURED only；VALID和attribution资格不同；未release不可见；invalid numeric null |
| command provenance | plc_restart_epoch_id, plc_command_id, plc_cycle_id, sequence_id_where_available, issue_time, applied_command_before_actuator_dynamics, accepted_target_id, safety_envelope_id, effect_boundary_interval_if_known, prior_command_id_used | 获准PLC output journal；host send/ack/effect分别记录，不推定issue==physical effect；nullable不造值 |
| tracking/transaction provenance | logical_watch_id, obligation_id, evaluation_time, consumed_source_identity, pre_evidence_commit_id, post_command_enrollment_id, runtime_restart_epoch_id, phase | bridge/qualifier产生的因果诊断，不宣称来自硬件；ID分配/commit格式需后续冻结 |

这是接口要求/nullable设计，不声称硬件都有字段。Contract06:14–29规定sample/receive/available、window、clock uncertainty、source IDs与restart epoch；Contract14:31规定time-aligned获准命令。桥接缺字段返回PROVENANCE_BRIDGE_REQUIRED，真实timing仍CALIBRATION_REQUIRED；不得补造0 delay/0 window/精确clock。

PLCcommand来源只可为inner_loop.ActuatorCommand/PLCCycle及获准journal（inner_loop.py:17/36/120）。command值取Safety约束后的applied_command_before_actuator_dynamics；requested target、pre-safety request、echo、measuredspeed与ACTUAL都不替代身份。created/issue、实际发送、ack和effect不是同一事件；如果dispatch未知，command authority可证但physical response eligibility不可推定。桥接元数据也不等于硬件报告值。

## 10. Window attribution / ambiguity

拟议证据资格要求：窗口及clock uncertainty的所有可行解释均支持同一已经enrolled的义务，而且response opportunity满足原冻结规则，才可award。不能用最新host command代替source window所属command。transition/effect boundary未知、window straddle无法解卷积、clock未知/重启未映射均NO_CREDIT；不发明noise/窗口容差模型。

Issue boundary与effect boundary必须分别保留：完整窗口在transition前可支持旧context，但仍需合法response机会；issue与effect之间的间隔只有独立delay资格证据才能归属；窗口跨transition/effect uncertainty集合不能只看end而乐观归属。若effect未知，不用fixture0.2s补齐。延迟delivery仍按source时间和已存在history判断。

“不能award”不意味着自动全清或invent FAULT。candidate UNKNOWN/POST_COMMAND_EFFECT路径保留entering state而不给old credit（lifecycle:123/141）；真实quality invalid由原INSUFFICIENT路径及独立sensor Safety处理。将provenance ambiguous统一改公开INSUFFICIENT不能静默视为已经等价，列入publication裁决；既有confirmed保持。Sensor quality VALID与causal attribution合格是两个条件。

## 11. Single-credit与测量权限

消费身份按source复合键绑定logical watch/obligation/evaluation commit，至少保留到不会将旧source作为新样本重用的可证明边界；当前永久ledger是否可裁剪未获批准。重复receive不更新sample freshness，restart重用ID不能新鲜，乱序旧packet不能覆盖newer held。旧sample不能给新obligation再次记功；可复用既有reference值作context的情形必须与新evidence区分并证明，不由bridge自行创造progress。

所有qualifier decisions只读released MEASURED；flow/DP仍独立Safety/诊断，不偷偷替代speed tracking confirmation。Truth只在measurement仿真生成边界出现，不经过bridge洗成未经传感器资格的控制输入。

## 12. B4：仅预登记既有15A集成

STEADY/HANDOFF/PROGRESS → NORMAL identity、不加tracking severity/restriction；SUSPECTED → DEGRADED/ACTUATOR_TRACKING_SUSPECTED、无tracking限制；CONFIRMED → FAULT/ACTUATOR_TRACKING_CONFIRMED、原fallback/latch/recovery；INSUFFICIENT不新增actuator fault。旧raw mismatch+2s detector不得与新qualifier并列为同path第二套资格策略。

Contract15A:28按FAULT > PROTECTED > DERATE_REQUESTED > DEGRADED > FF_DISABLED > NORMAL reduce，并保留所有active reasons。sensor/thermal/hydraulic/pressure/priorconfirmed/其他channel不被tracking if/elif吞掉；tracking正常不清独立FAULT，恢复motion不清latch。pressure优先和原envelope限制不改。无新主reason字段、无新timer/threshold、无新硬件动作。本阶段未实现B4。

## 13. 必须审阅的明确问题

- **UP-01 / USER_POLICY_DECISION_REQUIRED**：选A full checkpoint还是C必要state恢复+输入连续性重资格？B无逻辑连续性不能作为未解/confirmed状态下的透明替代。
- **UP-02 / USER_POLICY_DECISION_REQUIRED**：checkpoint丢失/损坏/过旧、PLC输出或时间连续性未知时，允许的运行/恢复动作是什么？需既有Safety权限内单独冻结，不能发明新tracking FAULT。
- **UP-03 / USER_POLICY_DECISION_REQUIRED**：Safety显式reset与qualifier confirmed恢复如何绑定、何时解除历史、如何审计？原合同没有规定qualifier reset API。
- **UP-04 / PORT_RUNTIME_SEMANTIC_EQUIVALENCE_UNRESOLVED**：PRE证据贡献与POST生命周期最终public publication的事务切面，以及启动/State U reissue/outage recovery/reference creation如何等价？
- **UP-05 / USER_POLICY_DECISION_REQUIRED**：跨restart clock映射、停机时间与first fresh sample response机会如何处理？不得伪造时间连续性或凭停机时间新增证据。

这些问题不能被R4.6成绩代答。尤其UP-04是静态等价证明缺口，不是单凭选择某方案即可宣告关闭；必须先约定预登记的proof对象、允许读取context的切面和public contribution identity。

## 14. 后续静态验证建议（本阶段未运行）

- checkpoint completeness covers every behavior read and identity allocator; torn transaction invalid
- source/PLC/runtime epoch binding and no pre-restart credit
- dependency graph acyclic; no PRE reads future PLC output; Safety before PLC
- symbolic transition/refinement proof for all equivalence rows incl State U and recovery
- window/clock uncertainty attribution no fabricated precision
- duplicate/out-of-order ledger and reason retention static invariants

未来行为验证、R4.6域回归、scheduler实测、硬件校准/fault injection分开另批。本阶段没有生成候选、测试fixture或adapter，更没有执行这些检查以声称PASS。没有赋任何real command delay/tau/ramp/minΔspeed/sampleperiod/latency/clock/noise数字。真实参数全部CALIBRATION_REQUIRED；P15仅重构C9R，其他P历史依然未恢复。

## 15. 完整性与STOP

只新增本阶段report/registration/evidence三文件；原Git-visible 2,188文件以SHA-256比较保护，另外绑定所有核心source和上游JSON raw/canonical。保护范围不宣称包含所有ignored缓存。candidate/production/Safety/PLC/measurement/contracts/ITQ/Startup/DSX不变；behavioral tests=0，candidate execution=0，Git commit/push=NO。

本包自身hash写入单独evidence/最终响应，避免JSON自引用；canonical规则为UTF-8、ensure_ascii=False、sort_keys=True、separators=(',',':')，raw按真实保存bytes。evidence不嵌入自身hash。

保持：candidate=REQUALIFIED_FOR_FROZEN_FIXTURE_DOMAIN；CAN_PRODUCTION_PORT_START=NO；FULL_P_HISTORY_VALIDATION_AVAILABLE=NO；REAL_HARDWARE=CALIBRATION_REQUIRED；PHASE6=NO。下一步用户审阅restart policy、scheduler split和provenance schema，单独批准后才能冻结；本阶段STOP，无实现授权。

