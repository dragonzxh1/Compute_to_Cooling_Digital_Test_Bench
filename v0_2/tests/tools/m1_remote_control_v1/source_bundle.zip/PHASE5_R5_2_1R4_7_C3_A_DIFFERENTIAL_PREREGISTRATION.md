# R4.7-C3-A — Independent PRE/POST Differential Qualification Preregistration

## 1. 当前结论

`C3_A_PREREGISTRATION_READY_FOR_REVIEW`。

只完成“试卷/判卷/证据链”设计。没有split engine、可执行split harness、比较器实现或行为运行；没有自动冻结可执行资格包。C3-B创建与C3-C执行均未授权。

大白话：先把“比较什么、在哪一拍比较、哪些差异算失败”写死，再让后续独立开发的split来考试。原R4.6成绩只证明参考算法原资格，不拿来充当本轮新结果。

## 2. 冻结基线核验

C2-R1规范RAW49e953…ee215、登记e8f7e7…06653、manifest6f491e…6a61a、evidence7371fa…1c37e5及aggregate `3b171572e35afe57ec5e660a8822d8acd9704b5c4d2593842cf239be442cd019` 均按实际bytes复算匹配，manifest全部来源/产物raw/canonical绑定匹配。R4.6candidate453f2f…9300、run68dc4e…5d49、PolicyA d86eaa…167082及原合同保持。

51个ITQ input与23个expected文件实际SHA匹配原A1 exactmatrix。101个现有materialized INPUT trace来自R4.6已持久化structured结果：51ITQ、U+16ST、C13、S19、P15共101；读取后用独立canonical输入hash绑定，不执行原生成器/candidate。

完整身份在每份spec.source_hash_bindings及inputdescriptor。JSON canonical采用UTF8/sort_keys/compact/ensure_asciiFalse；比较数值规则另见comparator，不把JSON格式一致当算法一致。

## 3. 三条独立Lane

| Lane | 验证内容 | Oracle / 比较边界 |
| --- | --- | --- |
| A frozen reference behavior | finalstate、公事件time/count、watch/obligation、evidence、responsehistory、pairedrefs、StateU/nostale/singlecredit/latch | 原candidate fresh一update每row，POSTfullcore精确比较 |
| B new P1 temporal Safety | PRE真实性/immutablemapping/decision适用期限/allreasons/no retrorewrite/一finalpublication | 已批准C2R1 T01..10、15A/profile/classifier独立断言；没有原productionPREgolden |
| C authority/transaction | Safety-beforePLC、唯一命令owner、禁止PRE读未来、真实模拟output enrollment一次、四commits、incomplete/UNKNOWN | 独立capability/phase/commandjournal/commit audit，不能仅靠输出state声明 |

R4.6没有观测到productionPRE Safety快照。StateU PREsuspected仍是source-derived，不标runtimeobserved。未来有readonlyinstrumentedreferencecut也只是新软件derived observation，不冒充历史硬件日志。

## 4. Reference oracle与全状态观察设计

Oracle=`WatchLifecycleTrackingQualifier`及冻结Startup/Directional/Deferred/Paired/base链。不能改模块或用split输出生成golden。

snapshot()不含全部行为state，因此未来C3-B需独立freeze只读observer。静态AST提取56个reference self属性（含parameters/logs/pairs/epoch/startup/consumption/previousinput/clock），全部presence/value进入coreprojection；不把不存在字段变None，不能只挑state和count。完整列表见oracle JSON。

未来observer只读vars/dataclass，不代换update或修改reference；entry/final每tick必采集，旧interval cut若需source tracing必须冻结line/sourcehash及非干扰证明。Inactive/invalid/curr-command-sensitive路径不能用reference内部已经知道c_new的cut来替splitPRE越权。B Lane独立限定旧context/evidence，不能把原candidate执行结构当已合格生产scheduler。

## 5. 四个接口、读写权限和因果输入

接口仅定义，未实现：
PRE_EVALUATE_OLD_OBLIGATION → SAFETY_CONSUME_PRE_CONTRIBUTION → PLC_PRODUCE_FINAL_COMMAND → POST_ENROLL_COMMAND_AND_PUBLISH。

PRE只能读measurement-only view、已enrolled priorjournal和旧qualifiedstate；原完整row里c_new由orchestrator/模拟PLC私有，不能传给PRE。POST允许context-only reference建立，但newprogress/fault/suspicion/confirmation/opportunity/secondsourcecredit全禁止。不能调用原update两次同t，不能加epsilon。每个source/oldcommand/phase/decision/output/newdirection/publication有固定transaction链接，PRE不增加公开milestone。

### 命令因果模型

为数值差分采用 `DEVELOPMENT_ONLY_SIMULATED_PLC_AUTHORIZATION_NOT_HARDWARE_TRACE`：
- 首row command是明确标注的既有fixture commanded initial condition，用于PREexistingcontext；不是捏造历史Safety/PLCissue或负时间事件。
- 后续每个value/issue-time变化事件在本tickSafety之后，由唯一模拟PLC角色发出原fixture获准output值，POST才enroll。原51variants/ST/U/C/S/P15检查没有“issue时刻≠首次可见row时刻”事件，因此无需retime输入。
- 保留reference legacy released-command:<issue_ns>投影身份，另用新metadata绑定模拟PLCproducer/cycle；绝不称真实PLC/hardwareID或requested target。
- Heldrepeat不是新enrollment，timestamp变化但value相同仍只按原reference语义处理，无新fakecredit。
- C3-B输入recipe同样必须满足此同步模型，否则TEST_INPUT_CAUSALITY_UNRESOLVED；不改原期望。

这是对已给定外生command trace的tracking调度语义/owner/provenance测试，不验证真实闭环PID输出、硬件command执行或numeric安全action可实施性。真正Safety/PLC集成及硬件资格仍独立gate；不得把此模拟授权边界写成production通过。

## 6. 16 PF绑定与验收cut

| PF | 路径 | 已绑定source inputs |
| --- | --- | --- |
| PF-01 | withdrawal before evidence | ST-01, ST-04, ST-06, ITQ-013 |
| PF-02 | withdrawal after evidence | ST-02, ST-03, ST-11, ITQ-014 |
| PF-03 | same-tick confirmation | ST-12-POLICY-A-v2, ITQ-003 |
| PF-04 | State U suspension | U-fresh |
| PF-05 | State U reissue | U-fresh, ST-11 |
| PF-06 | reversal | ITQ-010, ITQ-011 |
| PF-07 | invalid outage | ST-05, ST-16, ITQ-012 |
| PF-08 | valid recovery | ST-07, ITQ-015, ITQ-016 |
| PF-09 | deferred demand | ITQ-012, ITQ-015, ITQ-016 |
| PF-10 | resolved_pair creation | ST-01, ITQ-001 |
| PF-11 | progress_pair creation | ST-13, ST-15, ITQ-017, ITQ-020 |
| PF-12 | startup reference establishment | U-fresh, ST-12-POLICY-A-v2 |
| PF-13 | no stale confirmation | ST-10, ST-11, U-fresh, ITQ-014 |
| PF-14 | watch lineage | ST-10, ST-11, ST-16, ITQ-014 |
| PF-15 | sample single-credit | ST-08, ST-09, ST-16, ITQ-017 |
| PF-16 | confirmed latch retention | ST-12-POLICY-A-v2, ITQ-003, ITQ-016, ITQ-022 |

每条保留完整原C1 row和classification，没有PROVED promotion。canonical0.2s主见证用于PF定位，所有51原meshvariants仍列入fullregression；不是只测选中的几个ITQ。每source有原fixture或已有structured INPUTS JSONpointer、raw/canonical/inputhash、rowcount/replay_kind、generator/expectation来源。PF无COVERAGE_INPUT_MISSING。

每row预登记五cut：decisionentry/reference-before、PREafterevidencecommit、Safetyaftercommit、PLCafteroutputissue、POSTfinal。A lane同variant原timestamp精确对比；ORDER phase即使timestamp相同仍不能倒序。Meaningfulfields包括所有原state、nestedrefs/provenance、sourceID、creditcount、latch和公事件；参见PFmatrix完整字段。

PF必须在freshreference出现其precondition事件/历史，不允许空覆盖vacuousPASS；若newrun没有合法sourceprecondition，是incomplete/integrity，不能把“没遇到问题”算PF成功。所选input读旧records只提供输入和来源；newqualification必freshreference，不借旧snapshots/PASS。

## 7. StateU精确见证

ST12-U-CONTROL-v1 / U-fresh，t=1200000000ns，source synthetic-measurement:1200000000。
Oldcommand0.7/measured0.5，count0→1/notconfirmed，PREsource-derivedSUSPECTED；同cycle模拟PLCwithdrawal0.5后POSTSTEADY、retainedwatch/flagTrue，原publictransitioncount1。

冻结断言：只一份真实oldmeasurement failurecredit；PRE可以在当前decision映DEGRADED/no trackingrestriction；POST只生命周期和context，不能重记分；旧PRE/Safetybytes不回写；下一cycle新qualifiedinput/no stalePREcopy；不多加publicsuspected/progressmilestone。2.6s reissue和laterconfirmed另按原U/v2断言，不混淆run-endlatch与1.2s状态。

## 8. 独立comparator规范

18条CMP-A/B/C规则覆盖用户要求的全部mismatch类型。未实现、未执行。

Canonicalcore规则严格：typedpresence/missing≠None、intns/count exact、bool≠int、finiteIEEE754binary64精确位模式/保留signedzero、原array/event顺序、所有原ID exact、consumption set按typedkey canonical。没有一般epsilon/rounding/allocatorwildcard或删除meaningfulfields。

新增P1 transaction/cycle/evidencebinding/commitID、executionmetadata仅在明示路径验证identitygraph与deterministic case-row-phaserecipe；重复执行可只对这些新metadata中的runexecution前缀做角色映射，不归一化原source/clock/旧IDs。B Lane新Safetyreason_codes按唯一exact集合验证，重复或丢reasonFAIL，再sorted显示；原candidatearrays不处理为set。

所有oldfixtureexpected与EXACT/ORDER/WINDOW/NON规则保持；更强diffcore equality是单独验收，不回写historicgolden。NoPREgolden时B独立用批准条款和sourcequalificationpredicate，不从SUT报告“valid”自证valid。

原离线mapping契约M1..M16作为独立symbolicSafety输入组合，绑定已有expectedseverity/channel/retainedreason规则；不是运行真实pressure/thermal传感器，也不增hardware数值。

## 9. Future evidence / prefix / repeat顺序

1. 原输入、reference/observer/comparator/env/code身份封包；核验source/capability。
2. Freshreference及原frozenexpectation checks，先raw/structured/frames持久化、fsync、hash回读完整性。
3. 用approvedconditionalselector从persistedfreshreference物化selectedinventory，hash后才能prefixcomparison；不预填旧1363。
4. Split phases/fullcore独立执行与持久化，再用封存comparator检查三Lane/PF16/fullregression。
5. Prefix/repeat及完整性gate；FAIL当次STOP，不修code/fixture/expected后重跑PASS。

ITQ仍23cases/51variants，原mandatory674、eligible2298，仅inputmandatory + freshreference progress + confirmed union；不改为all2298、不由splitoutput选题。U/ST/C/S/P15沿原fullprefix policy。Repeatpolicy原样：ITQ/U/ST2fullsnapshots，C/S/P15 baseline+10 additional共11。

FreshStartup50原testbodies不改，reference/split的未来versionedadapter需要独立冻结；旧49/50唯一legacyline144/assertion/type/semanticidentity须精确匹配，不能任意容忍1fail。新compatibility由freshU/v2/ST及prefix/repeat分开报告。输入生成recipe必须独立于被测候选结果；未来若不能在执行前解析输入，须阻止资格执行，不能盲继承旧分数。

C11groups/13traces、S17groups/19traces、重构P15单独fresh；C9保持原排除。P1-P14/P16-P20始终未恢复，FullPHistoryNO，ITQ不是它们的替身。

## 10. Restart与T09单独扩展

Oracle登记7条EXT-R协议场景：validrestore、torncheckpoint、stale/duplicateID、断裂commandattribution、coordinatedreset、firstfresh、nobackcredit。使用futurefreshreference-derivedstate及既有输入suffix，expected来自UP01/02/03/05，不把原R46叫硬件restartoracle。新增sourceepoch/transaction metadata是协议刺激，不修改原frozen数值fixture。

7条EXT-T09分别覆盖PREcommit后、Safetycommit后、PLCissue后、POSTpublish前、UNKNOWNissue、重复recovery、idempotentjournalreconciliation。注入点按phase/event，不发明timer/物理延迟。当前没有journal格式/实现或durable故障证据，因此明确：
`T09_RECOVERY_QUALIFICATION_BLOCKED=YES_FOR_REAL_DURABLE_RUNTIME`。
协议场景已设计，实际checkpoint/journal/injection schema仍须C3-B独立封包；in-memory模型PASS也不证明真实durability，IMPLEMENTATION_HOLD不解除。

这是后续执行blocker，不是16PF输入缺失或本阶段伪装normalPF success。软件fixturecore可单独限定验证范围，完整runtimefinalfreeze仍需T09/restart/provenance/hardware等义务关闭。

## 11. 后续分阶段授权与失败分类

C3-B仅为建议名：development-only split/comparator/readonlyobserver、syntheticcomparator负例和input-first materializer实施；需用户另批。开发验证与正式qualification分开，不能开发跑了之后换试卷。

C3-C仅为建议名：finalexecutable/inputs/comparator/env/artifactschemas/STOP封存后，由用户单独授权blindfreshdiff。Reference必须先持久化再比较，score不借。
EVIDENCE_INTEGRITY_INVALID不做behavior裁决；validinput/evidence真实mismatch为BEHAVIORAL_DIFFERENCE；只有所有requiredcomparisons与coverage/prefix/repeat通过才PASS。首divergentpointer/phase、rawinputs/records保存，不改单次失败。

## 12. 本阶段结构完整性与STOP

只创建指定6个新版report/spec/matrix/comparator/integrity JSON文件，无.py split/observer/harness/comparator创建；Python只做stdlibJSON/AST读取、结构/hash审计，没有candidateimport/replay或比较器执行。

保护开始Git-visible2,216原文件，前后hash同（忽略缓存不声称全盘审计）；旧C2-R1和C2STOP/C1/R46/production/DSX/Twin不改；Gitcommit/pushNO。本包精确hash在integrity evidence及最终响应；prereg aggregate不自引用，用5核心产物+绑定source数据封存设计身份，不等于可执行package或automaticapproval。

当前C2-R1NARROW_PUBLICATION_TIMING_POLICY_FROZEN有效；C3 executionNO；UP04UNRESOLVED；runtimeNOT_FROZEN；productionportNO；hardwareCALIBRATION_REQUIRED；FullPHistoryNO；Phase6NO。
下一步仅请用户审阅C3-A，再另批C3-B开发预登记实现。STOP。

